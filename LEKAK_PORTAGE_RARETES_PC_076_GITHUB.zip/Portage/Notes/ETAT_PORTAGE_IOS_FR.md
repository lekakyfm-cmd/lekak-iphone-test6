# LEKAK — portage iOS natif (étape 2, vérifications catalogue)

Cette branche est une **base de développement**, et non un IPA v0.7.6 jouable.

## Réalisé
- Conservation du noyau CPU de rareté de l'étape 1 (probabilités, bonus ATK/DEF, prix, palette BGR555).
- Génération déterministe de la correspondance exacte des **518 cartes supplémentaires** Lekak depuis `identities.h` (v0.7.6 PC), avec tests de dérive.
- Registre C natif capable de produire les **4 960 identifiants de variantes** et de vérifier les 1 240 cartes de base présentes dans un catalogue.
- Liaison du registre à `App/native_entry.c` **après** `Cards_Build` en **diagnostic lecture seule** (aucune mutation de cartes, aucune texture modifiée).
- Ajout à la compilation des objets Mach-O arm64-apple-ios15.0 dans la bibliothèque statique Lekak ; vérification des empreintes à la liaison.
- Tests automatisés du catalogue, de tous les 4 960 identifiants, du noyau de palette et des bornes.

## NON réalisé — important
- **Aucun nouveau binaire iPhone ou IPA v0.7.6 n'a été construit.** L'environnement actuel est Linux, pas macOS avec Xcode/iPhoneOS SDK.
- Le registre permet l'identification des cartes **mais ne crée pas les 4 960 variantes dans le jeu**. Elles nécessitent un manifeste de données actif, le support de sauvegarde, puis les hooks PC adaptés à ARM64.
- Non portés : les 11 unités de hooks de duel / drop / main / menu / bibliothèque, les textures banques/palettes VRAM, les dos de carte, les routines de collection/revente.
- Aucune exécution en duel, test sur vrai iPhone ou signature de l'IPA.
- Ne remplace **pas** l'IPA stable précédente par un build issu d'étape 2.

## Valider et compiler (sur macOS ARM64, Xcode)
```
python3 tools/generate_rarity_registry.py --check
python3 tools/test_rarity_port.py
```
Puis lancer manuellement le workflow `.github/workflows/lekak-native-ios.yml`.
Le workflow existant reconstruit l'application iPhone de base avec son registre de diagnostic, **sans les variantes jouables**.

## Prochain travail requis pour le portage complet
1. Construire/tester une ABI des 11 unités de raretés PC avec le jeu iOS traduit.
2. Adapter le modèle de chargement du module natif iOS (et ses données) au manifeste `lekak-rarities-test` sans charger un `.o` Windows.
3. Ajouter les 4 960 cartes au catalogue iPhone en préservant la persistance des sauvegardes et la compatibilité de mods.
4. Porter les hooks de drop/stats/IA/menus/bibliothèque, puis les hooks palettes/clut bank13 avec l'anti-corruption graphique v0.7.6.
5. Porter et tester le module Collection & revente v1.6, intégrer les hooks d'interface.
6. Compiler, signer et valider en conditions réelles sur iPhone : duels, variantes, illustrations, dos des cartes, couleurs et fluidité.


## Étape 3 — snapshot natif sécurisé du catalogue (octobre 2026)

Ajout de `SourceMod/RaritiesNative/rarity_snapshot.[ch]`, compilé dans
`libLekak_iPhone.a` par `tools/build_lekak_ios_objects.py`.

- La routine `LekakRarity_SnapshotBuildIndexed` balaie le catalogue via
  `Cards_Identity(id)` une seule fois pour retrouver les quatre tiers par carte.
  Elle ne suppose aucun ordre pour les identifiants physiques des variantes.
- Avant d'exposer la table, elle vérifie la présence **des 4960 variantes**,
  l'unicité des paires `(base, tier)`, les bornes d'identifiants et les
  1240 cartes de base. Un catalogue absent retourne `0`, partiel ou
  corrompu retourne `-1` et **aucune table n'est publiée**.
- L'entrée `App/native_entry.c` l'appelle **après** `Cards_Build` uniquement
  en mode lecture, avec diagnostic dans stderr.
- Les tests hôte `tools/test_rarity_port.py` couvrent catalogue complet,
  absent, partiel, doublons, variantes réordonnées, erreur de syntaxe,
  limites et remise à zéro.
- `tools/build_native_ipa.py` refuse de lier un objet périmé à partir de
  son empreinte SHA-256, comme pour les modules des étapes précédentes.
- Validation locale : objet **Mach-O ARM64 ciblant iPhoneOS** émis par
  `clang -target arm64-apple-ios15.0` en mode freestanding. Cela ne prouve
  pas que l'application UIKit a été liée ou testée.

**Pas encore actif en jeu :** le manifeste des variantes n'est pas chargé,
aucun tirage de rareté, hook de duel, banque de texture, palette ni
sauvegarde de variante n'a été activé. Ne pas installer cette étape comme
une nouvelle IPA de raretés.


## Étape 4 — catalogue iOS hors ligne et contrat de sauvegarde (octobre 2026)

- `tools/stage_rarity_ios_catalog.py` valide le manifeste PC complet et
  produit sur demande un **catalogue iOS de test hors ligne** avec 4960
  identités stables et les 518 PNG nécessaires. Il retire le pointeur
  `library` PC (introuvable sur iOS) et les 136 règles d'équipement qui
  attendent des hooks non portés. Par défaut, rien n'est copié dans le
  bundle iPhone ni activé. Le catalogue expérimental ne doit PAS être
  installé comme un mod jouable.
- `rarity_save_bridge.[ch]` convertit les identifiants du catalogue
  vers leurs identités stables, et inversement, **après** validation de
  la table `rarity_snapshot` (étape 3). Les tests simulent l'ordre de
  cartes modifié, les entrées malformées et la table absente. Aucun
  fichier de sauvegarde réel n'est encore lu, écrit ou migré par la
  passerelle native.
- La source du moteur (`EngineSDK/src/pc/cards/cards.c`) utilise déjà
  `chest2`, `seen2`, `deck2` et `recent2`, avec les identités, pour les
  cartes supplémentaires. Des tests vérifient que ce contrat existe.
  Ce **test statique** n'est pas une preuve que les variantes sont
  sauvegardées sur iPhone ; le catalogue PC n'est pas chargé dans l'app.
- Compilation testée de la passerelle en objet Mach-O ARM64 destiné à
  iPhoneOS. Build UIKit/Xcode, jeu et sauvegardes sur appareil : NON TESTÉS.

Ne pas remplacer l'IPA stable par cette étape. Les hooks de duel, de
revente, de drop, de bibliothèque et de palettes restent à porter.
