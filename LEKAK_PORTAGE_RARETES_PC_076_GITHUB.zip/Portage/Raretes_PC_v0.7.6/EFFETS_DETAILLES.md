# Effets détaillés des cartes — Lekak v0.7

**Ces effets sont implémentés dans le module v0.7 fourni dans ce ZIP.** Les originales restent inchangées. Compilation et tests automatiques effectués ; le rendu et les duels restent à vérifier dans le jeu Windows.

Ce guide couvre les **101 cartes** Équipement, Magie, Piège et Rituel du jeu USA, avec une fiche par carte. Les noms anglais et numéros permettent de les retrouver dans le jeu. Les effets sont ceux de **Forbidden Memories**, pas ceux du jeu de cartes papier.

## Comment lire ce guide

- **PV** : points de vie. Soigner rend des PV ; infliger des dégâts en retire.
- **ATK / DEF** : attaque / défense du monstre. « +600 ATK et +600 DEF » augmente chacune de ces deux valeurs.
- **Terrain adverse** : les cartes déjà posées par ton adversaire ; sa main et son deck ne sont pas touchés sauf mention contraire.
- **Seuil inclus** : « ATK ≤ 1500 » signifie 1500 ou moins.
- Les tableaux donnent le **résultat total de la carte**, pas une deuxième augmentation à ajouter.
- Les plafonds de PV et de statistiques du jeu restent applicables. Les soins proposés sur les effets utilitaires ne se déclencheraient qu’après un effet réussi, une seule fois par activation.
- Les couleurs, les taux de drop et les prix de revente déjà choisis restent les mêmes.

Les recettes rituelles et les listes d’équipements ci-dessous ont été extraites du disque USA fourni. Les compatibilités ajoutées par Lekak restent prioritaires dans le jeu ; la liste précise du disque sert de référence pour les cartes d’origine.

## Équipements — 34 cartes

### 301 — Legendary Sword
**Effet d’origine :** Augmente de **500 points l’ATK et de 500 points la DEF** d’un monstre compatible auquel tu appliques cet équipement. Le renforcement concerne ce monstre, pas tout ton terrain, et reste tant que ce monstre conserve son état sur le terrain. Un monstre incompatible ne reçoit pas le bonus.

**Conditions et limites :** Les mêmes monstres restent compatibles à toutes les raretés. Reverse Trap peut retourner le renforcement en pénalité. Le bonus d’équipement s’ajoute aux statistiques du monstre, y compris son éventuel bonus de rareté.

| Rareté | Effet total selon la rareté |
|---|---|
| Normale | Le monstre équipé gagne **500 ATK et 500 DEF**. |
| Rare | Le monstre équipé gagne **600 ATK et 600 DEF**. |
| Épique | Le monstre équipé gagne **800 ATK et 800 DEF**. |
| Légendaire | Le monstre équipé gagne **1000 ATK et 1000 DEF**. |
| Mythique | Le monstre équipé gagne **1300 ATK et 1300 DEF**. |

**Monstres compatibles dans le disque USA :** Swamp Battleguard (n° 12); Flame Swordsman (n° 15); Battle Ox (n° 26); Beaver Warrior (n° 27); Mountain Warrior (n° 29); Judge Man (n° 33); Gaia the Fierce Knight (n° 38); Celtic Guardian (n° 41); Karbonala Warrior (n° 43); Tiger Axe (n° 64); Kojikocy (n° 66); Axe Raider (n° 78); Rabid Horseman (n° 92); Zanki (n° 93); Battle Warrior (n° 100); Hero of the East (n° 110); Supporter in the Shadows (n° 118); Dream Clown (n° 120); Octoberser (n° 131); Charubin the Fire Knight (n° 133); Dragon Statue (n° 138); Monster Egg (n° 147); Rhaimundos of the Red Sword (n° 151); Hard Armor (n° 156); M-warrior #1 (n° 160); M-warrior #2 (n° 161); The Judgement Hand (n° 165); Mysterious Puppeteer (n° 166); Armaill (n° 172); Eyearmor (n° 185); Arma Knight (n° 196); Penguin Knight (n° 199); Meotoko (n° 212); Trap Master (n° 224); Wood Clown (n° 231); Wodan the Resident of the Forest (n° 235); Hyo (n° 250); Nekogal #1 (n° 252); Dimensional Warrior (n° 256); The Little Swordsman of Aile (n° 262); The Furious Sea King (n° 265); Princess of Tsurugi (n° 266); Gatekeeper (n° 286); Moon Envoy (n° 290); Fireyarou (n° 291); Masaki the Legendary Swordsman (n° 293); Sonic Maid (n° 299); Kanan the Swordmistress (n° 352); Stuffed Animal (n° 354); Millennium Shield (n° 362); Giltia the D. Knight (n° 389); Swordsman from a Foreign Land (n° 399); Beautiful Beast Trainer (n° 434); Minomushi Warrior (n° 456); Cockroach Knight (n° 479); D. Human (n° 502); Bean Soldier (n° 511); Mushroom Man #2 (n° 553); Empress Judge (n° 572); Tenderness (n° 601); Bladefly (n° 609); Performance of Sword (n° 701); Skull Guardian (n° 704).

### 302 — Sword of Dark Destruction
**Effet d’origine :** Augmente de **500 points l’ATK et de 500 points la DEF** d’un monstre compatible auquel tu appliques cet équipement. Le renforcement concerne ce monstre, pas tout ton terrain, et reste tant que ce monstre conserve son état sur le terrain. Un monstre incompatible ne reçoit pas le bonus.

**Conditions et limites :** Les mêmes monstres restent compatibles à toutes les raretés. Reverse Trap peut retourner le renforcement en pénalité. Le bonus d’équipement s’ajoute aux statistiques du monstre, y compris son éventuel bonus de rareté.

| Rareté | Effet total selon la rareté |
|---|---|
| Normale | Le monstre équipé gagne **500 ATK et 500 DEF**. |
| Rare | Le monstre équipé gagne **600 ATK et 600 DEF**. |
| Épique | Le monstre équipé gagne **800 ATK et 800 DEF**. |
| Légendaire | Le monstre équipé gagne **1000 ATK et 1000 DEF**. |
| Mythique | Le monstre équipé gagne **1300 ATK et 1300 DEF**. |

**Monstres compatibles dans le disque USA :** Swamp Battleguard (n° 12); Battle Steer (n° 14); Summoned Skull (n° 22); The Wicked Worm Beast (n° 23); Horn Imp (n° 25); Zombie Warrior (n° 30); Gaia the Fierce Knight (n° 38); Kojikocy (n° 66); Garoozis (n° 68); Kageningen (n° 107); Trial of Nightmares (n° 119); Ancient Tool (n° 124); Ansatsu (n° 127); Masked Clown (n° 182); Doron (n° 195); Kagemusha of the Blue Flame (n° 214); Solitude (n° 219); Fiend Sword (n° 225); Skull Stalker (n° 226); Beautiful Headhuntress (n° 234); Guardian of the Labyrinth (n° 236); Vishwar Randi (n° 239); Dark Assailant (n° 241); One Who Hunts Souls (n° 246); Dimensional Warrior (n° 256); Unknown Warrior of Fiend (n° 267); Versago the Destroyer (n° 269); Mystic Clown (n° 281); Masaki the Legendary Swordsman (n° 293); Dragoness the Wicked Knight (n° 294); Cyber Soldier of Darkworld (n° 297); Megasonic Eye (n° 355); Super War-lion (n° 356); Three-legged Zombies (n° 359); Zera The Mant (n° 360); Black Luster Soldier (n° 364); Wall Shadow (n° 369); Gate Guardian (n° 374); Monster Tamer (n° 376); Swordstalker (n° 378); Saber Slasher (n° 405); Yaiba Robo (n° 406); Blocker (n° 416); Armed Ninja (n° 469); The Bistro Butcher (n° 523); Lava Battleguard (n° 554); Oscillo Hero (n° 559); Mechanical Snail (n° 585); Greenkappa (n° 586); Warrior of Tradition (n° 618); Succubus Knight (n° 621); Queen's Double (n° 635); Invader of the Throne (n° 641); Hibikime (n° 649); Hungry Burger (n° 702); Skull Knight (n° 707); Psycho-Puppet (n° 715); Garma Sword (n° 716); Mask of Shine & Dark (n° 720); Magician of Black Chaos (n° 722).

### 303 — Dark Energy
**Effet d’origine :** Augmente de **500 points l’ATK et de 500 points la DEF** d’un monstre compatible auquel tu appliques cet équipement. Le renforcement concerne ce monstre, pas tout ton terrain, et reste tant que ce monstre conserve son état sur le terrain. Un monstre incompatible ne reçoit pas le bonus.

**Conditions et limites :** Les mêmes monstres restent compatibles à toutes les raretés. Reverse Trap peut retourner le renforcement en pénalité. Le bonus d’équipement s’ajoute aux statistiques du monstre, y compris son éventuel bonus de rareté.

| Rareté | Effet total selon la rareté |
|---|---|
| Normale | Le monstre équipé gagne **500 ATK et 500 DEF**. |
| Rare | Le monstre équipé gagne **600 ATK et 600 DEF**. |
| Épique | Le monstre équipé gagne **800 ATK et 800 DEF**. |
| Légendaire | Le monstre équipé gagne **1000 ATK et 1000 DEF**. |
| Mythique | Le monstre équipé gagne **1300 ATK et 1300 DEF**. |

**Monstres compatibles dans le disque USA :** Hitotsu-me Giant (n° 3); Ryu-kishin (n° 5); Feral Imp (n° 6); Shadow Specter (n° 9); Blackland Fire Dragon (n° 10); Swamp Battleguard (n° 12); Time Wizard (n° 16); Right Leg of the Forbidden One (n° 17); Left Leg of the Forbidden One (n° 18); Right Arm of the Forbidden One (n° 19); Left Arm of the Forbidden One (n° 20); Exodia the Forbidden (n° 21); Summoned Skull (n° 22); The Wicked Worm Beast (n° 23); Skull Servant (n° 24); Horn Imp (n° 25); Zombie Warrior (n° 30); Koumori Dragon (n° 31); Saggi the Dark Clown (n° 34); Dark Magician (n° 35); Gaia the Fierce Knight (n° 38); Dragon Piper (n° 40); Illusionist Faceless Mage (n° 42); Oscillo Hero #2 (n° 45); Sangan (n° 48); Kuriboh (n° 58); Silver Fang (n° 65); Kojikocy (n° 66); Man-eating Plant (n° 75); Krokodilus (n° 76); Crawling Dragon #2 (n° 81); Castle of Dark Illusions (n° 83); Reaper of the Cards (n° 84); King of Yamimakai (n° 85); Barox (n° 86); Dark Chimera (n° 87); Metal Guardian (n° 88); Crass Clown (n° 95); Armored Zombie (n° 96); Dragon Zombie (n° 97); Clown Zombie (n° 98); Pumpking the King of Ghosts (n° 99); Wings of Wicked Flame (n° 101); Mask of Darkness (n° 102); Job-change Mirror (n° 103); Curtain of the Dark Ones (n° 104); Tomozaurus (n° 105); Kageningen (n° 107); Graveyard and the Hand of Invitation (n° 108); Doma The Angel of Silence (n° 111); That Which Feeds on Life (n° 112); Dark Gray (n° 113); Kamion Wizard (n° 115); Nightmare Scorpion (n° 116); Trial of Nightmares (n° 119); Dark Plant (n° 123); Ancient Tool (n° 124); Ansatsu (n° 127); The 13th Grave (n° 132); Fiend's Hand (n° 135); Witty Phantom (n° 136); Mystery Hand (n° 137); Blue-eyed Silver Zombie (n° 139); Spiked Snail (n° 141); Flame Manipulator (n° 142); Necrolancer the Timelord (n° 143); Temple of Skulls (n° 146); The Shadow Who Controls the Dark (n° 148); Lord of the Lamp (n° 149); Akihiron (n° 150); The Melting Red Shadow (n° 152); Dokuroizo the Grim Reaper (n° 153); Fire Reaper (n° 154); Larvas (n° 155); Man Eater (n° 158); Tainted Wisdom (n° 162); Lord of Zemia (n° 164); Ancient Jar (n° 167); Darkfire Dragon (n° 168); Dark King of the Abyss (n° 169); Big Eye (n° 171); Dark Prisoner (n° 173); Hurricail (n° 174); Ancient Brain (n° 175); Fire Eye (n° 176); Claw Reacher (n° 178); Phantom Dewan (n° 179); Dark Shade (n° 181); Masked Clown (n° 182); Eyearmor (n° 185); Gate Deeg (n° 187); Synchar (n° 188); Akakieisu (n° 190); Terra the Terrible (n° 194); Doron (n° 195); Mech Mole Zombie (n° 197); Frenzied Panda (n° 201); Air Marmot of Nefariousness (n° 202); Phantom Ghost (n° 203); Mabarrel (n° 204); Dorover (n° 205); Twin Long Rods #1 (n° 206); Winged Cleaver (n° 209); Hinotama Soul (n° 210); Meotoko (n° 212); Aqua Madoor (n° 213); Kagemusha of the Blue Flame (n° 214); Flame Ghost (n° 215); Two-mouth Darkruler (n° 218); Solitude (n° 219); Masked Sorcerer (n° 220); Kumootoko (n° 221); Midnight Fiend (n° 222); Roaring Ocean Snake (n° 223); Trap Master (n° 224); Fiend Sword (n° 225); Skull Stalker (n° 226); Wood Remains (n° 228); Wood Clown (n° 231); Madjinn Gunn (n° 232); Dark Titan of Terror (n° 233); Beautiful Headhuntress (n° 234); Guardian of the Labyrinth (n° 236); Vishwar Randi (n° 239); The Drdek (n° 240); Dark Assailant (n° 241); Candle of Fate (n° 242); Meda Bat (n° 245); One Who Hunts Souls (n° 246); Master & Expert (n° 248); Angelwitch (n° 253); Embryonic Beast (n° 254); Dimensional Warrior (n° 256); Beastking of the Swamps (n° 258); Ancient Sorcerer (n° 259); Wicked Mirror (n° 261); Unknown Warrior of Fiend (n° 267); Sectarian of Secrets (n° 268); Versago the Destroyer (n° 269); Megirus Light (n° 271); Gorgon Egg (n° 277); King Fog (n° 279); Mystic Clown (n° 281); Holograh (n° 283); Tao the Chanter (n° 284); Serpent Marauder (n° 285); Gatekeeper (n° 286); Ogre of the Black Shadow (n° 287); Dark Artist (n° 288); Fireyarou (n° 291); Masaki the Legendary Swordsman (n° 293); Dragoness the Wicked Knight (n° 294); Bio Plant (n° 295); Cyber Soldier of Darkworld (n° 297); Wicked Dragon with the Ersatz Head (n° 298); Yaranzo (n° 351); Megasonic Eye (n° 355); Three-legged Zombies (n° 359); Zera The Mant (n° 360); Millennium Shield (n° 362); Black Luster Soldier (n° 364); Fiend's Mirror (n° 365); Jirai Gumo (n° 367); Shadow Ghoul (n° 368); Wall Shadow (n° 369); Labyrinth Tank (n° 370); Sanga of the Thunder (n° 371); Kazejin (n° 372); Suijin (n° 373); Gate Guardian (n° 374); Monster Tamer (n° 376); Ryu-kishin Powered (n° 377); Swordstalker (n° 378); La Jinn the Mystical Genie (n° 379); Rude Kaiser (n° 382); Dark Rabbit (n° 384); Bickuribox (n° 385); Harpie's Pet Dragon (n° 386); Pendulum Machine (n° 388); Launcher Spider (n° 390); Zoa (n° 391); Metalzoa (n° 392); Emperor of the Land and Sea (n° 400); Ushi Oni (n° 401); Monster Eye (n° 402); Saber Slasher (n° 405); Machine King (n° 407); Giant Mech-soldier (n° 408); Mechanical Spider (n° 410); Giga-tech Wolf (n° 412); Shovel Crusher (n° 414); Mechanicalchacer (n° 415); Blast Juggler (n° 417); Golgoil (n° 418); Cyber-Stein (n° 420); Cyber Commander (n° 421); Jinzo #7 (n° 422); Beautiful Beast Trainer (n° 434); Water Girl (n° 435); Deepsea Shark (n° 437); Metal Fish (n° 438); Mech Bass (n° 441); Giant Red Seasnake (n° 447); Spike Seadra (n° 448); Kappa Avenger (n° 450); Kanikabuto (n° 451); Destroyer Golem (n° 454); Barrel Rock (n° 455); Stone Ghost (n° 457); Bolt Escargot (n° 460); The Immortal of Thunder (n° 462); Magical Ghost (n° 470); Soul Hunter (n° 471); Air Eater (n° 472); Sinister Serpent (n° 475); Pragtical (n° 482); Flower Wolf (n° 487); Needle Ball (n° 490); Wilmee (n° 496); Morinphen (n° 498); Dragon Seeker (n° 500); Man-eater Bug (n° 501); Fungi of the Musk (n° 504); Gale Dogra (n° 506); Crazy Fish (n° 507); Cannon Soldier (n° 512); Brave Scizzar (n° 514); Sand Stone (n° 517); Skullbird (n° 521); The Bistro Butcher (n° 523); Neck Hunter (n° 526); Milus Radiant (n° 527); Flame Cerebrus (n° 529); Eldeen (n° 530); Mystical Sand (n° 531); Minar (n° 534); Corroding Shark (n° 539); Skelgon (n° 545); Wow Warrior (n° 546); Bone Mouse (n° 548); Dark Elf (n° 551); Mushroom Man #2 (n° 553); Lava Battleguard (n° 554); Tyhone #2 (n° 555); The Wandering Doomed (n° 556); Oscillo Hero (n° 559); Invader from Another Dimension (n° 560); Lesser Dragon (n° 561); Wretched Ghost of the Attic (n° 563); Great Mammoth of Goldfine (n° 564); Man-eating Black Shark (n° 565); Darkworld Thorns (n° 567); Drooling Lizard (n° 569); B. Dragon Jungle King (n° 571); Witch of the Black Forest (n° 574); Leo Wizard (n° 578); Abyss Flower (n° 579); Takuhee (n° 581); Binding Chain (n° 584); Greenkappa (n° 586); Morphing Jar (n° 591); Rose Spectre of Dunn (n° 594); Fiend Refrection #1 (n° 595); Ghoul with an Appetite (n° 596); Pale Beast (n° 597); Violent Rain (n° 599); Key Mace #2 (n° 600); Obese Marmot of Nefariousness (n° 604); Hiro's Shadow Scout (n° 611); Twin-headed Thunder Dragon (n° 613); Hunter Spider (n° 614); Warrior of Tradition (n° 618); Succubus Knight (n° 621); The Thing That Hides in the Mud (n° 623); Stone Ogre Grotto (n° 632); Queen's Double (n° 635); Invader of the Throne (n° 641); Mystical Sheep #1 (n° 642); Disk Magician (n° 643); Flame Viper (n° 644); Gruesome Goo (n° 646); Whiptail Crow (n° 650); Hungry Burger (n° 702); Sengenjin (n° 703); Skull Knight (n° 707); Chakra (n° 709); Meteor Dragon (n° 712); Psycho-Puppet (n° 715); Garma Sword (n° 716); Dokurorider (n° 719); Mask of Shine & Dark (n° 720); Magician of Black Chaos (n° 722).

### 304 — Axe of Despair
**Effet d’origine :** Augmente de **500 points l’ATK et de 500 points la DEF** d’un monstre compatible auquel tu appliques cet équipement. Le renforcement concerne ce monstre, pas tout ton terrain, et reste tant que ce monstre conserve son état sur le terrain. Un monstre incompatible ne reçoit pas le bonus.

**Conditions et limites :** Les mêmes monstres restent compatibles à toutes les raretés. Reverse Trap peut retourner le renforcement en pénalité. Le bonus d’équipement s’ajoute aux statistiques du monstre, y compris son éventuel bonus de rareté.

| Rareté | Effet total selon la rareté |
|---|---|
| Normale | Le monstre équipé gagne **500 ATK et 500 DEF**. |
| Rare | Le monstre équipé gagne **600 ATK et 600 DEF**. |
| Épique | Le monstre équipé gagne **800 ATK et 800 DEF**. |
| Légendaire | Le monstre équipé gagne **1000 ATK et 1000 DEF**. |
| Mythique | Le monstre équipé gagne **1300 ATK et 1300 DEF**. |

**Monstres compatibles dans le disque USA :** Hitotsu-me Giant (n° 3); Ryu-kishin (n° 5); Feral Imp (n° 6); Swamp Battleguard (n° 12); Battle Steer (n° 14); Summoned Skull (n° 22); The Wicked Worm Beast (n° 23); Skull Servant (n° 24); Horn Imp (n° 25); Battle Ox (n° 26); Beaver Warrior (n° 27); Mountain Warrior (n° 29); Zombie Warrior (n° 30); Tiger Axe (n° 64); Kojikocy (n° 66); Garoozis (n° 68); Krokodilus (n° 76); Grappler (n° 77); Axe Raider (n° 78); Barox (n° 86); Metal Guardian (n° 88); Mystic Horseman (n° 91); Rabid Horseman (n° 92); Armored Zombie (n° 96); Kageningen (n° 107); Trial of Nightmares (n° 119); Ansatsu (n° 127); Lord of the Lamp (n° 149); The Melting Red Shadow (n° 152); Dark King of the Abyss (n° 169); Big Eye (n° 171); Claw Reacher (n° 178); Masked Clown (n° 182); Eyearmor (n° 185); Gate Deeg (n° 187); Synchar (n° 188); Terra the Terrible (n° 194); Doron (n° 195); Air Marmot of Nefariousness (n° 202); Twin Long Rods #1 (n° 206); Solitude (n° 219); Trap Master (n° 224); Skull Stalker (n° 226); Wood Clown (n° 231); One Who Hunts Souls (n° 246); Rock Ogre Grotto #2 (n° 263); Megirus Light (n° 271); Mystic Clown (n° 281); Gatekeeper (n° 286); Ogre of the Black Shadow (n° 287); Bio Plant (n° 295); Yaranzo (n° 351); Super War-lion (n° 356); Three-legged Zombies (n° 359); Toon Alligator (n° 381); Rude Kaiser (n° 382); Pendulum Machine (n° 388); Ushi Oni (n° 401); Yaiba Robo (n° 406); Giant Mech-soldier (n° 408); Giganto (n° 419); Millennium Golem (n° 453); Destroyer Golem (n° 454); Barrel Rock (n° 455); Soul Hunter (n° 471); Kuwagata α (n° 480); Man-eater Bug (n° 501); The Bistro Butcher (n° 523); Neck Hunter (n° 526); Hane-Hane (n° 541); Wow Warrior (n° 546); Lava Battleguard (n° 554); Steel Ogre Grotto #1 (n° 557); Drooling Lizard (n° 569); Patrol Robo (n° 580); Ghoul with an Appetite (n° 596); Hiro's Shadow Scout (n° 611); Warrior of Tradition (n° 618); Nekogal #2 (n° 627); Royal Guard (n° 645); Hibikime (n° 649); Sengenjin (n° 703).

### 305 — Laser Cannon Armor
**Effet d’origine :** Augmente de **500 points l’ATK et de 500 points la DEF** d’un monstre compatible auquel tu appliques cet équipement. Le renforcement concerne ce monstre, pas tout ton terrain, et reste tant que ce monstre conserve son état sur le terrain. Un monstre incompatible ne reçoit pas le bonus.

**Conditions et limites :** Les mêmes monstres restent compatibles à toutes les raretés. Reverse Trap peut retourner le renforcement en pénalité. Le bonus d’équipement s’ajoute aux statistiques du monstre, y compris son éventuel bonus de rareté.

| Rareté | Effet total selon la rareté |
|---|---|
| Normale | Le monstre équipé gagne **500 ATK et 500 DEF**. |
| Rare | Le monstre équipé gagne **600 ATK et 600 DEF**. |
| Épique | Le monstre équipé gagne **800 ATK et 800 DEF**. |
| Légendaire | Le monstre équipé gagne **1000 ATK et 1000 DEF**. |
| Mythique | Le monstre équipé gagne **1300 ATK et 1300 DEF**. |

**Monstres compatibles dans le disque USA :** Hitotsu-me Giant (n° 3); Baby Dragon (n° 4); Ryu-kishin (n° 5); Feral Imp (n° 6); Swamp Battleguard (n° 12); Tyhone (n° 13); Rock Ogre Grotto #1 (n° 28); Curse of Dragon (n° 39); Oscillo Hero #2 (n° 45); Griffore (n° 46); Big Insect (n° 49); Basic Insect (n° 50); Armored Lizard (n° 51); Hercules Beetle (n° 52); Killer Needle (n° 53); Gokibore (n° 54); Giant Flea (n° 55); Larvae Moth (n° 56); Great Moth (n° 57); Silver Fang (n° 65); Perfectly Ultimate Great Moth (n° 67); Garoozis (n° 68); Cocoon of Evolution (n° 72); Giant Soldier of Stone (n° 74); Krokodilus (n° 76); Grappler (n° 77); Megazowler (n° 79); Uraby (n° 80); Crawling Dragon #2 (n° 81); King of Yamimakai (n° 85); Dark Chimera (n° 87); Metal Guardian (n° 88); Catapult Turtle (n° 89); Mystic Horseman (n° 91); Rabid Horseman (n° 92); Crawling Dragon (n° 94); Dragon Zombie (n° 97); Tomozaurus (n° 105); That Which Feeds on Life (n° 112); Dark Gray (n° 113); Nightmare Scorpion (n° 116); Sleeping Lion (n° 121); Faith Bird (n° 125); Blue-eyed Silver Zombie (n° 139); Spiked Snail (n° 141); Larvas (n° 155); Dig Beak (n° 159); Big Eye (n° 171); Ancient Brain (n° 175); Monsturtle (n° 177); Dark Shade (n° 181); Lucky Trinket (n° 183); Turtle Tiger (n° 193); Mech Mole Zombie (n° 197); Air Marmot of Nefariousness (n° 202); Mabarrel (n° 204); Winged Cleaver (n° 209); Kumootoko (n° 221); Midnight Fiend (n° 222); Skull Stalker (n° 226); Madjinn Gunn (n° 232); Dark Assailant (n° 241); Water Element (n° 243); Meda Bat (n° 245); Prevent Rat (n° 255); Ground Attacker Bugroth (n° 275); Petit Moth (n° 278); Gatekeeper (n° 286); Psychic Kappa (n° 292); One-eyed Shield Dragon (n° 296); Cyber Soldier of Darkworld (n° 297); Kurama (n° 300); Takriminos (n° 353); Megasonic Eye (n° 355); Yamadron (n° 357); Zera The Mant (n° 360); Jirai Gumo (n° 367); Shadow Ghoul (n° 368); Wall Shadow (n° 369); Labyrinth Tank (n° 370); Dungeon Worm (n° 375); Ryu-kishin Powered (n° 377); Toon Alligator (n° 381); Rude Kaiser (n° 382); Parrot Dragon (n° 383); Harpie's Pet Dragon (n° 386); Pendulum Machine (n° 388); Launcher Spider (n° 390); Metalzoa (n° 392); Steel Scorpion (n° 394); Leghul (n° 397); Saber Slasher (n° 405); Yaiba Robo (n° 406); Machine King (n° 407); Giant Mech-soldier (n° 408); Metal Dragon (n° 409); Mechanical Spider (n° 410); Bat (n° 411); Giga-tech Wolf (n° 412); Cyber Soldier (n° 413); Shovel Crusher (n° 414); Mechanicalchacer (n° 415); Blocker (n° 416); Blast Juggler (n° 417); Golgoil (n° 418); Giganto (n° 419); Cyber-Stein (n° 420); Cyber Commander (n° 421); Jinzo #7 (n° 422); Dice Armadillo (n° 423); Sky Dragon (n° 424); Kaiser Dragon (n° 427); Metal Fish (n° 438); Mech Bass (n° 441); Ganigumo (n° 476); Alinsection (n° 477); Insect Soldiers of the Sky (n° 478); Cockroach Knight (n° 479); Kuwagata α (n° 480); Korogashi (n° 485); Kattapillar (n° 499); Man-eater Bug (n° 501); Gale Dogra (n° 506); Cyber Saurus (n° 508); Cannon Soldier (n° 512); Guardian of the Throne Room (n° 513); Brave Scizzar (n° 514); Kwagar Hercules (n° 533); Minar (n° 534); Kamakiriman (n° 535); Dharma Cannon (n° 544); Tyhone #2 (n° 555); Steel Ogre Grotto #1 (n° 557); Lesser Dragon (n° 561); Needle Worm (n° 562); B. Dragon Jungle King (n° 571); Giant Scorpion of the Tundra (n° 576); Patrol Robo (n° 580); Mechanical Snail (n° 585); Fairy Dragon (n° 603); Bladefly (n° 609); Hunter Spider (n° 614); Amphibious Bugroth (n° 639); Acid Crawler (n° 640); Disk Magician (n° 643); Royal Guard (n° 645); Machine Attacker (n° 648); Meteor Dragon (n° 712); Javelin Beetle (n° 717).

### 306 — Insect Armor with Laser Cannon
**Effet d’origine :** Augmente de **500 points l’ATK et de 500 points la DEF** d’un monstre compatible auquel tu appliques cet équipement. Le renforcement concerne ce monstre, pas tout ton terrain, et reste tant que ce monstre conserve son état sur le terrain. Un monstre incompatible ne reçoit pas le bonus.

**Conditions et limites :** Les mêmes monstres restent compatibles à toutes les raretés. Reverse Trap peut retourner le renforcement en pénalité. Le bonus d’équipement s’ajoute aux statistiques du monstre, y compris son éventuel bonus de rareté.

| Rareté | Effet total selon la rareté |
|---|---|
| Normale | Le monstre équipé gagne **500 ATK et 500 DEF**. |
| Rare | Le monstre équipé gagne **600 ATK et 600 DEF**. |
| Épique | Le monstre équipé gagne **800 ATK et 800 DEF**. |
| Légendaire | Le monstre équipé gagne **1000 ATK et 1000 DEF**. |
| Mythique | Le monstre équipé gagne **1300 ATK et 1300 DEF**. |

**Monstres compatibles dans le disque USA :** Big Insect (n° 49); Basic Insect (n° 50); Armored Lizard (n° 51); Hercules Beetle (n° 52); Killer Needle (n° 53); Gokibore (n° 54); Giant Flea (n° 55); Larvae Moth (n° 56); Great Moth (n° 57); Perfectly Ultimate Great Moth (n° 67); Cocoon of Evolution (n° 72); Nightmare Scorpion (n° 116); Spiked Snail (n° 141); Winged Cleaver (n° 209); Kumootoko (n° 221); Ground Attacker Bugroth (n° 275); Petit Moth (n° 278); Serpent Marauder (n° 285); Megasonic Eye (n° 355); Jirai Gumo (n° 367); Shadow Ghoul (n° 368); Wall Shadow (n° 369); Sanga of the Thunder (n° 371); Kazejin (n° 372); Suijin (n° 373); Gate Guardian (n° 374); Dungeon Worm (n° 375); Monster Tamer (n° 376); Ryu-kishin Powered (n° 377); Swordstalker (n° 378); Toon Alligator (n° 381); Rude Kaiser (n° 382); Dark Rabbit (n° 384); Pendulum Machine (n° 388); Giltia the D. Knight (n° 389); Zoa (n° 391); Metalzoa (n° 392); Leghul (n° 397); Ushi Oni (n° 401); Saber Slasher (n° 405); Machine King (n° 407); Giant Mech-soldier (n° 408); Cyber-Stein (n° 420); Cyber Commander (n° 421); Jinzo #7 (n° 422); Millennium Golem (n° 453); Destroyer Golem (n° 454); Barrel Rock (n° 455); Minomushi Warrior (n° 456); Bolt Penguin (n° 461); Armed Ninja (n° 469); Vermillion Sparrow (n° 473); Sea Kamen (n° 474); Ganigumo (n° 476); Alinsection (n° 477); Insect Soldiers of the Sky (n° 478); Cockroach Knight (n° 479); Kuwagata α (n° 480); Burglar (n° 481); Korogashi (n° 485); Musician King (n° 495); Wilmee (n° 496); Kattapillar (n° 499); Dragon Seeker (n° 500); Man-eater Bug (n° 501); D. Human (n° 502); Turtle Raccoon (n° 503); Prisman (n° 505); Gale Dogra (n° 506); Cyber Saurus (n° 508); Bean Soldier (n° 511); Cannon Soldier (n° 512); Guardian of the Throne Room (n° 513); The Bistro Butcher (n° 523); Kwagar Hercules (n° 533); Minar (n° 534); Kamakiriman (n° 535); Lava Battleguard (n° 554); Steel Ogre Grotto #1 (n° 557); Oscillo Hero (n° 559); Invader from Another Dimension (n° 560); Lesser Dragon (n° 561); Needle Worm (n° 562); Anthrosaurus (n° 568); Drooling Lizard (n° 569); Giant Scorpion of the Tundra (n° 576); Greenkappa (n° 586); Giant Turtle Who Feeds on Flames (n° 593); Rose Spectre of Dunn (n° 594); Ghoul with an Appetite (n° 596); Penguin Soldier (n° 602); Bladefly (n° 609); Electric Lizard (n° 610); Hiro's Shadow Scout (n° 611); Hunter Spider (n° 614); Rock Spirit (n° 619); Ancient Lizard Warrior (n° 630); Stone Ogre Grotto (n° 632); Night Lizard (n° 634); Amphibious Bugroth (n° 639); Acid Crawler (n° 640); Disk Magician (n° 643); Royal Guard (n° 645); Hyosube (n° 647); Machine Attacker (n° 648); Whiptail Crow (n° 650); Sengenjin (n° 703); Skull Guardian (n° 704); Skull Knight (n° 707); Cosmo Queen (n° 708); Psycho-Puppet (n° 715); Garma Sword (n° 716); Javelin Beetle (n° 717); Dokurorider (n° 719).

### 307 — Elf's Light
**Effet d’origine :** Augmente de **500 points l’ATK et de 500 points la DEF** d’un monstre compatible auquel tu appliques cet équipement. Le renforcement concerne ce monstre, pas tout ton terrain, et reste tant que ce monstre conserve son état sur le terrain. Un monstre incompatible ne reçoit pas le bonus.

**Conditions et limites :** Les mêmes monstres restent compatibles à toutes les raretés. Reverse Trap peut retourner le renforcement en pénalité. Le bonus d’équipement s’ajoute aux statistiques du monstre, y compris son éventuel bonus de rareté.

| Rareté | Effet total selon la rareté |
|---|---|
| Normale | Le monstre équipé gagne **500 ATK et 500 DEF**. |
| Rare | Le monstre équipé gagne **600 ATK et 600 DEF**. |
| Épique | Le monstre équipé gagne **800 ATK et 800 DEF**. |
| Légendaire | Le monstre équipé gagne **1000 ATK et 1000 DEF**. |
| Mythique | Le monstre équipé gagne **1300 ATK et 1300 DEF**. |

**Monstres compatibles dans le disque USA :** Mystical Elf (n° 2); Celtic Guardian (n° 41); Rogue Doll (n° 44); Oscillo Hero #2 (n° 45); Gyakutenno Megami (n° 90); Goddess with the Third Eye (n° 109); Faith Bird (n° 125); Orion the Battle King (n° 126); LaMoon (n° 128); Nemuriko (n° 129); Weather Control (n° 130); Monster Egg (n° 147); Spirit of the Harp (n° 170); Lucky Trinket (n° 183); Genin (n° 184); Key Mace (n° 192); Happy Lover (n° 198); Petit Angel (n° 208); Dryad (n° 216); Hourglass of Life (n° 229); Water Element (n° 243); Water Omotics (n° 249); Nekogal #1 (n° 252); Angelwitch (n° 253); Lunar Queen Elzaim (n° 260); Ancient Tree of Enlightenment (n° 273); Green Phantom King (n° 274); Ray & Temperature (n° 276); Mystical Sheep #2 (n° 282); Sonic Maid (n° 299); Flying Penguin (n° 361); Fairy's Gift (n° 363); Dancing Elf (n° 395); Ocubeam (n° 396); Magician of Faith (n° 428); Goddess of Whim (n° 429); Water Magician (n° 430); Ice Water (n° 431); Waterdragon Fairy (n° 432); Ancient Elf (n° 433); Beautiful Beast Trainer (n° 434); Water Girl (n° 435); Boo Koo (n° 486); Hoshiningen (n° 492); Rainbow Marine Mermaid (n° 494); Spirit of the Mountain (n° 525); Eldeen (n° 530); Mystical Sand (n° 531); Gemini Elf (n° 532); Skelengel (n° 540); Griggle (n° 547); Dark Elf (n° 551); Empress Judge (n° 572); Witch of the Black Forest (n° 574); Dark Witch (n° 582); Muse-A (n° 592); Key Mace #2 (n° 600); Tenderness (n° 601); Fairy Dragon (n° 603); Shining Friendship (n° 608); Lady of Faith (n° 612); Hourglass of Courage (n° 616); Warrior of Tradition (n° 618); Rock Spirit (n° 619); Succubus Knight (n° 621); Ill Witch (n° 622); Fairy of the Fountain (n° 625); Amazon of the Seas (n° 626); Nekogal #2 (n° 627); Witch's Apprentice (n° 628); Maiden of the Moonlight (n° 631); Winged Egg of New Life (n° 633); Queen's Double (n° 635); Queen of Autumn Leaves (n° 638); Invader of the Throne (n° 641); Hibikime (n° 649); Performance of Sword (n° 701); Cosmo Queen (n° 708); Magician of Black Chaos (n° 722).

### 308 — Beast Fangs
**Effet d’origine :** Augmente de **500 points l’ATK et de 500 points la DEF** d’un monstre compatible auquel tu appliques cet équipement. Le renforcement concerne ce monstre, pas tout ton terrain, et reste tant que ce monstre conserve son état sur le terrain. Un monstre incompatible ne reçoit pas le bonus.

**Conditions et limites :** Les mêmes monstres restent compatibles à toutes les raretés. Reverse Trap peut retourner le renforcement en pénalité. Le bonus d’équipement s’ajoute aux statistiques du monstre, y compris son éventuel bonus de rareté.

| Rareté | Effet total selon la rareté |
|---|---|
| Normale | Le monstre équipé gagne **500 ATK et 500 DEF**. |
| Rare | Le monstre équipé gagne **600 ATK et 600 DEF**. |
| Épique | Le monstre équipé gagne **800 ATK et 800 DEF**. |
| Légendaire | Le monstre équipé gagne **1000 ATK et 1000 DEF**. |
| Mythique | Le monstre équipé gagne **1300 ATK et 1300 DEF**. |

**Monstres compatibles dans le disque USA :** Hitotsu-me Giant (n° 3); Baby Dragon (n° 4); Ryu-kishin (n° 5); Feral Imp (n° 6); Winged Dragon #1 (n° 7); Shadow Specter (n° 9); Blackland Fire Dragon (n° 10); Sword Arm of Dragon (n° 11); Battle Steer (n° 14); Summoned Skull (n° 22); The Wicked Worm Beast (n° 23); Skull Servant (n° 24); Beaver Warrior (n° 27); Mountain Warrior (n° 29); Zombie Warrior (n° 30); Koumori Dragon (n° 31); Two-headed King Rex (n° 32); The Snake Hair (n° 36); Curse of Dragon (n° 39); Griffore (n° 46); Torike (n° 47); Sangan (n° 48); Big Insect (n° 49); Armored Lizard (n° 51); Hercules Beetle (n° 52); Mammoth Graveyard (n° 59); Great White (n° 60); Wolf (n° 61); Tiger Axe (n° 64); Silver Fang (n° 65); Garoozis (n° 68); Kairyu-shin (n° 73); Krokodilus (n° 76); Grappler (n° 77); Megazowler (n° 79); Uraby (n° 80); Crawling Dragon #2 (n° 81); King of Yamimakai (n° 85); Barox (n° 86); Dark Chimera (n° 87); Mystic Horseman (n° 91); Crawling Dragon (n° 94); Crass Clown (n° 95); Dragon Zombie (n° 97); Clown Zombie (n° 98); Pumpking the King of Ghosts (n° 99); Tomozaurus (n° 105); Dark Gray (n° 113); Sleeping Lion (n° 121); Dark Plant (n° 123); Orion the Battle King (n° 126); The 13th Grave (n° 132); Dragon Statue (n° 138); Spiked Snail (n° 141); Necrolancer the Timelord (n° 143); Akihiron (n° 150); Rhaimundos of the Red Sword (n° 151); Dokuroizo the Grim Reaper (n° 153); Man Eater (n° 158); Dig Beak (n° 159); Lisark (n° 163); Ancient Jar (n° 167); Darkfire Dragon (n° 168); Dark King of the Abyss (n° 169); Phantom Dewan (n° 179); Masked Clown (n° 182); Gate Deeg (n° 187); Synchar (n° 188); Fusionist (n° 189); Turtle Tiger (n° 193); Mech Mole Zombie (n° 197); Petit Dragon (n° 200); Frenzied Panda (n° 201); Air Marmot of Nefariousness (n° 202); Twin Long Rods #1 (n° 206); Kaminarikozou (n° 211); Meotoko (n° 212); Two-mouth Darkruler (n° 218); Midnight Fiend (n° 222); Roaring Ocean Snake (n° 223); Skull Stalker (n° 226); Wood Remains (n° 228); Rare Fish (n° 230); One Who Hunts Souls (n° 246); Master & Expert (n° 248); Nekogal #1 (n° 252); Prevent Rat (n° 255); Stone Armadiller (n° 257); Beastking of the Swamps (n° 258); The Furious Sea King (n° 265); Mystical Sheep #2 (n° 282); Serpent Marauder (n° 285); Ogre of the Black Shadow (n° 287); Wicked Dragon with the Ersatz Head (n° 298); Kurama (n° 300); Yaranzo (n° 351); Takriminos (n° 353); Stuffed Animal (n° 354); Super War-lion (n° 356); Yamadron (n° 357); Zera The Mant (n° 360); Jirai Gumo (n° 367); Dungeon Worm (n° 375); Ryu-kishin Powered (n° 377); Swordstalker (n° 378); Toon Alligator (n° 381); Rude Kaiser (n° 382); Dark Rabbit (n° 384); Bickuribox (n° 385); Harpie's Pet Dragon (n° 386); Zoa (n° 391); Metalzoa (n° 392); Zone Eater (n° 393); Leghul (n° 397); Ooguchi (n° 398); Emperor of the Land and Sea (n° 400); Leogun (n° 403); Tatsunootoshigo (n° 404); Metal Dragon (n° 409); Giga-tech Wolf (n° 412); Shovel Crusher (n° 414); Blast Juggler (n° 417); Cyber-Stein (n° 420); Dice Armadillo (n° 423); Sky Dragon (n° 424); Thunder Dragon (n° 425); Stone D. (n° 426); Kaiser Dragon (n° 427); Beautiful Beast Trainer (n° 434); Water Girl (n° 435); White Dolphin (n° 436); Metal Fish (n° 438); Bottom Dweller (n° 439); 7 Colored Fish (n° 440); Mech Bass (n° 441); Aqua Dragon (n° 442); Turu-Purun (n° 444); Aqua Snake (n° 446); Giant Red Seasnake (n° 447); Spike Seadra (n° 448); 30,000-Year White Turtle (n° 449); Stone Ghost (n° 457); Tripwire Beast (n° 459); Bolt Escargot (n° 460); Electric Snake (n° 463); Sea Kamen (n° 474); Alinsection (n° 477); Insect Soldiers of the Sky (n° 478); Kuwagata α (n° 480); Burglar (n° 481); Pragtical (n° 482); Garvas (n° 483); Flower Wolf (n° 487); Needle Ball (n° 490); Musician King (n° 495); Wilmee (n° 496); Yado Karu (n° 497); Morinphen (n° 498); Kattapillar (n° 499); Man-eater Bug (n° 501); Turtle Raccoon (n° 503); Gale Dogra (n° 506); Crazy Fish (n° 507); Cyber Saurus (n° 508); Muka Muka (n° 516); Sand Stone (n° 517); The Bistro Butcher (n° 523); Star Boy (n° 524); Neck Hunter (n° 526); Milus Radiant (n° 527); Togex (n° 528); Flame Cerebrus (n° 529); Kwagar Hercules (n° 533); Kamakiriman (n° 535); Mega Thunderball (n° 537); Corroding Shark (n° 539); Hane-Hane (n° 541); Misairuzame (n° 542); Tongyo (n° 543); Skelgon (n° 545); Wow Warrior (n° 546); Bone Mouse (n° 548); Behegon (n° 550); Winged Dragon #2 (n° 552); Lava Battleguard (n° 554); The Wandering Doomed (n° 556); Invader from Another Dimension (n° 560); Lesser Dragon (n° 561); Great Mammoth of Goldfine (n° 564); Yormungarde (n° 566); Darkworld Thorns (n° 567); Anthrosaurus (n° 568); Drooling Lizard (n° 569); Trakadon (n° 570); B. Dragon Jungle King (n° 571); Little D (n° 573); Ancient One of the Deep Forest (n° 575); Giant Scorpion of the Tundra (n° 576); Abyss Flower (n° 579); Mechanical Snail (n° 585); Mon Larvas (n° 587); Morphing Jar (n° 591); Giant Turtle Who Feeds on Flames (n° 593); Pale Beast (n° 597); Little Chimera (n° 598); Obese Marmot of Nefariousness (n° 604); Twin Long Rods #2 (n° 606); Great Bill (n° 607); Bladefly (n° 609); Electric Lizard (n° 610); Twin-headed Thunder Dragon (n° 613); Marine Beast (n° 617); Ill Witch (n° 622); High Tide Gyojin (n° 624); Nekogal #2 (n° 627); Armored Rat (n° 629); Mystical Sheep #1 (n° 642); Flame Viper (n° 644); Gruesome Goo (n° 646); Hungry Burger (n° 702); Sengenjin (n° 703); Skull Knight (n° 707); Meteor Dragon (n° 712); Firewing Pegasus (n° 714); Javelin Beetle (n° 717); Fortress Whale (n° 718).

### 309 — Steel Shell
**Effet d’origine :** Augmente de **500 points l’ATK et de 500 points la DEF** d’un monstre compatible auquel tu appliques cet équipement. Le renforcement concerne ce monstre, pas tout ton terrain, et reste tant que ce monstre conserve son état sur le terrain. Un monstre incompatible ne reçoit pas le bonus.

**Conditions et limites :** Les mêmes monstres restent compatibles à toutes les raretés. Reverse Trap peut retourner le renforcement en pénalité. Le bonus d’équipement s’ajoute aux statistiques du monstre, y compris son éventuel bonus de rareté.

| Rareté | Effet total selon la rareté |
|---|---|
| Normale | Le monstre équipé gagne **500 ATK et 500 DEF**. |
| Rare | Le monstre équipé gagne **600 ATK et 600 DEF**. |
| Épique | Le monstre équipé gagne **800 ATK et 800 DEF**. |
| Légendaire | Le monstre équipé gagne **1000 ATK et 1000 DEF**. |
| Mythique | Le monstre équipé gagne **1300 ATK et 1300 DEF**. |

**Monstres compatibles dans le disque USA :** Catapult Turtle (n° 89); Monsturtle (n° 177); Turtle Tiger (n° 193); Psychic Kappa (n° 292); Sea King Dragon (n° 443); 30,000-Year White Turtle (n° 449); Kappa Avenger (n° 450); Tripwire Beast (n° 459); Bolt Escargot (n° 460); Yado Karu (n° 497); Turtle Raccoon (n° 503); Boulder Tortoise (n° 518); Turtle Bird (n° 520); Giant Turtle Who Feeds on Flames (n° 593); Hyosube (n° 647); Crab Turtle (n° 710).

### 310 — Vile Germs
**Effet d’origine :** Augmente de **500 points l’ATK et de 500 points la DEF** d’un monstre compatible auquel tu appliques cet équipement. Le renforcement concerne ce monstre, pas tout ton terrain, et reste tant que ce monstre conserve son état sur le terrain. Un monstre incompatible ne reçoit pas le bonus.

**Conditions et limites :** Les mêmes monstres restent compatibles à toutes les raretés. Reverse Trap peut retourner le renforcement en pénalité. Le bonus d’équipement s’ajoute aux statistiques du monstre, y compris son éventuel bonus de rareté.

| Rareté | Effet total selon la rareté |
|---|---|
| Normale | Le monstre équipé gagne **500 ATK et 500 DEF**. |
| Rare | Le monstre équipé gagne **600 ATK et 600 DEF**. |
| Épique | Le monstre équipé gagne **800 ATK et 800 DEF**. |
| Légendaire | Le monstre équipé gagne **1000 ATK et 1000 DEF**. |
| Mythique | Le monstre équipé gagne **1300 ATK et 1300 DEF**. |

**Monstres compatibles dans le disque USA :** Mushroom Man (n° 8); Man-eating Plant (n° 75); Clown Zombie (n° 98); Dark Plant (n° 123); Firegrass (n° 157); Man Eater (n° 158); Arlownay (n° 180); Dryad (n° 216); Wood Remains (n° 228); Wodan the Resident of the Forest (n° 235); Yashinoki (n° 238); Ancient Tree of Enlightenment (n° 273); Green Phantom King (n° 274); Flower Wolf (n° 487); Rainbow Flower (n° 488); Barrel Lily (n° 489); Fungi of the Musk (n° 504); Laughing Flower (n° 510); Bean Soldier (n° 511); Griggle (n° 547); Mushroom Man #2 (n° 553); Darkworld Thorns (n° 567); Abyss Flower (n° 579); Living Vase (n° 588); Tentacle Plant (n° 589); Rose Spectre of Dunn (n° 594); Snakeyashi (n° 620); Trent (n° 637); Queen of Autumn Leaves (n° 638); Hungry Burger (n° 702).

### 311 — Black Pendant
**Effet d’origine :** Augmente de **500 points l’ATK et de 500 points la DEF** d’un monstre compatible auquel tu appliques cet équipement. Le renforcement concerne ce monstre, pas tout ton terrain, et reste tant que ce monstre conserve son état sur le terrain. Un monstre incompatible ne reçoit pas le bonus.

**Conditions et limites :** Les mêmes monstres restent compatibles à toutes les raretés. Reverse Trap peut retourner le renforcement en pénalité. Le bonus d’équipement s’ajoute aux statistiques du monstre, y compris son éventuel bonus de rareté.

| Rareté | Effet total selon la rareté |
|---|---|
| Normale | Le monstre équipé gagne **500 ATK et 500 DEF**. |
| Rare | Le monstre équipé gagne **600 ATK et 600 DEF**. |
| Épique | Le monstre équipé gagne **800 ATK et 800 DEF**. |
| Légendaire | Le monstre équipé gagne **1000 ATK et 1000 DEF**. |
| Mythique | Le monstre équipé gagne **1300 ATK et 1300 DEF**. |

**Monstres compatibles dans le disque USA :** Swamp Battleguard (n° 12); Time Wizard (n° 16); Right Leg of the Forbidden One (n° 17); Left Leg of the Forbidden One (n° 18); Right Arm of the Forbidden One (n° 19); Left Arm of the Forbidden One (n° 20); Exodia the Forbidden (n° 21); Summoned Skull (n° 22); The Wicked Worm Beast (n° 23); Skull Servant (n° 24); Horn Imp (n° 25); Saggi the Dark Clown (n° 34); Dark Magician (n° 35); The Snake Hair (n° 36); Dragon Piper (n° 40); Illusionist Faceless Mage (n° 42); Reaper of the Cards (n° 84); King of Yamimakai (n° 85); Crass Clown (n° 95); Clown Zombie (n° 98); Pumpking the King of Ghosts (n° 99); Wings of Wicked Flame (n° 101); Mask of Darkness (n° 102); Job-change Mirror (n° 103); Curtain of the Dark Ones (n° 104); Graveyard and the Hand of Invitation (n° 108); Doma The Angel of Silence (n° 111); That Which Feeds on Life (n° 112); Kamion Wizard (n° 115); The 13th Grave (n° 132); Toad Master (n° 140); Flame Manipulator (n° 142); Necrolancer the Timelord (n° 143); The Bewitching Phantom Thief (n° 145); The Shadow Who Controls the Dark (n° 148); Lord of the Lamp (n° 149); Dokuroizo the Grim Reaper (n° 153); Fire Reaper (n° 154); Lord of Zemia (n° 164); Mysterious Puppeteer (n° 166); Ancient Jar (n° 167); Dark King of the Abyss (n° 169); Dark Prisoner (n° 173); Ancient Brain (n° 175); Fire Eye (n° 176); Phantom Dewan (n° 179); Dark Shade (n° 181); Masked Clown (n° 182); Akakieisu (n° 190); Kaminarikozou (n° 211); Aqua Madoor (n° 213); Solitude (n° 219); Masked Sorcerer (n° 220); Trap Master (n° 224); Wood Clown (n° 231); Dark Titan of Terror (n° 233); Guardian of the Labyrinth (n° 236); Angelwitch (n° 253); Ancient Sorcerer (n° 259); Wicked Mirror (n° 261); Sectarian of Secrets (n° 268); Versago the Destroyer (n° 269); Megirus Light (n° 271); Gorgon Egg (n° 277); Holograh (n° 283); Tao the Chanter (n° 284); Yaranzo (n° 351); Fiend's Mirror (n° 365); Sanga of the Thunder (n° 371); Kazejin (n° 372); Suijin (n° 373); Gate Guardian (n° 374); La Jinn the Mystical Genie (n° 379); Bickuribox (n° 385); Mystic Lamp (n° 387); Ice Water (n° 431); Beautiful Beast Trainer (n° 434); Water Girl (n° 435); Turu-Purun (n° 444); Aqua Snake (n° 446); Millennium Golem (n° 453); Stone Ghost (n° 457); The Immortal of Thunder (n° 462); Magical Ghost (n° 470); Soul Hunter (n° 471); Musician King (n° 495); Morinphen (n° 498); Dragon Seeker (n° 500); Laughing Flower (n° 510); The Statue of Easter Island (n° 515); Neck Hunter (n° 526); Eldeen (n° 530); Mystical Sand (n° 531); Dark Elf (n° 551); Mushroom Man #2 (n° 553); Lava Battleguard (n° 554); The Wandering Doomed (n° 556); Pot the Trick (n° 558); Oscillo Hero (n° 559); Invader from Another Dimension (n° 560); Witch of the Black Forest (n° 574); Leo Wizard (n° 578); Morphing Jar (n° 591); Rose Spectre of Dunn (n° 594); Fiend Refrection #1 (n° 595); Ghoul with an Appetite (n° 596); Key Mace #2 (n° 600); Succubus Knight (n° 621); Witch's Apprentice (n° 628); Queen's Double (n° 635); Invader of the Throne (n° 641); Mystical Sheep #1 (n° 642); Disk Magician (n° 643); Hyosube (n° 647); Hibikime (n° 649); Skull Knight (n° 707); Chakra (n° 709); Psycho-Puppet (n° 715); Mask of Shine & Dark (n° 720); Magician of Black Chaos (n° 722).

### 312 — Silver Bow and Arrow
**Effet d’origine :** Augmente de **500 points l’ATK et de 500 points la DEF** d’un monstre compatible auquel tu appliques cet équipement. Le renforcement concerne ce monstre, pas tout ton terrain, et reste tant que ce monstre conserve son état sur le terrain. Un monstre incompatible ne reçoit pas le bonus.

**Conditions et limites :** Les mêmes monstres restent compatibles à toutes les raretés. Reverse Trap peut retourner le renforcement en pénalité. Le bonus d’équipement s’ajoute aux statistiques du monstre, y compris son éventuel bonus de rareté.

| Rareté | Effet total selon la rareté |
|---|---|
| Normale | Le monstre équipé gagne **500 ATK et 500 DEF**. |
| Rare | Le monstre équipé gagne **600 ATK et 600 DEF**. |
| Épique | Le monstre équipé gagne **800 ATK et 800 DEF**. |
| Légendaire | Le monstre équipé gagne **1000 ATK et 1000 DEF**. |
| Mythique | Le monstre équipé gagne **1300 ATK et 1300 DEF**. |

**Monstres compatibles dans le disque USA :** Mystical Elf (n° 2); Harpie Lady (n° 62); Harpie Lady Sisters (n° 63); Gyakutenno Megami (n° 90); Goddess with the Third Eye (n° 109); Doma The Angel of Silence (n° 111); Yamatano Dragon Scroll (n° 122); Orion the Battle King (n° 126); LaMoon (n° 128); Weather Control (n° 130); Mystical Capture Chain (n° 134); Spirit of the Harp (n° 170); Ancient Brain (n° 175); Fusionist (n° 189); Key Mace (n° 192); Happy Lover (n° 198); Petit Angel (n° 208); Dryad (n° 216); Hourglass of Life (n° 229); Angelwitch (n° 253); Lunar Queen Elzaim (n° 260); Wing Egg Elf (n° 264); Ray & Temperature (n° 276); Dancing Elf (n° 395); Ocubeam (n° 396); Magician of Faith (n° 428); Goddess of Whim (n° 429); Water Magician (n° 430); Ice Water (n° 431); Waterdragon Fairy (n° 432); Ancient Elf (n° 433); Beautiful Beast Trainer (n° 434); Water Girl (n° 435); Hoshiningen (n° 492); Rainbow Marine Mermaid (n° 494); Eldeen (n° 530); Mystical Sand (n° 531); Gemini Elf (n° 532); Skelengel (n° 540); Empress Judge (n° 572); Witch of the Black Forest (n° 574); Dark Witch (n° 582); Binding Chain (n° 584); Muse-A (n° 592); Rose Spectre of Dunn (n° 594); Key Mace #2 (n° 600); Tenderness (n° 601); Shining Friendship (n° 608); Lady of Faith (n° 612); Hourglass of Courage (n° 616); Warrior of Tradition (n° 618); Ill Witch (n° 622); Fairy of the Fountain (n° 625); Amazon of the Seas (n° 626); Nekogal #2 (n° 627); Witch's Apprentice (n° 628); Maiden of the Moonlight (n° 631); Winged Egg of New Life (n° 633); Queen's Double (n° 635); Queen of Autumn Leaves (n° 638); Invader of the Throne (n° 641); Hibikime (n° 649); Performance of Sword (n° 701); Cosmo Queen (n° 708).

### 313 — Horn of Light
**Effet d’origine :** Augmente de **500 points l’ATK et de 500 points la DEF** d’un monstre compatible auquel tu appliques cet équipement. Le renforcement concerne ce monstre, pas tout ton terrain, et reste tant que ce monstre conserve son état sur le terrain. Un monstre incompatible ne reçoit pas le bonus.

**Conditions et limites :** Les mêmes monstres restent compatibles à toutes les raretés. Reverse Trap peut retourner le renforcement en pénalité. Le bonus d’équipement s’ajoute aux statistiques du monstre, y compris son éventuel bonus de rareté.

| Rareté | Effet total selon la rareté |
|---|---|
| Normale | Le monstre équipé gagne **500 ATK et 500 DEF**. |
| Rare | Le monstre équipé gagne **600 ATK et 600 DEF**. |
| Épique | Le monstre équipé gagne **800 ATK et 800 DEF**. |
| Légendaire | Le monstre équipé gagne **1000 ATK et 1000 DEF**. |
| Mythique | Le monstre équipé gagne **1300 ATK et 1300 DEF**. |

**Monstres compatibles dans le disque USA :** Baby Dragon (n° 4); Winged Dragon #1 (n° 7); Battle Ox (n° 26); Beaver Warrior (n° 27); Rock Ogre Grotto #1 (n° 28); Mountain Warrior (n° 29); Two-headed King Rex (n° 32); Curse of Dragon (n° 39); Oscillo Hero #2 (n° 45); Torike (n° 47); Hercules Beetle (n° 52); Catapult Turtle (n° 89); Rabid Horseman (n° 92); Hero of the East (n° 110); Monsturtle (n° 177); Meotoko (n° 212); Master & Expert (n° 248); The Furious Sea King (n° 265); Mystical Sheep #2 (n° 282); Moon Envoy (n° 290); Dragoness the Wicked Knight (n° 294); Yamadron (n° 357); Parrot Dragon (n° 383); Leogun (n° 403); Machine King (n° 407); Metal Dragon (n° 409); Dice Armadillo (n° 423); Thunder Dragon (n° 425); Stone D. (n° 426); White Dolphin (n° 436); Aqua Dragon (n° 442); Sea King Dragon (n° 443); Minomushi Warrior (n° 456); Tripwire Beast (n° 459); Queen Bird (n° 468); Alinsection (n° 477); Cockroach Knight (n° 479); Korogashi (n° 485); Bean Soldier (n° 511); Togex (n° 528); Kwagar Hercules (n° 533); Kamakiriman (n° 535); Mega Thunderball (n° 537); Misairuzame (n° 542); Wow Warrior (n° 546); Winged Dragon #2 (n° 552); Oscillo Hero (n° 559); Needle Worm (n° 562); Ancient One of the Deep Forest (n° 575); Violent Rain (n° 599); Twin-headed Thunder Dragon (n° 613); Nekogal #2 (n° 627); Armored Rat (n° 629); Night Lizard (n° 634); Queen's Double (n° 635); Blue-winged Crown (n° 636); Hungry Burger (n° 702); Skull Guardian (n° 704); Javelin Beetle (n° 717).

### 314 — Horn of the Unicorn
**Effet d’origine :** Augmente de **500 points l’ATK et de 500 points la DEF** d’un monstre compatible auquel tu appliques cet équipement. Le renforcement concerne ce monstre, pas tout ton terrain, et reste tant que ce monstre conserve son état sur le terrain. Un monstre incompatible ne reçoit pas le bonus.

**Conditions et limites :** Les mêmes monstres restent compatibles à toutes les raretés. Reverse Trap peut retourner le renforcement en pénalité. Le bonus d’équipement s’ajoute aux statistiques du monstre, y compris son éventuel bonus de rareté.

| Rareté | Effet total selon la rareté |
|---|---|
| Normale | Le monstre équipé gagne **500 ATK et 500 DEF**. |
| Rare | Le monstre équipé gagne **600 ATK et 600 DEF**. |
| Épique | Le monstre équipé gagne **800 ATK et 800 DEF**. |
| Légendaire | Le monstre équipé gagne **1000 ATK et 1000 DEF**. |
| Mythique | Le monstre équipé gagne **1300 ATK et 1300 DEF**. |

**Monstres compatibles dans le disque USA :** Ryu-kishin (n° 5); Feral Imp (n° 6); Blackland Fire Dragon (n° 10); Swamp Battleguard (n° 12); Battle Steer (n° 14); Summoned Skull (n° 22); Horn Imp (n° 25); Larvae Moth (n° 56); Great Moth (n° 57); Mammoth Graveyard (n° 59); Perfectly Ultimate Great Moth (n° 67); Garoozis (n° 68); Megazowler (n° 79); Crawling Dragon #2 (n° 81); King of Yamimakai (n° 85); Barox (n° 86); Dark Chimera (n° 87); Zanki (n° 93); Job-change Mirror (n° 103); Dark Gray (n° 113); Dark Plant (n° 123); Necrolancer the Timelord (n° 143); Rhaimundos of the Red Sword (n° 151); Lord of Zemia (n° 164); Dark Prisoner (n° 173); Ancient Brain (n° 175); Claw Reacher (n° 178); Dark Shade (n° 181); Air Marmot of Nefariousness (n° 202); Mabarrel (n° 204); Solitude (n° 219); Masked Sorcerer (n° 220); Skull Stalker (n° 226); Wood Clown (n° 231); Guardian of the Labyrinth (n° 236); Vishwar Randi (n° 239); Meda Bat (n° 245); Unknown Warrior of Fiend (n° 267); Megasonic Eye (n° 355); Zera The Mant (n° 360); Rude Kaiser (n° 382); Bickuribox (n° 385); Harpie's Pet Dragon (n° 386); Pendulum Machine (n° 388); Zoa (n° 391); Metalzoa (n° 392); Leghul (n° 397); Ooguchi (n° 398); Emperor of the Land and Sea (n° 400); Ushi Oni (n° 401); Giant Mech-soldier (n° 408); Bat (n° 411); Cyber Soldier (n° 413); Blast Juggler (n° 417); Golgoil (n° 418); Cyber-Stein (n° 420); Turu-Purun (n° 444); Spike Seadra (n° 448); Stone Ghost (n° 457); Bolt Escargot (n° 460); Soul Hunter (n° 471); Sea Kamen (n° 474); Pragtical (n° 482); Needle Ball (n° 490); Yado Karu (n° 497); Dragon Seeker (n° 500); Man-eater Bug (n° 501); Gale Dogra (n° 506); Brave Scizzar (n° 514); Muka Muka (n° 516); Skullbird (n° 521); Neck Hunter (n° 526); Milus Radiant (n° 527); Minar (n° 534); Skelgon (n° 545); Lava Battleguard (n° 554); Invader from Another Dimension (n° 560); Lesser Dragon (n° 561); B. Dragon Jungle King (n° 571); Mechanical Snail (n° 585); Pale Beast (n° 597); Obese Marmot of Nefariousness (n° 604); Electric Lizard (n° 610); Hiro's Shadow Scout (n° 611); Succubus Knight (n° 621); Mystical Sheep #1 (n° 642); Flame Viper (n° 644); Skull Knight (n° 707); Cosmo Queen (n° 708); Garma Sword (n° 716); Dokurorider (n° 719); Mask of Shine & Dark (n° 720).

### 315 — Dragon Treasure
**Effet d’origine :** Augmente de **500 points l’ATK et de 500 points la DEF** d’un monstre compatible auquel tu appliques cet équipement. Le renforcement concerne ce monstre, pas tout ton terrain, et reste tant que ce monstre conserve son état sur le terrain. Un monstre incompatible ne reçoit pas le bonus.

**Conditions et limites :** Les mêmes monstres restent compatibles à toutes les raretés. Reverse Trap peut retourner le renforcement en pénalité. Le bonus d’équipement s’ajoute aux statistiques du monstre, y compris son éventuel bonus de rareté.

| Rareté | Effet total selon la rareté |
|---|---|
| Normale | Le monstre équipé gagne **500 ATK et 500 DEF**. |
| Rare | Le monstre équipé gagne **600 ATK et 600 DEF**. |
| Épique | Le monstre équipé gagne **800 ATK et 800 DEF**. |
| Légendaire | Le monstre équipé gagne **1000 ATK et 1000 DEF**. |
| Mythique | Le monstre équipé gagne **1300 ATK et 1300 DEF**. |

**Monstres compatibles dans le disque USA :** Blue-eyes White Dragon (n° 1); Baby Dragon (n° 4); Winged Dragon #1 (n° 7); Blackland Fire Dragon (n° 10); Sword Arm of Dragon (n° 11); Koumori Dragon (n° 31); Two-headed King Rex (n° 32); Gaia the Dragon Champion (n° 37); Curse of Dragon (n° 39); Griffore (n° 46); Torike (n° 47); Armored Lizard (n° 51); Garoozis (n° 68); Thousand Dragon (n° 69); Kairyu-shin (n° 73); Krokodilus (n° 76); Grappler (n° 77); Megazowler (n° 79); Uraby (n° 80); Crawling Dragon #2 (n° 81); Red-eyes B. Dragon (n° 82); Dark Chimera (n° 87); Crawling Dragon (n° 94); Dragon Zombie (n° 97); Tomozaurus (n° 105); Yamatano Dragon Scroll (n° 122); Dragon Statue (n° 138); Darkfire Dragon (n° 168); Synchar (n° 188); Petit Dragon (n° 200); B. Skull Dragon (n° 217); Midnight Fiend (n° 222); Roaring Ocean Snake (n° 223); Dragoness the Wicked Knight (n° 294); One-eyed Shield Dragon (n° 296); Wicked Dragon with the Ersatz Head (n° 298); Kurama (n° 300); Takriminos (n° 353); Yamadron (n° 357); Seiyaryu (n° 358); Zera The Mant (n° 360); Blue-eyes Ultimate Dragon (n° 380); Rude Kaiser (n° 382); Parrot Dragon (n° 383); Harpie's Pet Dragon (n° 386); Metal Dragon (n° 409); Sky Dragon (n° 424); Thunder Dragon (n° 425); Stone D. (n° 426); Kaiser Dragon (n° 427); Aqua Dragon (n° 442); Sea King Dragon (n° 443); Giant Red Seasnake (n° 447); Spike Seadra (n° 448); Air Eater (n° 472); Yado Karu (n° 497); Dragon Seeker (n° 500); D. Human (n° 502); Cyber Saurus (n° 508); Bracchio-raidus (n° 509); Skelgon (n° 545); Winged Dragon #2 (n° 552); Tyhone #2 (n° 555); Lesser Dragon (n° 561); Yormungarde (n° 566); Anthrosaurus (n° 568); Trakadon (n° 570); B. Dragon Jungle King (n° 571); Little D (n° 573); Fairy Dragon (n° 603); Twin-headed Thunder Dragon (n° 613); Tri-horned Dragon (n° 705); Serpent Night Dragon (n° 706); Mikazukinoyaiba (n° 711); Meteor Dragon (n° 712); Meteor B. Dragon (n° 713).

### 316 — Electro-whip
**Effet d’origine :** Augmente de **500 points l’ATK et de 500 points la DEF** d’un monstre compatible auquel tu appliques cet équipement. Le renforcement concerne ce monstre, pas tout ton terrain, et reste tant que ce monstre conserve son état sur le terrain. Un monstre incompatible ne reçoit pas le bonus.

**Conditions et limites :** Les mêmes monstres restent compatibles à toutes les raretés. Reverse Trap peut retourner le renforcement en pénalité. Le bonus d’équipement s’ajoute aux statistiques du monstre, y compris son éventuel bonus de rareté.

| Rareté | Effet total selon la rareté |
|---|---|
| Normale | Le monstre équipé gagne **500 ATK et 500 DEF**. |
| Rare | Le monstre équipé gagne **600 ATK et 600 DEF**. |
| Épique | Le monstre équipé gagne **800 ATK et 800 DEF**. |
| Légendaire | Le monstre équipé gagne **1000 ATK et 1000 DEF**. |
| Mythique | Le monstre équipé gagne **1300 ATK et 1300 DEF**. |

**Monstres compatibles dans le disque USA :** Mystical Elf (n° 2); Hitotsu-me Giant (n° 3); Feral Imp (n° 6); Swamp Battleguard (n° 12); Horn Imp (n° 25); Saggi the Dark Clown (n° 34); Oscillo Hero #2 (n° 45); Harpie Lady (n° 62); Harpie Lady Sisters (n° 63); Gyakutenno Megami (n° 90); Mystic Horseman (n° 91); Spirit of the Winds (n° 106); Goddess with the Third Eye (n° 109); White Magical Hat (n° 114); Dream Clown (n° 120); LaMoon (n° 128); Nemuriko (n° 129); The 13th Grave (n° 132); Fiend's Hand (n° 135); Mystery Hand (n° 137); Blue-eyed Silver Zombie (n° 139); Spiked Snail (n° 141); Flame Manipulator (n° 142); Necrolancer the Timelord (n° 143); Djinn the Watcher of the Wind (n° 144); Dark King of the Abyss (n° 169); Spirit of the Harp (n° 170); Arlownay (n° 180); Eyearmor (n° 185); Gate Deeg (n° 187); Synchar (n° 188); Key Mace (n° 192); Doron (n° 195); Twin Long Rods #1 (n° 206); Petit Angel (n° 208); Kaminarikozou (n° 211); Meotoko (n° 212); Dryad (n° 216); Trap Master (n° 224); Dark Titan of Terror (n° 233); Beautiful Headhuntress (n° 234); Haniwa (n° 237); Vishwar Randi (n° 239); Water Element (n° 243); Water Omotics (n° 249); Hyo (n° 250); Enchanting Mermaid (n° 251); Nekogal #1 (n° 252); Angelwitch (n° 253); Embryonic Beast (n° 254); Lunar Queen Elzaim (n° 260); Princess of Tsurugi (n° 266); Green Phantom King (n° 274); Protector of the Throne (n° 280); Mystic Clown (n° 281); Ogre of the Black Shadow (n° 287); Psychic Kappa (n° 292); Sonic Maid (n° 299); Yaranzo (n° 351); Kanan the Swordmistress (n° 352); Three-legged Zombies (n° 359); Fairy's Gift (n° 363); Monster Tamer (n° 376); Dancing Elf (n° 395); Magician of Faith (n° 428); Goddess of Whim (n° 429); Water Magician (n° 430); Ice Water (n° 431); Waterdragon Fairy (n° 432); Ancient Elf (n° 433); Beautiful Beast Trainer (n° 434); Water Girl (n° 435); Bolt Penguin (n° 461); Hoshiningen (n° 492); Rainbow Marine Mermaid (n° 494); Fungi of the Musk (n° 504); Sand Stone (n° 517); Star Boy (n° 524); Eldeen (n° 530); Mystical Sand (n° 531); Gemini Elf (n° 532); Dark Elf (n° 551); Empress Judge (n° 572); Witch of the Black Forest (n° 574); Dark Witch (n° 582); Tentacle Plant (n° 589); Muse-A (n° 592); Rose Spectre of Dunn (n° 594); Key Mace #2 (n° 600); Twin Long Rods #2 (n° 606); Lady of Faith (n° 612); Warrior of Tradition (n° 618); Succubus Knight (n° 621); Ill Witch (n° 622); Fairy of the Fountain (n° 625); Amazon of the Seas (n° 626); Nekogal #2 (n° 627); Witch's Apprentice (n° 628); Maiden of the Moonlight (n° 631); Queen's Double (n° 635); Queen of Autumn Leaves (n° 638); Invader of the Throne (n° 641); Hibikime (n° 649); Performance of Sword (n° 701); Cosmo Queen (n° 708).

### 317 — Cyber Shield
**Effet d’origine :** Augmente de **500 points l’ATK et de 500 points la DEF** d’un monstre compatible auquel tu appliques cet équipement. Le renforcement concerne ce monstre, pas tout ton terrain, et reste tant que ce monstre conserve son état sur le terrain. Un monstre incompatible ne reçoit pas le bonus.

**Conditions et limites :** Les mêmes monstres restent compatibles à toutes les raretés. Reverse Trap peut retourner le renforcement en pénalité. Le bonus d’équipement s’ajoute aux statistiques du monstre, y compris son éventuel bonus de rareté.

| Rareté | Effet total selon la rareté |
|---|---|
| Normale | Le monstre équipé gagne **500 ATK et 500 DEF**. |
| Rare | Le monstre équipé gagne **600 ATK et 600 DEF**. |
| Épique | Le monstre équipé gagne **800 ATK et 800 DEF**. |
| Légendaire | Le monstre équipé gagne **1000 ATK et 1000 DEF**. |
| Mythique | Le monstre équipé gagne **1300 ATK et 1300 DEF**. |

**Monstres compatibles dans le disque USA :** Mystical Elf (n° 2); Harpie Lady (n° 62); Harpie Lady Sisters (n° 63); Gyakutenno Megami (n° 90); Spirit of the Winds (n° 106); Goddess with the Third Eye (n° 109); LaMoon (n° 128); Nemuriko (n° 129); Spirit of the Harp (n° 170); Arlownay (n° 180); Key Mace (n° 192); Dryad (n° 216); Beautiful Headhuntress (n° 234); Vishwar Randi (n° 239); Water Element (n° 243); Water Omotics (n° 249); Enchanting Mermaid (n° 251); Angelwitch (n° 253); Lunar Queen Elzaim (n° 260); Princess of Tsurugi (n° 266); Protector of the Throne (n° 280); Sonic Maid (n° 299); Dancing Elf (n° 395); Magician of Faith (n° 428); Goddess of Whim (n° 429); Water Magician (n° 430); Ice Water (n° 431); Waterdragon Fairy (n° 432); Ancient Elf (n° 433); Beautiful Beast Trainer (n° 434); Water Girl (n° 435); Rainbow Marine Mermaid (n° 494); Eldeen (n° 530); Mystical Sand (n° 531); Gemini Elf (n° 532); Dark Elf (n° 551); Empress Judge (n° 572); Witch of the Black Forest (n° 574); Dark Witch (n° 582); Muse-A (n° 592); Rose Spectre of Dunn (n° 594); Key Mace #2 (n° 600); Lady of Faith (n° 612); Warrior of Tradition (n° 618); Succubus Knight (n° 621); Ill Witch (n° 622); Fairy of the Fountain (n° 625); Amazon of the Seas (n° 626); Nekogal #2 (n° 627); Witch's Apprentice (n° 628); Maiden of the Moonlight (n° 631); Queen's Double (n° 635); Queen of Autumn Leaves (n° 638); Invader of the Throne (n° 641); Hibikime (n° 649); Performance of Sword (n° 701); Cosmo Queen (n° 708).

### 318 — Elegant Egotist
**Effet d’origine :** Augmente de **500 points l’ATK et de 500 points la DEF** d’un monstre compatible auquel tu appliques cet équipement. Le renforcement concerne ce monstre, pas tout ton terrain, et reste tant que ce monstre conserve son état sur le terrain. Un monstre incompatible ne reçoit pas le bonus.

**Conditions et limites :** Les mêmes monstres restent compatibles à toutes les raretés. Reverse Trap peut retourner le renforcement en pénalité. Le bonus d’équipement s’ajoute aux statistiques du monstre, y compris son éventuel bonus de rareté.

| Rareté | Effet total selon la rareté |
|---|---|
| Normale | Le monstre équipé gagne **500 ATK et 500 DEF**. |
| Rare | Le monstre équipé gagne **600 ATK et 600 DEF**. |
| Épique | Le monstre équipé gagne **800 ATK et 800 DEF**. |
| Légendaire | Le monstre équipé gagne **1000 ATK et 1000 DEF**. |
| Mythique | Le monstre équipé gagne **1300 ATK et 1300 DEF**. |

**Monstres compatibles dans le disque USA :** Harpie Lady (n° 62).

### 319 — Mystical Moon
**Effet d’origine :** Augmente de **500 points l’ATK et de 500 points la DEF** d’un monstre compatible auquel tu appliques cet équipement. Le renforcement concerne ce monstre, pas tout ton terrain, et reste tant que ce monstre conserve son état sur le terrain. Un monstre incompatible ne reçoit pas le bonus.

**Conditions et limites :** Les mêmes monstres restent compatibles à toutes les raretés. Reverse Trap peut retourner le renforcement en pénalité. Le bonus d’équipement s’ajoute aux statistiques du monstre, y compris son éventuel bonus de rareté.

| Rareté | Effet total selon la rareté |
|---|---|
| Normale | Le monstre équipé gagne **500 ATK et 500 DEF**. |
| Rare | Le monstre équipé gagne **600 ATK et 600 DEF**. |
| Épique | Le monstre équipé gagne **800 ATK et 800 DEF**. |
| Légendaire | Le monstre équipé gagne **1000 ATK et 1000 DEF**. |
| Mythique | Le monstre équipé gagne **1300 ATK et 1300 DEF**. |

**Monstres compatibles dans le disque USA :** Feral Imp (n° 6); Shadow Specter (n° 9); Battle Steer (n° 14); The Wicked Worm Beast (n° 23); Battle Ox (n° 26); Beaver Warrior (n° 27); Mountain Warrior (n° 29); Griffore (n° 46); Torike (n° 47); Sangan (n° 48); Kuriboh (n° 58); Wolf (n° 61); Harpie Lady (n° 62); Harpie Lady Sisters (n° 63); Tiger Axe (n° 64); Silver Fang (n° 65); Barox (n° 86); Mystic Horseman (n° 91); Rabid Horseman (n° 92); Dark Gray (n° 113); Sleeping Lion (n° 121); Dig Beak (n° 159); Lisark (n° 163); Lord of Zemia (n° 164); Gate Deeg (n° 187); Synchar (n° 188); Fusionist (n° 189); Turtle Tiger (n° 193); Mech Mole Zombie (n° 197); Happy Lover (n° 198); Penguin Knight (n° 199); Frenzied Panda (n° 201); Air Marmot of Nefariousness (n° 202); Droll Bird (n° 207); Meotoko (n° 212); Solitude (n° 219); Rare Fish (n° 230); One Who Hunts Souls (n° 246); Master & Expert (n° 248); Hyo (n° 250); Nekogal #1 (n° 252); Prevent Rat (n° 255); Stone Armadiller (n° 257); Beastking of the Swamps (n° 258); Wing Egg Elf (n° 264); Mystical Sheep #2 (n° 282); Ogre of the Black Shadow (n° 287); Psychic Kappa (n° 292); Bio Plant (n° 295); Kurama (n° 300); Stuffed Animal (n° 354); Super War-lion (n° 356); Rude Kaiser (n° 382); Dark Rabbit (n° 384); Ocubeam (n° 396); Ushi Oni (n° 401); Leogun (n° 403); Tatsunootoshigo (n° 404); Giga-tech Wolf (n° 412); Shovel Crusher (n° 414); Sky Dragon (n° 424); Wing Eagle (n° 464); Punished Eagle (n° 465); Skull Red Bird (n° 466); Crimson Sunbird (n° 467); Queen Bird (n° 468); Burglar (n° 481); Garvas (n° 483); Flower Wolf (n° 487); Peacock (n° 491); Wilmee (n° 496); Turtle Raccoon (n° 503); Skullbird (n° 521); Monstrous Bird (n° 522); Neck Hunter (n° 526); Milus Radiant (n° 527); Togex (n° 528); Flame Cerebrus (n° 529); Niwatori (n° 538); Hane-Hane (n° 541); Bone Mouse (n° 548); Wretched Ghost of the Attic (n° 563); Ancient One of the Deep Forest (n° 575); Leo Wizard (n° 578); Takuhee (n° 581); Mon Larvas (n° 587); Fiend Refrection #1 (n° 595); Pale Beast (n° 597); Little Chimera (n° 598); Penguin Soldier (n° 602); Obese Marmot of Nefariousness (n° 604); Great Bill (n° 607); Hiro's Shadow Scout (n° 611); Marine Beast (n° 617); Nekogal #2 (n° 627); Sengenjin (n° 703); Firewing Pegasus (n° 714).

### 321 — Malevolent Nuzzler
**Effet d’origine :** Augmente de **500 points l’ATK et de 500 points la DEF** d’un monstre compatible auquel tu appliques cet équipement. Le renforcement concerne ce monstre, pas tout ton terrain, et reste tant que ce monstre conserve son état sur le terrain. Un monstre incompatible ne reçoit pas le bonus.

**Conditions et limites :** Les mêmes monstres restent compatibles à toutes les raretés. Reverse Trap peut retourner le renforcement en pénalité. Le bonus d’équipement s’ajoute aux statistiques du monstre, y compris son éventuel bonus de rareté.

| Rareté | Effet total selon la rareté |
|---|---|
| Normale | Le monstre équipé gagne **500 ATK et 500 DEF**. |
| Rare | Le monstre équipé gagne **600 ATK et 600 DEF**. |
| Épique | Le monstre équipé gagne **800 ATK et 800 DEF**. |
| Légendaire | Le monstre équipé gagne **1000 ATK et 1000 DEF**. |
| Mythique | Le monstre équipé gagne **1300 ATK et 1300 DEF**. |

**Monstres compatibles dans le disque USA :** Mystical Elf (n° 2); Hitotsu-me Giant (n° 3); Ryu-kishin (n° 5); Shadow Specter (n° 9); Summoned Skull (n° 22); Skull Servant (n° 24); Zombie Warrior (n° 30); Dragon Piper (n° 40); Illusionist Faceless Mage (n° 42); Sangan (n° 48); Harpie Lady (n° 62); Harpie Lady Sisters (n° 63); Gyakutenno Megami (n° 90); Crass Clown (n° 95); Armored Zombie (n° 96); Clown Zombie (n° 98); Pumpking the King of Ghosts (n° 99); Spirit of the Winds (n° 106); Goddess with the Third Eye (n° 109); Dark Plant (n° 123); LaMoon (n° 128); Nemuriko (n° 129); Spiked Snail (n° 141); Akihiron (n° 150); Larvas (n° 155); Man Eater (n° 158); Lord of Zemia (n° 164); Spirit of the Harp (n° 170); Arlownay (n° 180); Masked Clown (n° 182); Gate Deeg (n° 187); Synchar (n° 188); Key Mace (n° 192); Doron (n° 195); Mech Mole Zombie (n° 197); Happy Lover (n° 198); Frenzied Panda (n° 201); Twin Long Rods #1 (n° 206); Droll Bird (n° 207); Kaminarikozou (n° 211); Meotoko (n° 212); Dryad (n° 216); Kumootoko (n° 221); Beautiful Headhuntress (n° 234); Haniwa (n° 237); Vishwar Randi (n° 239); Water Element (n° 243); Water Omotics (n° 249); Enchanting Mermaid (n° 251); Nekogal #1 (n° 252); Angelwitch (n° 253); Lunar Queen Elzaim (n° 260); Princess of Tsurugi (n° 266); Green Phantom King (n° 274); Protector of the Throne (n° 280); Sonic Maid (n° 299); Kanan the Swordmistress (n° 352); Stuffed Animal (n° 354); Super War-lion (n° 356); Zera The Mant (n° 360); Fairy's Gift (n° 363); Ryu-kishin Powered (n° 377); Swordstalker (n° 378); Rude Kaiser (n° 382); Bickuribox (n° 385); Harpie's Pet Dragon (n° 386); Zoa (n° 391); Metalzoa (n° 392); Dancing Elf (n° 395); Leghul (n° 397); Ushi Oni (n° 401); Giga-tech Wolf (n° 412); Shovel Crusher (n° 414); Blast Juggler (n° 417); Magician of Faith (n° 428); Goddess of Whim (n° 429); Water Magician (n° 430); Ice Water (n° 431); Waterdragon Fairy (n° 432); Ancient Elf (n° 433); Beautiful Beast Trainer (n° 434); Water Girl (n° 435); Giant Red Seasnake (n° 447); Spike Seadra (n° 448); Kappa Avenger (n° 450); Stone Ghost (n° 457); Bolt Escargot (n° 460); Soul Hunter (n° 471); Sea Kamen (n° 474); Garvas (n° 483); Rainbow Marine Mermaid (n° 494); Musician King (n° 495); Wilmee (n° 496); Skullbird (n° 521); The Bistro Butcher (n° 523); Eldeen (n° 530); Mystical Sand (n° 531); Gemini Elf (n° 532); Corroding Shark (n° 539); Skelgon (n° 545); Wow Warrior (n° 546); Dark Elf (n° 551); Mushroom Man #2 (n° 553); Lava Battleguard (n° 554); Wretched Ghost of the Attic (n° 563); Darkworld Thorns (n° 567); Drooling Lizard (n° 569); Empress Judge (n° 572); Witch of the Black Forest (n° 574); Leo Wizard (n° 578); Abyss Flower (n° 579); Dark Witch (n° 582); Mechanical Snail (n° 585); Muse-A (n° 592); Rose Spectre of Dunn (n° 594); Pale Beast (n° 597); Key Mace #2 (n° 600); Lady of Faith (n° 612); Hunter Spider (n° 614); Warrior of Tradition (n° 618); Succubus Knight (n° 621); Ill Witch (n° 622); Fairy of the Fountain (n° 625); Amazon of the Seas (n° 626); Nekogal #2 (n° 627); Witch's Apprentice (n° 628); Maiden of the Moonlight (n° 631); Queen's Double (n° 635); Queen of Autumn Leaves (n° 638); Invader of the Throne (n° 641); Mystical Sheep #1 (n° 642); Hibikime (n° 649); Performance of Sword (n° 701); Hungry Burger (n° 702); Sengenjin (n° 703); Skull Knight (n° 707); Cosmo Queen (n° 708); Chakra (n° 709); Psycho-Puppet (n° 715); Garma Sword (n° 716); Magician of Black Chaos (n° 722).

### 322 — Violet Crystal
**Effet d’origine :** Augmente de **500 points l’ATK et de 500 points la DEF** d’un monstre compatible auquel tu appliques cet équipement. Le renforcement concerne ce monstre, pas tout ton terrain, et reste tant que ce monstre conserve son état sur le terrain. Un monstre incompatible ne reçoit pas le bonus.

**Conditions et limites :** Les mêmes monstres restent compatibles à toutes les raretés. Reverse Trap peut retourner le renforcement en pénalité. Le bonus d’équipement s’ajoute aux statistiques du monstre, y compris son éventuel bonus de rareté.

| Rareté | Effet total selon la rareté |
|---|---|
| Normale | Le monstre équipé gagne **500 ATK et 500 DEF**. |
| Rare | Le monstre équipé gagne **600 ATK et 600 DEF**. |
| Épique | Le monstre équipé gagne **800 ATK et 800 DEF**. |
| Légendaire | Le monstre équipé gagne **1000 ATK et 1000 DEF**. |
| Mythique | Le monstre équipé gagne **1300 ATK et 1300 DEF**. |

**Monstres compatibles dans le disque USA :** Ryu-kishin (n° 5); Shadow Specter (n° 9); Summoned Skull (n° 22); Skull Servant (n° 24); Zombie Warrior (n° 30); The Snake Hair (n° 36); Curse of Dragon (n° 39); Griffore (n° 46); Armored Zombie (n° 96); Dragon Zombie (n° 97); Clown Zombie (n° 98); Pumpking the King of Ghosts (n° 99); Mask of Darkness (n° 102); Job-change Mirror (n° 103); Curtain of the Dark Ones (n° 104); Graveyard and the Hand of Invitation (n° 108); That Which Feeds on Life (n° 112); Trial of Nightmares (n° 119); Yamatano Dragon Scroll (n° 122); The 13th Grave (n° 132); Fiend's Hand (n° 135); Mystery Hand (n° 137); Blue-eyed Silver Zombie (n° 139); Toad Master (n° 140); Spiked Snail (n° 141); Temple of Skulls (n° 146); Dokuroizo the Grim Reaper (n° 153); Fire Reaper (n° 154); Ancient Jar (n° 167); Dark Prisoner (n° 173); Phantom Dewan (n° 179); Mech Mole Zombie (n° 197); Phantom Ghost (n° 203); Flame Ghost (n° 215); Wood Remains (n° 228); Dark Assailant (n° 241); Embryonic Beast (n° 254); Wicked Mirror (n° 261); Sectarian of Secrets (n° 268); Versago the Destroyer (n° 269); Megirus Light (n° 271); Gorgon Egg (n° 277); Yaranzo (n° 351); Three-legged Zombies (n° 359); Fiend's Mirror (n° 365); Shadow Ghoul (n° 368); Wall Shadow (n° 369); Ryu-kishin Powered (n° 377); La Jinn the Mystical Genie (n° 379); Zoa (n° 391); Metalzoa (n° 392); Ooguchi (n° 398); Emperor of the Land and Sea (n° 400); Ushi Oni (n° 401); Turu-Purun (n° 444); Stone Ghost (n° 457); Magical Ghost (n° 470); Air Eater (n° 472); Pragtical (n° 482); Morinphen (n° 498); Skullbird (n° 521); Neck Hunter (n° 526); Corroding Shark (n° 539); Skelgon (n° 545); Bone Mouse (n° 548); The Wandering Doomed (n° 556); Great Mammoth of Goldfine (n° 564); Abyss Flower (n° 579); Greenkappa (n° 586); Morphing Jar (n° 591); Rose Spectre of Dunn (n° 594); Fiend Refrection #1 (n° 595); Ghoul with an Appetite (n° 596); Whiptail Crow (n° 650); Skull Knight (n° 707); Chakra (n° 709); Psycho-Puppet (n° 715); Dokurorider (n° 719).

### 323 — Book of Secret Arts
**Effet d’origine :** Augmente de **500 points l’ATK et de 500 points la DEF** d’un monstre compatible auquel tu appliques cet équipement. Le renforcement concerne ce monstre, pas tout ton terrain, et reste tant que ce monstre conserve son état sur le terrain. Un monstre incompatible ne reçoit pas le bonus.

**Conditions et limites :** Les mêmes monstres restent compatibles à toutes les raretés. Reverse Trap peut retourner le renforcement en pénalité. Le bonus d’équipement s’ajoute aux statistiques du monstre, y compris son éventuel bonus de rareté.

| Rareté | Effet total selon la rareté |
|---|---|
| Normale | Le monstre équipé gagne **500 ATK et 500 DEF**. |
| Rare | Le monstre équipé gagne **600 ATK et 600 DEF**. |
| Épique | Le monstre équipé gagne **800 ATK et 800 DEF**. |
| Légendaire | Le monstre équipé gagne **1000 ATK et 1000 DEF**. |
| Mythique | Le monstre équipé gagne **1300 ATK et 1300 DEF**. |

**Monstres compatibles dans le disque USA :** Mystical Elf (n° 2); Time Wizard (n° 16); Judge Man (n° 33); Celtic Guardian (n° 41); Illusionist Faceless Mage (n° 42); Rogue Doll (n° 44); Oscillo Hero #2 (n° 45); Harpie Lady (n° 62); Harpie Lady Sisters (n° 63); Gyakutenno Megami (n° 90); Spirit of the Winds (n° 106); Goddess with the Third Eye (n° 109); White Magical Hat (n° 114); Spirit of the Books (n° 117); Dream Clown (n° 120); Yamatano Dragon Scroll (n° 122); Orion the Battle King (n° 126); LaMoon (n° 128); Nemuriko (n° 129); Weather Control (n° 130); Mystical Capture Chain (n° 134); Flame Manipulator (n° 142); Necrolancer the Timelord (n° 143); Djinn the Watcher of the Wind (n° 144); The Bewitching Phantom Thief (n° 145); The Judgement Hand (n° 165); Spirit of the Harp (n° 170); Hurricail (n° 174); Lucky Trinket (n° 183); Genin (n° 184); Key Mace (n° 192); Happy Lover (n° 198); Petit Angel (n° 208); Aqua Madoor (n° 213); Dryad (n° 216); Wodan the Resident of the Forest (n° 235); Water Element (n° 243); Lunar Queen Elzaim (n° 260); Wing Egg Elf (n° 264); The Furious Sea King (n° 265); Wetha (n° 270); Ancient Tree of Enlightenment (n° 273); Green Phantom King (n° 274); Ray & Temperature (n° 276); Protector of the Throne (n° 280); Mystical Sheep #2 (n° 282); Psychic Kappa (n° 292); Sonic Maid (n° 299); Fairy's Gift (n° 363); Giltia the D. Knight (n° 389); Dancing Elf (n° 395); Ocubeam (n° 396); Magician of Faith (n° 428); Goddess of Whim (n° 429); Water Magician (n° 430); Waterdragon Fairy (n° 432); Ancient Elf (n° 433); Bottom Dweller (n° 439); Sea King Dragon (n° 443); Kaminari Attack (n° 458); Hoshiningen (n° 492); Maha Vailo (n° 493); Rainbow Marine Mermaid (n° 494); D. Human (n° 502); Spirit of the Mountain (n° 525); Gemini Elf (n° 532); Skelengel (n° 540); Empress Judge (n° 572); Ancient One of the Deep Forest (n° 575); Crow Goblin (n° 577); Dark Witch (n° 582); Weather Report (n° 583); Binding Chain (n° 584); Muse-A (n° 592); Tenderness (n° 601); Fairy Dragon (n° 603); Shining Friendship (n° 608); Lady of Faith (n° 612); Hourglass of Courage (n° 616); Rock Spirit (n° 619); Ill Witch (n° 622); Fairy of the Fountain (n° 625); Amazon of the Seas (n° 626); Maiden of the Moonlight (n° 631); Winged Egg of New Life (n° 633); Trent (n° 637); Queen of Autumn Leaves (n° 638); Sengenjin (n° 703); Cosmo Queen (n° 708); Mask of Shine & Dark (n° 720); Magician of Black Chaos (n° 722).

### 324 — Invigoration
**Effet d’origine :** Augmente de **500 points l’ATK et de 500 points la DEF** d’un monstre compatible auquel tu appliques cet équipement. Le renforcement concerne ce monstre, pas tout ton terrain, et reste tant que ce monstre conserve son état sur le terrain. Un monstre incompatible ne reçoit pas le bonus.

**Conditions et limites :** Les mêmes monstres restent compatibles à toutes les raretés. Reverse Trap peut retourner le renforcement en pénalité. Le bonus d’équipement s’ajoute aux statistiques du monstre, y compris son éventuel bonus de rareté.

| Rareté | Effet total selon la rareté |
|---|---|
| Normale | Le monstre équipé gagne **500 ATK et 500 DEF**. |
| Rare | Le monstre équipé gagne **600 ATK et 600 DEF**. |
| Épique | Le monstre équipé gagne **800 ATK et 800 DEF**. |
| Légendaire | Le monstre équipé gagne **1000 ATK et 1000 DEF**. |
| Mythique | Le monstre équipé gagne **1300 ATK et 1300 DEF**. |

**Monstres compatibles dans le disque USA :** Mushroom Man (n° 8); Shadow Specter (n° 9); Flame Swordsman (n° 15); Rock Ogre Grotto #1 (n° 28); Dragon Piper (n° 40); Oscillo Hero #2 (n° 45); Kuriboh (n° 58); Fiend Kraken (n° 70); Jellyfish (n° 71); Kairyu-shin (n° 73); Giant Soldier of Stone (n° 74); Man-eating Plant (n° 75); Castle of Dark Illusions (n° 83); Dragon Zombie (n° 97); Pumpking the King of Ghosts (n° 99); Wings of Wicked Flame (n° 101); Mask of Darkness (n° 102); Job-change Mirror (n° 103); Curtain of the Dark Ones (n° 104); Spirit of the Winds (n° 106); Graveyard and the Hand of Invitation (n° 108); Trial of Nightmares (n° 119); Yamatano Dragon Scroll (n° 122); Dark Plant (n° 123); Weather Control (n° 130); Charubin the Fire Knight (n° 133); Mystical Capture Chain (n° 134); Fiend's Hand (n° 135); Mystery Hand (n° 137); Flame Manipulator (n° 142); Temple of Skulls (n° 146); Monster Egg (n° 147); Akihiron (n° 150); The Melting Red Shadow (n° 152); Firegrass (n° 157); Tainted Wisdom (n° 162); Ancient Jar (n° 167); Darkfire Dragon (n° 168); Big Eye (n° 171); Dark Prisoner (n° 173); Hurricail (n° 174); Fire Eye (n° 176); Genin (n° 184); LaLa Li-oon (n° 191); Dorover (n° 205); Hinotama Soul (n° 210); Kaminarikozou (n° 211); Kagemusha of the Blue Flame (n° 214); Flame Ghost (n° 215); Fiend Sword (n° 225); Hitodenchak (n° 227); Wood Remains (n° 228); Hourglass of Life (n° 229); Haniwa (n° 237); Yashinoki (n° 238); The Drdek (n° 240); Candle of Fate (n° 242); Dissolverock (n° 244); Stone Armadiller (n° 257); Beastking of the Swamps (n° 258); Wicked Mirror (n° 261); Rock Ogre Grotto #2 (n° 263); Wing Egg Elf (n° 264); Ancient Tree of Enlightenment (n° 273); Ground Attacker Bugroth (n° 275); Ray & Temperature (n° 276); Gorgon Egg (n° 277); King Fog (n° 279); Holograh (n° 283); Change Slime (n° 289); Fireyarou (n° 291); Yaranzo (n° 351); Stuffed Animal (n° 354); Megasonic Eye (n° 355); Millennium Shield (n° 362); Fiend's Mirror (n° 365); Labyrinth Wall (n° 366); Jirai Gumo (n° 367); Wall Shadow (n° 369); Sanga of the Thunder (n° 371); Gate Guardian (n° 374); La Jinn the Mystical Genie (n° 379); Mystic Lamp (n° 387); Giltia the D. Knight (n° 389); Emperor of the Land and Sea (n° 400); Monster Eye (n° 402); Bat (n° 411); Thunder Dragon (n° 425); Stone D. (n° 426); Magician of Faith (n° 428); Goddess of Whim (n° 429); Millennium Golem (n° 453); Destroyer Golem (n° 454); Barrel Rock (n° 455); Minomushi Warrior (n° 456); Stone Ghost (n° 457); Kaminari Attack (n° 458); Tripwire Beast (n° 459); Bolt Escargot (n° 460); Bolt Penguin (n° 461); The Immortal of Thunder (n° 462); Electric Snake (n° 463); Magical Ghost (n° 470); Boo Koo (n° 486); Prisman (n° 505); The Statue of Easter Island (n° 515); Muka Muka (n° 516); Sand Stone (n° 517); Boulder Tortoise (n° 518); Flame Cerebrus (n° 529); Mystical Sand (n° 531); Mega Thunderball (n° 537); Pot the Trick (n° 558); Morphing Jar (n° 591); Electric Lizard (n° 610); Twin-headed Thunder Dragon (n° 613); The Thing That Hides in the Mud (n° 623); Armored Rat (n° 629); Ancient Lizard Warrior (n° 630); Stone Ogre Grotto (n° 632); Flame Viper (n° 644).

### 325 — Machine Conversion Factory
**Effet d’origine :** Augmente de **500 points l’ATK et de 500 points la DEF** d’un monstre compatible auquel tu appliques cet équipement. Le renforcement concerne ce monstre, pas tout ton terrain, et reste tant que ce monstre conserve son état sur le terrain. Un monstre incompatible ne reçoit pas le bonus.

**Conditions et limites :** Les mêmes monstres restent compatibles à toutes les raretés. Reverse Trap peut retourner le renforcement en pénalité. Le bonus d’équipement s’ajoute aux statistiques du monstre, y compris son éventuel bonus de rareté.

| Rareté | Effet total selon la rareté |
|---|---|
| Normale | Le monstre équipé gagne **500 ATK et 500 DEF**. |
| Rare | Le monstre équipé gagne **600 ATK et 600 DEF**. |
| Épique | Le monstre équipé gagne **800 ATK et 800 DEF**. |
| Légendaire | Le monstre équipé gagne **1000 ATK et 1000 DEF**. |
| Mythique | Le monstre équipé gagne **1300 ATK et 1300 DEF**. |

**Monstres compatibles dans le disque USA :** Swamp Battleguard (n° 12); Tyhone (n° 13); Catapult Turtle (n° 89); Ancient Tool (n° 124); M-warrior #1 (n° 160); M-warrior #2 (n° 161); Mabarrel (n° 204); Trap Master (n° 224); Madjinn Gunn (n° 232); Ground Attacker Bugroth (n° 275); Holograh (n° 283); Gatekeeper (n° 286); Change Slime (n° 289); Cyber Soldier of Darkworld (n° 297); Megasonic Eye (n° 355); Labyrinth Tank (n° 370); Bickuribox (n° 385); Pendulum Machine (n° 388); Launcher Spider (n° 390); Metalzoa (n° 392); Steel Scorpion (n° 394); Monster Eye (n° 402); Saber Slasher (n° 405); Yaiba Robo (n° 406); Machine King (n° 407); Giant Mech-soldier (n° 408); Metal Dragon (n° 409); Mechanical Spider (n° 410); Bat (n° 411); Giga-tech Wolf (n° 412); Cyber Soldier (n° 413); Shovel Crusher (n° 414); Mechanicalchacer (n° 415); Blocker (n° 416); Blast Juggler (n° 417); Golgoil (n° 418); Giganto (n° 419); Cyber-Stein (n° 420); Cyber Commander (n° 421); Jinzo #7 (n° 422); Dice Armadillo (n° 423); Metal Fish (n° 438); Mech Bass (n° 441); Barrel Rock (n° 455); Air Eater (n° 472); Needle Ball (n° 490); Cyber Saurus (n° 508); Cannon Soldier (n° 512); Guardian of the Throne Room (n° 513); Brave Scizzar (n° 514); Mega Thunderball (n° 537); Misairuzame (n° 542); Dharma Cannon (n° 544); Steel Ogre Grotto #1 (n° 557); Patrol Robo (n° 580); Mechanical Snail (n° 585); Amphibious Bugroth (n° 639); Disk Magician (n° 643); Royal Guard (n° 645); Machine Attacker (n° 648); Fortress Whale (n° 718); Dokurorider (n° 719).

### 326 — Raise Body Heat
**Effet d’origine :** Augmente de **500 points l’ATK et de 500 points la DEF** d’un monstre compatible auquel tu appliques cet équipement. Le renforcement concerne ce monstre, pas tout ton terrain, et reste tant que ce monstre conserve son état sur le terrain. Un monstre incompatible ne reçoit pas le bonus.

**Conditions et limites :** Les mêmes monstres restent compatibles à toutes les raretés. Reverse Trap peut retourner le renforcement en pénalité. Le bonus d’équipement s’ajoute aux statistiques du monstre, y compris son éventuel bonus de rareté.

| Rareté | Effet total selon la rareté |
|---|---|
| Normale | Le monstre équipé gagne **500 ATK et 500 DEF**. |
| Rare | Le monstre équipé gagne **600 ATK et 600 DEF**. |
| Épique | Le monstre équipé gagne **800 ATK et 800 DEF**. |
| Légendaire | Le monstre équipé gagne **1000 ATK et 1000 DEF**. |
| Mythique | Le monstre équipé gagne **1300 ATK et 1300 DEF**. |

**Monstres compatibles dans le disque USA :** Mushroom Man (n° 8); Sword Arm of Dragon (n° 11); Tyhone (n° 13); Flame Swordsman (n° 15); Koumori Dragon (n° 31); Two-headed King Rex (n° 32); Griffore (n° 46); Torike (n° 47); Big Insect (n° 49); Basic Insect (n° 50); Armored Lizard (n° 51); Hercules Beetle (n° 52); Killer Needle (n° 53); Gokibore (n° 54); Giant Flea (n° 55); Larvae Moth (n° 56); Great Moth (n° 57); Mammoth Graveyard (n° 59); Perfectly Ultimate Great Moth (n° 67); Garoozis (n° 68); Krokodilus (n° 76); Grappler (n° 77); Megazowler (n° 79); Uraby (n° 80); Crawling Dragon #2 (n° 81); Dark Chimera (n° 87); Wings of Wicked Flame (n° 101); Tomozaurus (n° 105); Nightmare Scorpion (n° 116); Ancient Tool (n° 124); Flame Manipulator (n° 142); Akihiron (n° 150); Rhaimundos of the Red Sword (n° 151); The Melting Red Shadow (n° 152); Fire Reaper (n° 154); Firegrass (n° 157); Dig Beak (n° 159); Big Eye (n° 171); Fire Eye (n° 176); Synchar (n° 188); Doron (n° 195); Air Marmot of Nefariousness (n° 202); Mabarrel (n° 204); Twin Long Rods #1 (n° 206); Winged Cleaver (n° 209); Hinotama Soul (n° 210); Dryad (n° 216); Two-mouth Darkruler (n° 218); Hitodenchak (n° 227); Candle of Fate (n° 242); Dissolverock (n° 244); Rock Ogre Grotto #2 (n° 263); Wing Egg Elf (n° 264); Mavelus (n° 272); Ground Attacker Bugroth (n° 275); Gorgon Egg (n° 277); Petit Moth (n° 278); Serpent Marauder (n° 285); Gatekeeper (n° 286); Change Slime (n° 289); Fireyarou (n° 291); Cyber Soldier of Darkworld (n° 297); Yaranzo (n° 351); Stuffed Animal (n° 354); Megasonic Eye (n° 355); Yamadron (n° 357); Jirai Gumo (n° 367); Dungeon Worm (n° 375); Toon Alligator (n° 381); Launcher Spider (n° 390); Leghul (n° 397); Emperor of the Land and Sea (n° 400); Machine King (n° 407); Metal Dragon (n° 409); Blast Juggler (n° 417); Crimson Sunbird (n° 467); Armed Ninja (n° 469); Vermillion Sparrow (n° 473); Sinister Serpent (n° 475); Ganigumo (n° 476); Alinsection (n° 477); Insect Soldiers of the Sky (n° 478); Cockroach Knight (n° 479); Kuwagata α (n° 480); Pragtical (n° 482); Korogashi (n° 485); Kattapillar (n° 499); Man-eater Bug (n° 501); Gale Dogra (n° 506); Bracchio-raidus (n° 509); Fire Kraken (n° 519); Kwagar Hercules (n° 533); Minar (n° 534); Kamakiriman (n° 535); Mechaleon (n° 536); Tyhone #2 (n° 555); Needle Worm (n° 562); Yormungarde (n° 566); Anthrosaurus (n° 568); Drooling Lizard (n° 569); Trakadon (n° 570); Little D (n° 573); Giant Scorpion of the Tundra (n° 576); Beaked Snake (n° 590); Bladefly (n° 609); Hunter Spider (n° 614); Ancient Lizard Warrior (n° 630); Acid Crawler (n° 640); Flame Viper (n° 644); Firewing Pegasus (n° 714); Javelin Beetle (n° 717).

### 327 — Follow Wind
**Effet d’origine :** Augmente de **500 points l’ATK et de 500 points la DEF** d’un monstre compatible auquel tu appliques cet équipement. Le renforcement concerne ce monstre, pas tout ton terrain, et reste tant que ce monstre conserve son état sur le terrain. Un monstre incompatible ne reçoit pas le bonus.

**Conditions et limites :** Les mêmes monstres restent compatibles à toutes les raretés. Reverse Trap peut retourner le renforcement en pénalité. Le bonus d’équipement s’ajoute aux statistiques du monstre, y compris son éventuel bonus de rareté.

| Rareté | Effet total selon la rareté |
|---|---|
| Normale | Le monstre équipé gagne **500 ATK et 500 DEF**. |
| Rare | Le monstre équipé gagne **600 ATK et 600 DEF**. |
| Épique | Le monstre équipé gagne **800 ATK et 800 DEF**. |
| Légendaire | Le monstre équipé gagne **1000 ATK et 1000 DEF**. |
| Mythique | Le monstre équipé gagne **1300 ATK et 1300 DEF**. |

**Monstres compatibles dans le disque USA :** Baby Dragon (n° 4); Ryu-kishin (n° 5); Feral Imp (n° 6); Winged Dragon #1 (n° 7); Blackland Fire Dragon (n° 10); Tyhone (n° 13); Skull Servant (n° 24); Koumori Dragon (n° 31); Curse of Dragon (n° 39); Rogue Doll (n° 44); Hercules Beetle (n° 52); Killer Needle (n° 53); Great Moth (n° 57); Harpie Lady (n° 62); Harpie Lady Sisters (n° 63); Perfectly Ultimate Great Moth (n° 67); Castle of Dark Illusions (n° 83); Reaper of the Cards (n° 84); Barox (n° 86); Dark Chimera (n° 87); Wings of Wicked Flame (n° 101); Spirit of the Winds (n° 106); Doma The Angel of Silence (n° 111); That Which Feeds on Life (n° 112); Dark Gray (n° 113); Spirit of the Books (n° 117); Faith Bird (n° 125); LaMoon (n° 128); Dragon Statue (n° 138); Djinn the Watcher of the Wind (n° 144); Fire Reaper (n° 154); Larvas (n° 155); Lisark (n° 163); Darkfire Dragon (n° 168); Dark Shade (n° 181); Lucky Trinket (n° 183); Fiend Refrection #2 (n° 186); Fusionist (n° 189); Happy Lover (n° 198); Petit Dragon (n° 200); Air Marmot of Nefariousness (n° 202); Phantom Ghost (n° 203); Mabarrel (n° 204); Droll Bird (n° 207); Petit Angel (n° 208); Winged Cleaver (n° 209); Hinotama Soul (n° 210); Flame Ghost (n° 215); Dryad (n° 216); Midnight Fiend (n° 222); Hourglass of Life (n° 229); Nekogal #1 (n° 252); Angelwitch (n° 253); Embryonic Beast (n° 254); Lunar Queen Elzaim (n° 260); Wing Egg Elf (n° 264); Sectarian of Secrets (n° 268); Versago the Destroyer (n° 269); Mavelus (n° 272); Ray & Temperature (n° 276); King Fog (n° 279); Dragoness the Wicked Knight (n° 294); One-eyed Shield Dragon (n° 296); Wicked Dragon with the Ersatz Head (n° 298); Kurama (n° 300); Takriminos (n° 353); Flying Penguin (n° 361); Fairy's Gift (n° 363); Kazejin (n° 372); Gate Guardian (n° 374); La Jinn the Mystical Genie (n° 379); Parrot Dragon (n° 383); Harpie's Pet Dragon (n° 386); Dancing Elf (n° 395); Ocubeam (n° 396); Monster Eye (n° 402); Metal Dragon (n° 409); Bat (n° 411); Giga-tech Wolf (n° 412); Mechanicalchacer (n° 415); Sky Dragon (n° 424); Thunder Dragon (n° 425); Kaiser Dragon (n° 427); Aqua Dragon (n° 442); Stone Ghost (n° 457); Wing Eagle (n° 464); Punished Eagle (n° 465); Skull Red Bird (n° 466); Crimson Sunbird (n° 467); Queen Bird (n° 468); Magical Ghost (n° 470); Soul Hunter (n° 471); Air Eater (n° 472); Sinister Serpent (n° 475); Insect Soldiers of the Sky (n° 478); Kuwagata α (n° 480); Garvas (n° 483); Peacock (n° 491); Hoshiningen (n° 492); Maha Vailo (n° 493); Morinphen (n° 498); Dragon Seeker (n° 500); Gale Dogra (n° 506); Crazy Fish (n° 507); Turtle Bird (n° 520); Skullbird (n° 521); Monstrous Bird (n° 522); Neck Hunter (n° 526); Niwatori (n° 538); Skelengel (n° 540); Hane-Hane (n° 541); Skelgon (n° 545); Winged Dragon #2 (n° 552); Tyhone #2 (n° 555); Wretched Ghost of the Attic (n° 563); Crow Goblin (n° 577); Takuhee (n° 581); Dark Witch (n° 582); Fiend Refrection #1 (n° 595); Little Chimera (n° 598); Tenderness (n° 601); Fairy Dragon (n° 603); Obese Marmot of Nefariousness (n° 604); Shining Friendship (n° 608); Bladefly (n° 609); Hourglass of Courage (n° 616); Ill Witch (n° 622); Nekogal #2 (n° 627); Witch's Apprentice (n° 628); Maiden of the Moonlight (n° 631); Winged Egg of New Life (n° 633); Blue-winged Crown (n° 636); Disk Magician (n° 643); Whiptail Crow (n° 650); Chakra (n° 709); Meteor Dragon (n° 712); Firewing Pegasus (n° 714); Mask of Shine & Dark (n° 720).

### 328 — Power of Kaishin
**Effet d’origine :** Augmente de **500 points l’ATK et de 500 points la DEF** d’un monstre compatible auquel tu appliques cet équipement. Le renforcement concerne ce monstre, pas tout ton terrain, et reste tant que ce monstre conserve son état sur le terrain. Un monstre incompatible ne reçoit pas le bonus.

**Conditions et limites :** Les mêmes monstres restent compatibles à toutes les raretés. Reverse Trap peut retourner le renforcement en pénalité. Le bonus d’équipement s’ajoute aux statistiques du monstre, y compris son éventuel bonus de rareté.

| Rareté | Effet total selon la rareté |
|---|---|
| Normale | Le monstre équipé gagne **500 ATK et 500 DEF**. |
| Rare | Le monstre équipé gagne **600 ATK et 600 DEF**. |
| Épique | Le monstre équipé gagne **800 ATK et 800 DEF**. |
| Légendaire | Le monstre équipé gagne **1000 ATK et 1000 DEF**. |
| Mythique | Le monstre équipé gagne **1300 ATK et 1300 DEF**. |

**Monstres compatibles dans le disque USA :** Oscillo Hero #2 (n° 45); Great White (n° 60); Fiend Kraken (n° 70); Jellyfish (n° 71); Kairyu-shin (n° 73); Krokodilus (n° 76); Catapult Turtle (n° 89); Octoberser (n° 131); Fiend's Hand (n° 135); Toad Master (n° 140); Spiked Snail (n° 141); Akihiron (n° 150); The Melting Red Shadow (n° 152); Big Eye (n° 171); Monsturtle (n° 177); Turtle Tiger (n° 193); Terra the Terrible (n° 194); Doron (n° 195); Arma Knight (n° 196); Penguin Knight (n° 199); Dorover (n° 205); Twin Long Rods #1 (n° 206); Kaminarikozou (n° 211); Aqua Madoor (n° 213); Roaring Ocean Snake (n° 223); Hitodenchak (n° 227); Rare Fish (n° 230); Water Element (n° 243); Root Water (n° 247); Water Omotics (n° 249); Enchanting Mermaid (n° 251); Beastking of the Swamps (n° 258); The Furious Sea King (n° 265); Wetha (n° 270); Change Slime (n° 289); Psychic Kappa (n° 292); Takriminos (n° 353); Flying Penguin (n° 361); Suijin (n° 373); Gate Guardian (n° 374); Toon Alligator (n° 381); Zone Eater (n° 393); Ooguchi (n° 398); Emperor of the Land and Sea (n° 400); Tatsunootoshigo (n° 404); Water Magician (n° 430); Ice Water (n° 431); Waterdragon Fairy (n° 432); Water Girl (n° 435); White Dolphin (n° 436); Deepsea Shark (n° 437); Metal Fish (n° 438); Bottom Dweller (n° 439); 7 Colored Fish (n° 440); Mech Bass (n° 441); Aqua Dragon (n° 442); Sea King Dragon (n° 443); Turu-Purun (n° 444); Guardian of the Sea (n° 445); Aqua Snake (n° 446); Giant Red Seasnake (n° 447); Spike Seadra (n° 448); 30,000-Year White Turtle (n° 449); Kappa Avenger (n° 450); Kanikabuto (n° 451); Zarigun (n° 452); Bolt Escargot (n° 460); Bolt Penguin (n° 461); Electric Snake (n° 463); Armed Ninja (n° 469); Sea Kamen (n° 474); Sinister Serpent (n° 475); Ameba (n° 484); Rainbow Marine Mermaid (n° 494); Yado Karu (n° 497); Morinphen (n° 498); Turtle Raccoon (n° 503); Fungi of the Musk (n° 504); Crazy Fish (n° 507); Boulder Tortoise (n° 518); Fire Kraken (n° 519); Turtle Bird (n° 520); Star Boy (n° 524); Mechaleon (n° 536); Corroding Shark (n° 539); Misairuzame (n° 542); Tongyo (n° 543); Wow Warrior (n° 546); Frog The Jam (n° 549); Behegon (n° 550); Man-eating Black Shark (n° 565); Yormungarde (n° 566); Drooling Lizard (n° 569); Weather Report (n° 583); Beaked Snake (n° 590); Giant Turtle Who Feeds on Flames (n° 593); Violent Rain (n° 599); Penguin Soldier (n° 602); Liquid Beast (n° 605); Twin Long Rods #2 (n° 606); Electric Lizard (n° 610); Armored Starfish (n° 615); Marine Beast (n° 617); Snakeyashi (n° 620); High Tide Gyojin (n° 624); Fairy of the Fountain (n° 625); Amazon of the Seas (n° 626); Ancient Lizard Warrior (n° 630); Night Lizard (n° 634); Amphibious Bugroth (n° 639); Gruesome Goo (n° 646); Hyosube (n° 647); Crab Turtle (n° 710); Fortress Whale (n° 718).

### 651 — Kunai with Chain
**Effet d’origine :** Augmente de **500 points l’ATK et de 500 points la DEF** d’un monstre compatible auquel tu appliques cet équipement. Le renforcement concerne ce monstre, pas tout ton terrain, et reste tant que ce monstre conserve son état sur le terrain. Un monstre incompatible ne reçoit pas le bonus.

**Conditions et limites :** Les mêmes monstres restent compatibles à toutes les raretés. Reverse Trap peut retourner le renforcement en pénalité. Le bonus d’équipement s’ajoute aux statistiques du monstre, y compris son éventuel bonus de rareté.

| Rareté | Effet total selon la rareté |
|---|---|
| Normale | Le monstre équipé gagne **500 ATK et 500 DEF**. |
| Rare | Le monstre équipé gagne **600 ATK et 600 DEF**. |
| Épique | Le monstre équipé gagne **800 ATK et 800 DEF**. |
| Légendaire | Le monstre équipé gagne **1000 ATK et 1000 DEF**. |
| Mythique | Le monstre équipé gagne **1300 ATK et 1300 DEF**. |

**Monstres compatibles dans le disque USA :** Swamp Battleguard (n° 12); Battle Steer (n° 14); Flame Swordsman (n° 15); Summoned Skull (n° 22); The Wicked Worm Beast (n° 23); Horn Imp (n° 25); Zombie Warrior (n° 30); Judge Man (n° 33); Gaia the Fierce Knight (n° 38); Celtic Guardian (n° 41); Karbonala Warrior (n° 43); Kojikocy (n° 66); Garoozis (n° 68); Axe Raider (n° 78); Zanki (n° 93); Battle Warrior (n° 100); Kageningen (n° 107); Hero of the East (n° 110); Supporter in the Shadows (n° 118); Trial of Nightmares (n° 119); Dream Clown (n° 120); Ancient Tool (n° 124); Ansatsu (n° 127); Mystical Capture Chain (n° 134); Dragon Statue (n° 138); Monster Egg (n° 147); Rhaimundos of the Red Sword (n° 151); Hard Armor (n° 156); M-warrior #1 (n° 160); M-warrior #2 (n° 161); The Judgement Hand (n° 165); Mysterious Puppeteer (n° 166); Armaill (n° 172); Masked Clown (n° 182); Eyearmor (n° 185); Doron (n° 195); Kagemusha of the Blue Flame (n° 214); Solitude (n° 219); Trap Master (n° 224); Fiend Sword (n° 225); Skull Stalker (n° 226); Wood Clown (n° 231); Beautiful Headhuntress (n° 234); Wodan the Resident of the Forest (n° 235); Guardian of the Labyrinth (n° 236); Vishwar Randi (n° 239); Dark Assailant (n° 241); One Who Hunts Souls (n° 246); Hyo (n° 250); Dimensional Warrior (n° 256); The Little Swordsman of Aile (n° 262); Princess of Tsurugi (n° 266); Unknown Warrior of Fiend (n° 267); Versago the Destroyer (n° 269); Protector of the Throne (n° 280); Mystic Clown (n° 281); Moon Envoy (n° 290); Masaki the Legendary Swordsman (n° 293); Dragoness the Wicked Knight (n° 294); Cyber Soldier of Darkworld (n° 297); Sonic Maid (n° 299); Kanan the Swordmistress (n° 352); Stuffed Animal (n° 354); Megasonic Eye (n° 355); Super War-lion (n° 356); Three-legged Zombies (n° 359); Zera The Mant (n° 360); Millennium Shield (n° 362); Black Luster Soldier (n° 364); Wall Shadow (n° 369); Gate Guardian (n° 374); Monster Tamer (n° 376); Swordstalker (n° 378); Giltia the D. Knight (n° 389); Swordsman from a Foreign Land (n° 399); Saber Slasher (n° 405); Yaiba Robo (n° 406); Blocker (n° 416); Beautiful Beast Trainer (n° 434); Armed Ninja (n° 469); D. Human (n° 502); The Bistro Butcher (n° 523); Mushroom Man #2 (n° 553); Lava Battleguard (n° 554); Oscillo Hero (n° 559); Empress Judge (n° 572); Binding Chain (n° 584); Mechanical Snail (n° 585); Greenkappa (n° 586); Warrior of Tradition (n° 618); Succubus Knight (n° 621); Queen's Double (n° 635); Invader of the Throne (n° 641); Hibikime (n° 649); Performance of Sword (n° 701); Hungry Burger (n° 702); Skull Guardian (n° 704); Skull Knight (n° 707); Psycho-Puppet (n° 715); Garma Sword (n° 716); Mask of Shine & Dark (n° 720); Magician of Black Chaos (n° 722).

### 652 — Magical Labyrinth
**Effet d’origine :** Augmente de **500 points l’ATK et de 500 points la DEF** d’un monstre compatible auquel tu appliques cet équipement. Le renforcement concerne ce monstre, pas tout ton terrain, et reste tant que ce monstre conserve son état sur le terrain. Un monstre incompatible ne reçoit pas le bonus.

**Conditions et limites :** Les mêmes monstres restent compatibles à toutes les raretés. Reverse Trap peut retourner le renforcement en pénalité. Le bonus d’équipement s’ajoute aux statistiques du monstre, y compris son éventuel bonus de rareté.

| Rareté | Effet total selon la rareté |
|---|---|
| Normale | Le monstre équipé gagne **500 ATK et 500 DEF**. |
| Rare | Le monstre équipé gagne **600 ATK et 600 DEF**. |
| Épique | Le monstre équipé gagne **800 ATK et 800 DEF**. |
| Légendaire | Le monstre équipé gagne **1000 ATK et 1000 DEF**. |
| Mythique | Le monstre équipé gagne **1300 ATK et 1300 DEF**. |

**Monstres compatibles dans le disque USA :** Labyrinth Wall (n° 366).

### 654 — Salamandra
**Effet d’origine :** Augmente de **500 points l’ATK et de 500 points la DEF** d’un monstre compatible auquel tu appliques cet équipement. Le renforcement concerne ce monstre, pas tout ton terrain, et reste tant que ce monstre conserve son état sur le terrain. Un monstre incompatible ne reçoit pas le bonus.

**Conditions et limites :** Les mêmes monstres restent compatibles à toutes les raretés. Reverse Trap peut retourner le renforcement en pénalité. Le bonus d’équipement s’ajoute aux statistiques du monstre, y compris son éventuel bonus de rareté.

| Rareté | Effet total selon la rareté |
|---|---|
| Normale | Le monstre équipé gagne **500 ATK et 500 DEF**. |
| Rare | Le monstre équipé gagne **600 ATK et 600 DEF**. |
| Épique | Le monstre équipé gagne **800 ATK et 800 DEF**. |
| Légendaire | Le monstre équipé gagne **1000 ATK et 1000 DEF**. |
| Mythique | Le monstre équipé gagne **1300 ATK et 1300 DEF**. |

**Monstres compatibles dans le disque USA :** Flame Swordsman (n° 15); Dragon Piper (n° 40); Garoozis (n° 68); Wings of Wicked Flame (n° 101); Charubin the Fire Knight (n° 133); Flame Manipulator (n° 142); Fire Reaper (n° 154); Firegrass (n° 157); Darkfire Dragon (n° 168); Armaill (n° 172); Fire Eye (n° 176); Hinotama Soul (n° 210); Kagemusha of the Blue Flame (n° 214); Flame Ghost (n° 215); Candle of Fate (n° 242); Dissolverock (n° 244); Mavelus (n° 272); Fireyarou (n° 291); Yamadron (n° 357); Launcher Spider (n° 390); Machine King (n° 407); Metal Dragon (n° 409); Blast Juggler (n° 417); Crimson Sunbird (n° 467); Vermillion Sparrow (n° 473); Fire Kraken (n° 519); Flame Cerebrus (n° 529); Tyhone #2 (n° 555); Flame Viper (n° 644); Meteor B. Dragon (n° 713); Firewing Pegasus (n° 714).

### 657 — Megamorph
**Effet d’origine :** Augmente de **1000 points l’ATK et de 1000 points la DEF** d’un monstre compatible auquel tu appliques cet équipement. Le renforcement concerne ce monstre, pas tout ton terrain, et reste tant que ce monstre conserve son état sur le terrain. Un monstre incompatible ne reçoit pas le bonus.

**Conditions et limites :** Les mêmes monstres restent compatibles à toutes les raretés. Reverse Trap peut retourner le renforcement en pénalité. Le bonus d’équipement s’ajoute aux statistiques du monstre, y compris son éventuel bonus de rareté.

| Rareté | Effet total selon la rareté |
|---|---|
| Normale | Le monstre équipé gagne **1000 ATK et 1000 DEF**. |
| Rare | Le monstre équipé gagne **1100 ATK et 1100 DEF**. |
| Épique | Le monstre équipé gagne **1300 ATK et 1300 DEF**. |
| Légendaire | Le monstre équipé gagne **1500 ATK et 1500 DEF**. |
| Mythique | Le monstre équipé gagne **1800 ATK et 1800 DEF**. |

**Monstres compatibles dans le disque USA :** Blue-eyes White Dragon (n° 1); Mystical Elf (n° 2); Hitotsu-me Giant (n° 3); Baby Dragon (n° 4); Ryu-kishin (n° 5); Feral Imp (n° 6); Winged Dragon #1 (n° 7); Mushroom Man (n° 8); Shadow Specter (n° 9); Blackland Fire Dragon (n° 10); Sword Arm of Dragon (n° 11); Swamp Battleguard (n° 12); Tyhone (n° 13); Battle Steer (n° 14); Flame Swordsman (n° 15); Time Wizard (n° 16); Right Leg of the Forbidden One (n° 17); Left Leg of the Forbidden One (n° 18); Right Arm of the Forbidden One (n° 19); Left Arm of the Forbidden One (n° 20); Exodia the Forbidden (n° 21); Summoned Skull (n° 22); The Wicked Worm Beast (n° 23); Skull Servant (n° 24); Horn Imp (n° 25); Battle Ox (n° 26); Beaver Warrior (n° 27); Rock Ogre Grotto #1 (n° 28); Mountain Warrior (n° 29); Zombie Warrior (n° 30); Koumori Dragon (n° 31); Two-headed King Rex (n° 32); Judge Man (n° 33); Saggi the Dark Clown (n° 34); Dark Magician (n° 35); The Snake Hair (n° 36); Gaia the Dragon Champion (n° 37); Gaia the Fierce Knight (n° 38); Curse of Dragon (n° 39); Dragon Piper (n° 40); Celtic Guardian (n° 41); Illusionist Faceless Mage (n° 42); Karbonala Warrior (n° 43); Rogue Doll (n° 44); Oscillo Hero #2 (n° 45); Griffore (n° 46); Torike (n° 47); Sangan (n° 48); Big Insect (n° 49); Basic Insect (n° 50); Armored Lizard (n° 51); Hercules Beetle (n° 52); Killer Needle (n° 53); Gokibore (n° 54); Giant Flea (n° 55); Larvae Moth (n° 56); Great Moth (n° 57); Kuriboh (n° 58); Mammoth Graveyard (n° 59); Great White (n° 60); Wolf (n° 61); Harpie Lady (n° 62); Harpie Lady Sisters (n° 63); Tiger Axe (n° 64); Silver Fang (n° 65); Kojikocy (n° 66); Perfectly Ultimate Great Moth (n° 67); Garoozis (n° 68); Thousand Dragon (n° 69); Fiend Kraken (n° 70); Jellyfish (n° 71); Cocoon of Evolution (n° 72); Kairyu-shin (n° 73); Giant Soldier of Stone (n° 74); Man-eating Plant (n° 75); Krokodilus (n° 76); Grappler (n° 77); Axe Raider (n° 78); Megazowler (n° 79); Uraby (n° 80); Crawling Dragon #2 (n° 81); Red-eyes B. Dragon (n° 82); Castle of Dark Illusions (n° 83); Reaper of the Cards (n° 84); King of Yamimakai (n° 85); Barox (n° 86); Dark Chimera (n° 87); Metal Guardian (n° 88); Catapult Turtle (n° 89); Gyakutenno Megami (n° 90); Mystic Horseman (n° 91); Rabid Horseman (n° 92); Zanki (n° 93); Crawling Dragon (n° 94); Crass Clown (n° 95); Armored Zombie (n° 96); Dragon Zombie (n° 97); Clown Zombie (n° 98); Pumpking the King of Ghosts (n° 99); Battle Warrior (n° 100); Wings of Wicked Flame (n° 101); Mask of Darkness (n° 102); Job-change Mirror (n° 103); Curtain of the Dark Ones (n° 104); Tomozaurus (n° 105); Spirit of the Winds (n° 106); Kageningen (n° 107); Graveyard and the Hand of Invitation (n° 108); Goddess with the Third Eye (n° 109); Hero of the East (n° 110); Doma The Angel of Silence (n° 111); That Which Feeds on Life (n° 112); Dark Gray (n° 113); White Magical Hat (n° 114); Kamion Wizard (n° 115); Nightmare Scorpion (n° 116); Spirit of the Books (n° 117); Supporter in the Shadows (n° 118); Trial of Nightmares (n° 119); Dream Clown (n° 120); Sleeping Lion (n° 121); Yamatano Dragon Scroll (n° 122); Dark Plant (n° 123); Ancient Tool (n° 124); Faith Bird (n° 125); Orion the Battle King (n° 126); Ansatsu (n° 127); LaMoon (n° 128); Nemuriko (n° 129); Weather Control (n° 130); Octoberser (n° 131); The 13th Grave (n° 132); Charubin the Fire Knight (n° 133); Mystical Capture Chain (n° 134); Fiend's Hand (n° 135); Witty Phantom (n° 136); Mystery Hand (n° 137); Dragon Statue (n° 138); Blue-eyed Silver Zombie (n° 139); Toad Master (n° 140); Spiked Snail (n° 141); Flame Manipulator (n° 142); Necrolancer the Timelord (n° 143); Djinn the Watcher of the Wind (n° 144); The Bewitching Phantom Thief (n° 145); Temple of Skulls (n° 146); Monster Egg (n° 147); The Shadow Who Controls the Dark (n° 148); Lord of the Lamp (n° 149); Akihiron (n° 150); Rhaimundos of the Red Sword (n° 151); The Melting Red Shadow (n° 152); Dokuroizo the Grim Reaper (n° 153); Fire Reaper (n° 154); Larvas (n° 155); Hard Armor (n° 156); Firegrass (n° 157); Man Eater (n° 158); Dig Beak (n° 159); M-warrior #1 (n° 160); M-warrior #2 (n° 161); Tainted Wisdom (n° 162); Lisark (n° 163); Lord of Zemia (n° 164); The Judgement Hand (n° 165); Mysterious Puppeteer (n° 166); Ancient Jar (n° 167); Darkfire Dragon (n° 168); Dark King of the Abyss (n° 169); Spirit of the Harp (n° 170); Big Eye (n° 171); Armaill (n° 172); Dark Prisoner (n° 173); Hurricail (n° 174); Ancient Brain (n° 175); Fire Eye (n° 176); Monsturtle (n° 177); Claw Reacher (n° 178); Phantom Dewan (n° 179); Arlownay (n° 180); Dark Shade (n° 181); Masked Clown (n° 182); Lucky Trinket (n° 183); Genin (n° 184); Eyearmor (n° 185); Fiend Refrection #2 (n° 186); Gate Deeg (n° 187); Synchar (n° 188); Fusionist (n° 189); Akakieisu (n° 190); LaLa Li-oon (n° 191); Key Mace (n° 192); Turtle Tiger (n° 193); Terra the Terrible (n° 194); Doron (n° 195); Arma Knight (n° 196); Mech Mole Zombie (n° 197); Happy Lover (n° 198); Penguin Knight (n° 199); Petit Dragon (n° 200); Frenzied Panda (n° 201); Air Marmot of Nefariousness (n° 202); Phantom Ghost (n° 203); Mabarrel (n° 204); Dorover (n° 205); Twin Long Rods #1 (n° 206); Droll Bird (n° 207); Petit Angel (n° 208); Winged Cleaver (n° 209); Hinotama Soul (n° 210); Kaminarikozou (n° 211); Meotoko (n° 212); Aqua Madoor (n° 213); Kagemusha of the Blue Flame (n° 214); Flame Ghost (n° 215); Dryad (n° 216); B. Skull Dragon (n° 217); Two-mouth Darkruler (n° 218); Solitude (n° 219); Masked Sorcerer (n° 220); Kumootoko (n° 221); Midnight Fiend (n° 222); Roaring Ocean Snake (n° 223); Trap Master (n° 224); Fiend Sword (n° 225); Skull Stalker (n° 226); Hitodenchak (n° 227); Wood Remains (n° 228); Hourglass of Life (n° 229); Rare Fish (n° 230); Wood Clown (n° 231); Madjinn Gunn (n° 232); Dark Titan of Terror (n° 233); Beautiful Headhuntress (n° 234); Wodan the Resident of the Forest (n° 235); Guardian of the Labyrinth (n° 236); Haniwa (n° 237); Yashinoki (n° 238); Vishwar Randi (n° 239); The Drdek (n° 240); Dark Assailant (n° 241); Candle of Fate (n° 242); Water Element (n° 243); Dissolverock (n° 244); Meda Bat (n° 245); One Who Hunts Souls (n° 246); Root Water (n° 247); Master & Expert (n° 248); Water Omotics (n° 249); Hyo (n° 250); Enchanting Mermaid (n° 251); Nekogal #1 (n° 252); Angelwitch (n° 253); Embryonic Beast (n° 254); Prevent Rat (n° 255); Dimensional Warrior (n° 256); Stone Armadiller (n° 257); Beastking of the Swamps (n° 258); Ancient Sorcerer (n° 259); Lunar Queen Elzaim (n° 260); Wicked Mirror (n° 261); The Little Swordsman of Aile (n° 262); Rock Ogre Grotto #2 (n° 263); Wing Egg Elf (n° 264); The Furious Sea King (n° 265); Princess of Tsurugi (n° 266); Unknown Warrior of Fiend (n° 267); Sectarian of Secrets (n° 268); Versago the Destroyer (n° 269); Wetha (n° 270); Megirus Light (n° 271); Mavelus (n° 272); Ancient Tree of Enlightenment (n° 273); Green Phantom King (n° 274); Ground Attacker Bugroth (n° 275); Ray & Temperature (n° 276); Gorgon Egg (n° 277); Petit Moth (n° 278); King Fog (n° 279); Protector of the Throne (n° 280); Mystic Clown (n° 281); Mystical Sheep #2 (n° 282); Holograh (n° 283); Tao the Chanter (n° 284); Serpent Marauder (n° 285); Gatekeeper (n° 286); Ogre of the Black Shadow (n° 287); Dark Artist (n° 288); Change Slime (n° 289); Moon Envoy (n° 290); Fireyarou (n° 291); Psychic Kappa (n° 292); Masaki the Legendary Swordsman (n° 293); Dragoness the Wicked Knight (n° 294); Bio Plant (n° 295); One-eyed Shield Dragon (n° 296); Cyber Soldier of Darkworld (n° 297); Wicked Dragon with the Ersatz Head (n° 298); Sonic Maid (n° 299); Kurama (n° 300); Yaranzo (n° 351); Kanan the Swordmistress (n° 352); Takriminos (n° 353); Stuffed Animal (n° 354); Megasonic Eye (n° 355); Super War-lion (n° 356); Yamadron (n° 357); Seiyaryu (n° 358); Three-legged Zombies (n° 359); Zera The Mant (n° 360); Flying Penguin (n° 361); Millennium Shield (n° 362); Fairy's Gift (n° 363); Black Luster Soldier (n° 364); Fiend's Mirror (n° 365); Labyrinth Wall (n° 366); Jirai Gumo (n° 367); Shadow Ghoul (n° 368); Wall Shadow (n° 369); Labyrinth Tank (n° 370); Sanga of the Thunder (n° 371); Kazejin (n° 372); Suijin (n° 373); Gate Guardian (n° 374); Dungeon Worm (n° 375); Monster Tamer (n° 376); Ryu-kishin Powered (n° 377); Swordstalker (n° 378); La Jinn the Mystical Genie (n° 379); Blue-eyes Ultimate Dragon (n° 380); Toon Alligator (n° 381); Rude Kaiser (n° 382); Parrot Dragon (n° 383); Dark Rabbit (n° 384); Bickuribox (n° 385); Harpie's Pet Dragon (n° 386); Mystic Lamp (n° 387); Pendulum Machine (n° 388); Giltia the D. Knight (n° 389); Launcher Spider (n° 390); Zoa (n° 391); Metalzoa (n° 392); Zone Eater (n° 393); Steel Scorpion (n° 394); Dancing Elf (n° 395); Ocubeam (n° 396); Leghul (n° 397); Ooguchi (n° 398); Swordsman from a Foreign Land (n° 399); Emperor of the Land and Sea (n° 400); Ushi Oni (n° 401); Monster Eye (n° 402); Leogun (n° 403); Tatsunootoshigo (n° 404); Saber Slasher (n° 405); Yaiba Robo (n° 406); Machine King (n° 407); Giant Mech-soldier (n° 408); Metal Dragon (n° 409); Mechanical Spider (n° 410); Bat (n° 411); Giga-tech Wolf (n° 412); Cyber Soldier (n° 413); Shovel Crusher (n° 414); Mechanicalchacer (n° 415); Blocker (n° 416); Blast Juggler (n° 417); Golgoil (n° 418); Giganto (n° 419); Cyber-Stein (n° 420); Cyber Commander (n° 421); Jinzo #7 (n° 422); Dice Armadillo (n° 423); Sky Dragon (n° 424); Thunder Dragon (n° 425); Stone D. (n° 426); Kaiser Dragon (n° 427); Magician of Faith (n° 428); Goddess of Whim (n° 429); Water Magician (n° 430); Ice Water (n° 431); Waterdragon Fairy (n° 432); Ancient Elf (n° 433); Beautiful Beast Trainer (n° 434); Water Girl (n° 435); White Dolphin (n° 436); Deepsea Shark (n° 437); Metal Fish (n° 438); Bottom Dweller (n° 439); 7 Colored Fish (n° 440); Mech Bass (n° 441); Aqua Dragon (n° 442); Sea King Dragon (n° 443); Turu-Purun (n° 444); Guardian of the Sea (n° 445); Aqua Snake (n° 446); Giant Red Seasnake (n° 447); Spike Seadra (n° 448); 30,000-Year White Turtle (n° 449); Kappa Avenger (n° 450); Kanikabuto (n° 451); Zarigun (n° 452); Millennium Golem (n° 453); Destroyer Golem (n° 454); Barrel Rock (n° 455); Minomushi Warrior (n° 456); Stone Ghost (n° 457); Kaminari Attack (n° 458); Tripwire Beast (n° 459); Bolt Escargot (n° 460); Bolt Penguin (n° 461); The Immortal of Thunder (n° 462); Electric Snake (n° 463); Wing Eagle (n° 464); Punished Eagle (n° 465); Skull Red Bird (n° 466); Crimson Sunbird (n° 467); Queen Bird (n° 468); Armed Ninja (n° 469); Magical Ghost (n° 470); Soul Hunter (n° 471); Air Eater (n° 472); Vermillion Sparrow (n° 473); Sea Kamen (n° 474); Sinister Serpent (n° 475); Ganigumo (n° 476); Alinsection (n° 477); Insect Soldiers of the Sky (n° 478); Cockroach Knight (n° 479); Kuwagata α (n° 480); Burglar (n° 481); Pragtical (n° 482); Garvas (n° 483); Ameba (n° 484); Korogashi (n° 485); Boo Koo (n° 486); Flower Wolf (n° 487); Rainbow Flower (n° 488); Barrel Lily (n° 489); Needle Ball (n° 490); Peacock (n° 491); Hoshiningen (n° 492); Maha Vailo (n° 493); Rainbow Marine Mermaid (n° 494); Musician King (n° 495); Wilmee (n° 496); Yado Karu (n° 497); Morinphen (n° 498); Kattapillar (n° 499); Dragon Seeker (n° 500); Man-eater Bug (n° 501); D. Human (n° 502); Turtle Raccoon (n° 503); Fungi of the Musk (n° 504); Prisman (n° 505); Gale Dogra (n° 506); Crazy Fish (n° 507); Cyber Saurus (n° 508); Bracchio-raidus (n° 509); Laughing Flower (n° 510); Bean Soldier (n° 511); Cannon Soldier (n° 512); Guardian of the Throne Room (n° 513); Brave Scizzar (n° 514); The Statue of Easter Island (n° 515); Muka Muka (n° 516); Sand Stone (n° 517); Boulder Tortoise (n° 518); Fire Kraken (n° 519); Turtle Bird (n° 520); Skullbird (n° 521); Monstrous Bird (n° 522); The Bistro Butcher (n° 523); Star Boy (n° 524); Spirit of the Mountain (n° 525); Neck Hunter (n° 526); Milus Radiant (n° 527); Togex (n° 528); Flame Cerebrus (n° 529); Eldeen (n° 530); Mystical Sand (n° 531); Gemini Elf (n° 532); Kwagar Hercules (n° 533); Minar (n° 534); Kamakiriman (n° 535); Mechaleon (n° 536); Mega Thunderball (n° 537); Niwatori (n° 538); Corroding Shark (n° 539); Skelengel (n° 540); Hane-Hane (n° 541); Misairuzame (n° 542); Tongyo (n° 543); Dharma Cannon (n° 544); Skelgon (n° 545); Wow Warrior (n° 546); Griggle (n° 547); Bone Mouse (n° 548); Frog The Jam (n° 549); Behegon (n° 550); Dark Elf (n° 551); Winged Dragon #2 (n° 552); Mushroom Man #2 (n° 553); Lava Battleguard (n° 554); Tyhone #2 (n° 555); The Wandering Doomed (n° 556); Steel Ogre Grotto #1 (n° 557); Pot the Trick (n° 558); Oscillo Hero (n° 559); Invader from Another Dimension (n° 560); Lesser Dragon (n° 561); Needle Worm (n° 562); Wretched Ghost of the Attic (n° 563); Great Mammoth of Goldfine (n° 564); Man-eating Black Shark (n° 565); Yormungarde (n° 566); Darkworld Thorns (n° 567); Anthrosaurus (n° 568); Drooling Lizard (n° 569); Trakadon (n° 570); B. Dragon Jungle King (n° 571); Empress Judge (n° 572); Little D (n° 573); Witch of the Black Forest (n° 574); Ancient One of the Deep Forest (n° 575); Giant Scorpion of the Tundra (n° 576); Crow Goblin (n° 577); Leo Wizard (n° 578); Abyss Flower (n° 579); Patrol Robo (n° 580); Takuhee (n° 581); Dark Witch (n° 582); Weather Report (n° 583); Binding Chain (n° 584); Mechanical Snail (n° 585); Greenkappa (n° 586); Mon Larvas (n° 587); Living Vase (n° 588); Tentacle Plant (n° 589); Beaked Snake (n° 590); Morphing Jar (n° 591); Muse-A (n° 592); Giant Turtle Who Feeds on Flames (n° 593); Rose Spectre of Dunn (n° 594); Fiend Refrection #1 (n° 595); Ghoul with an Appetite (n° 596); Pale Beast (n° 597); Little Chimera (n° 598); Violent Rain (n° 599); Key Mace #2 (n° 600); Tenderness (n° 601); Penguin Soldier (n° 602); Fairy Dragon (n° 603); Obese Marmot of Nefariousness (n° 604); Liquid Beast (n° 605); Twin Long Rods #2 (n° 606); Great Bill (n° 607); Shining Friendship (n° 608); Bladefly (n° 609); Electric Lizard (n° 610); Hiro's Shadow Scout (n° 611); Lady of Faith (n° 612); Twin-headed Thunder Dragon (n° 613); Hunter Spider (n° 614); Armored Starfish (n° 615); Hourglass of Courage (n° 616); Marine Beast (n° 617); Warrior of Tradition (n° 618); Rock Spirit (n° 619); Snakeyashi (n° 620); Succubus Knight (n° 621); Ill Witch (n° 622); The Thing That Hides in the Mud (n° 623); High Tide Gyojin (n° 624); Fairy of the Fountain (n° 625); Amazon of the Seas (n° 626); Nekogal #2 (n° 627); Witch's Apprentice (n° 628); Armored Rat (n° 629); Ancient Lizard Warrior (n° 630); Maiden of the Moonlight (n° 631); Stone Ogre Grotto (n° 632); Winged Egg of New Life (n° 633); Night Lizard (n° 634); Queen's Double (n° 635); Blue-winged Crown (n° 636); Trent (n° 637); Queen of Autumn Leaves (n° 638); Amphibious Bugroth (n° 639); Acid Crawler (n° 640); Invader of the Throne (n° 641); Mystical Sheep #1 (n° 642); Disk Magician (n° 643); Flame Viper (n° 644); Royal Guard (n° 645); Gruesome Goo (n° 646); Hyosube (n° 647); Machine Attacker (n° 648); Hibikime (n° 649); Whiptail Crow (n° 650); Performance of Sword (n° 701); Hungry Burger (n° 702); Sengenjin (n° 703); Skull Guardian (n° 704); Tri-horned Dragon (n° 705); Serpent Night Dragon (n° 706); Skull Knight (n° 707); Cosmo Queen (n° 708); Chakra (n° 709); Crab Turtle (n° 710); Mikazukinoyaiba (n° 711); Meteor Dragon (n° 712); Meteor B. Dragon (n° 713); Firewing Pegasus (n° 714); Psycho-Puppet (n° 715); Garma Sword (n° 716); Javelin Beetle (n° 717); Fortress Whale (n° 718); Dokurorider (n° 719); Mask of Shine & Dark (n° 720); Magician of Black Chaos (n° 722).

### 658 — Metalmorph
**Effet d’origine :** Augmente de **500 points l’ATK et de 500 points la DEF** d’un monstre compatible auquel tu appliques cet équipement. Le renforcement concerne ce monstre, pas tout ton terrain, et reste tant que ce monstre conserve son état sur le terrain. Un monstre incompatible ne reçoit pas le bonus.

**Conditions et limites :** Les mêmes monstres restent compatibles à toutes les raretés. Reverse Trap peut retourner le renforcement en pénalité. Le bonus d’équipement s’ajoute aux statistiques du monstre, y compris son éventuel bonus de rareté.

| Rareté | Effet total selon la rareté |
|---|---|
| Normale | Le monstre équipé gagne **500 ATK et 500 DEF**. |
| Rare | Le monstre équipé gagne **600 ATK et 600 DEF**. |
| Épique | Le monstre équipé gagne **800 ATK et 800 DEF**. |
| Légendaire | Le monstre équipé gagne **1000 ATK et 1000 DEF**. |
| Mythique | Le monstre équipé gagne **1300 ATK et 1300 DEF**. |

**Monstres compatibles dans le disque USA :** Zoa (n° 391).

### 659 — Winged Trumpeter
**Effet d’origine :** Augmente de **500 points l’ATK et de 500 points la DEF** d’un monstre compatible auquel tu appliques cet équipement. Le renforcement concerne ce monstre, pas tout ton terrain, et reste tant que ce monstre conserve son état sur le terrain. Un monstre incompatible ne reçoit pas le bonus.

**Conditions et limites :** Les mêmes monstres restent compatibles à toutes les raretés. Reverse Trap peut retourner le renforcement en pénalité. Le bonus d’équipement s’ajoute aux statistiques du monstre, y compris son éventuel bonus de rareté.

| Rareté | Effet total selon la rareté |
|---|---|
| Normale | Le monstre équipé gagne **500 ATK et 500 DEF**. |
| Rare | Le monstre équipé gagne **600 ATK et 600 DEF**. |
| Épique | Le monstre équipé gagne **800 ATK et 800 DEF**. |
| Légendaire | Le monstre équipé gagne **1000 ATK et 1000 DEF**. |
| Mythique | Le monstre équipé gagne **1300 ATK et 1300 DEF**. |

**Monstres compatibles dans le disque USA :** Gyakutenno Megami (n° 90); Goddess with the Third Eye (n° 109); Doma The Angel of Silence (n° 111); Orion the Battle King (n° 126); Weather Control (n° 130); Mystical Capture Chain (n° 134); Spirit of the Harp (n° 170); Key Mace (n° 192); Happy Lover (n° 198); Petit Angel (n° 208); Hourglass of Life (n° 229); Lunar Queen Elzaim (n° 260); Wing Egg Elf (n° 264); Ray & Temperature (n° 276); Dancing Elf (n° 395); Ocubeam (n° 396); Goddess of Whim (n° 429); Hoshiningen (n° 492); Skelengel (n° 540); Dark Witch (n° 582); Binding Chain (n° 584); Muse-A (n° 592); Tenderness (n° 601); Shining Friendship (n° 608); Hourglass of Courage (n° 616); Winged Egg of New Life (n° 633).

### 668 — Bright Castle
**Effet d’origine :** Augmente de **500 points l’ATK et de 500 points la DEF** d’un monstre compatible auquel tu appliques cet équipement. Le renforcement concerne ce monstre, pas tout ton terrain, et reste tant que ce monstre conserve son état sur le terrain. Un monstre incompatible ne reçoit pas le bonus.

**Conditions et limites :** Les mêmes monstres restent compatibles à toutes les raretés. Reverse Trap peut retourner le renforcement en pénalité. Le bonus d’équipement s’ajoute aux statistiques du monstre, y compris son éventuel bonus de rareté.

| Rareté | Effet total selon la rareté |
|---|---|
| Normale | Le monstre équipé gagne **500 ATK et 500 DEF**. |
| Rare | Le monstre équipé gagne **600 ATK et 600 DEF**. |
| Épique | Le monstre équipé gagne **800 ATK et 800 DEF**. |
| Légendaire | Le monstre équipé gagne **1000 ATK et 1000 DEF**. |
| Mythique | Le monstre équipé gagne **1300 ATK et 1300 DEF**. |

**Monstres compatibles dans le disque USA :** Blue-eyes White Dragon (n° 1); Mystical Elf (n° 2); Hitotsu-me Giant (n° 3); Baby Dragon (n° 4); Ryu-kishin (n° 5); Feral Imp (n° 6); Winged Dragon #1 (n° 7); Mushroom Man (n° 8); Shadow Specter (n° 9); Blackland Fire Dragon (n° 10); Sword Arm of Dragon (n° 11); Swamp Battleguard (n° 12); Tyhone (n° 13); Battle Steer (n° 14); Flame Swordsman (n° 15); Time Wizard (n° 16); Right Leg of the Forbidden One (n° 17); Left Leg of the Forbidden One (n° 18); Right Arm of the Forbidden One (n° 19); Left Arm of the Forbidden One (n° 20); Exodia the Forbidden (n° 21); Summoned Skull (n° 22); The Wicked Worm Beast (n° 23); Skull Servant (n° 24); Horn Imp (n° 25); Battle Ox (n° 26); Beaver Warrior (n° 27); Rock Ogre Grotto #1 (n° 28); Mountain Warrior (n° 29); Zombie Warrior (n° 30); Koumori Dragon (n° 31); Two-headed King Rex (n° 32); Judge Man (n° 33); Saggi the Dark Clown (n° 34); Dark Magician (n° 35); The Snake Hair (n° 36); Gaia the Dragon Champion (n° 37); Gaia the Fierce Knight (n° 38); Curse of Dragon (n° 39); Dragon Piper (n° 40); Celtic Guardian (n° 41); Illusionist Faceless Mage (n° 42); Karbonala Warrior (n° 43); Rogue Doll (n° 44); Oscillo Hero #2 (n° 45); Griffore (n° 46); Torike (n° 47); Sangan (n° 48); Big Insect (n° 49); Basic Insect (n° 50); Armored Lizard (n° 51); Hercules Beetle (n° 52); Killer Needle (n° 53); Gokibore (n° 54); Giant Flea (n° 55); Larvae Moth (n° 56); Great Moth (n° 57); Kuriboh (n° 58); Mammoth Graveyard (n° 59); Great White (n° 60); Wolf (n° 61); Harpie Lady (n° 62); Harpie Lady Sisters (n° 63); Tiger Axe (n° 64); Silver Fang (n° 65); Kojikocy (n° 66); Perfectly Ultimate Great Moth (n° 67); Garoozis (n° 68); Thousand Dragon (n° 69); Fiend Kraken (n° 70); Jellyfish (n° 71); Cocoon of Evolution (n° 72); Kairyu-shin (n° 73); Giant Soldier of Stone (n° 74); Man-eating Plant (n° 75); Krokodilus (n° 76); Grappler (n° 77); Axe Raider (n° 78); Megazowler (n° 79); Uraby (n° 80); Crawling Dragon #2 (n° 81); Red-eyes B. Dragon (n° 82); Castle of Dark Illusions (n° 83); Reaper of the Cards (n° 84); King of Yamimakai (n° 85); Barox (n° 86); Dark Chimera (n° 87); Metal Guardian (n° 88); Catapult Turtle (n° 89); Gyakutenno Megami (n° 90); Mystic Horseman (n° 91); Rabid Horseman (n° 92); Zanki (n° 93); Crawling Dragon (n° 94); Crass Clown (n° 95); Armored Zombie (n° 96); Dragon Zombie (n° 97); Clown Zombie (n° 98); Pumpking the King of Ghosts (n° 99); Battle Warrior (n° 100); Wings of Wicked Flame (n° 101); Mask of Darkness (n° 102); Job-change Mirror (n° 103); Curtain of the Dark Ones (n° 104); Tomozaurus (n° 105); Spirit of the Winds (n° 106); Kageningen (n° 107); Graveyard and the Hand of Invitation (n° 108); Goddess with the Third Eye (n° 109); Hero of the East (n° 110); Doma The Angel of Silence (n° 111); That Which Feeds on Life (n° 112); Dark Gray (n° 113); White Magical Hat (n° 114); Kamion Wizard (n° 115); Nightmare Scorpion (n° 116); Spirit of the Books (n° 117); Supporter in the Shadows (n° 118); Trial of Nightmares (n° 119); Dream Clown (n° 120); Sleeping Lion (n° 121); Yamatano Dragon Scroll (n° 122); Dark Plant (n° 123); Ancient Tool (n° 124); Faith Bird (n° 125); Orion the Battle King (n° 126); Ansatsu (n° 127); LaMoon (n° 128); Nemuriko (n° 129); Weather Control (n° 130); Octoberser (n° 131); The 13th Grave (n° 132); Charubin the Fire Knight (n° 133); Mystical Capture Chain (n° 134); Fiend's Hand (n° 135); Witty Phantom (n° 136); Mystery Hand (n° 137); Dragon Statue (n° 138); Blue-eyed Silver Zombie (n° 139); Toad Master (n° 140); Spiked Snail (n° 141); Flame Manipulator (n° 142); Necrolancer the Timelord (n° 143); Djinn the Watcher of the Wind (n° 144); The Bewitching Phantom Thief (n° 145); Temple of Skulls (n° 146); Monster Egg (n° 147); The Shadow Who Controls the Dark (n° 148); Lord of the Lamp (n° 149); Akihiron (n° 150); Rhaimundos of the Red Sword (n° 151); The Melting Red Shadow (n° 152); Dokuroizo the Grim Reaper (n° 153); Fire Reaper (n° 154); Larvas (n° 155); Hard Armor (n° 156); Firegrass (n° 157); Man Eater (n° 158); Dig Beak (n° 159); M-warrior #1 (n° 160); M-warrior #2 (n° 161); Tainted Wisdom (n° 162); Lisark (n° 163); Lord of Zemia (n° 164); The Judgement Hand (n° 165); Mysterious Puppeteer (n° 166); Ancient Jar (n° 167); Darkfire Dragon (n° 168); Dark King of the Abyss (n° 169); Spirit of the Harp (n° 170); Big Eye (n° 171); Armaill (n° 172); Dark Prisoner (n° 173); Hurricail (n° 174); Ancient Brain (n° 175); Fire Eye (n° 176); Monsturtle (n° 177); Claw Reacher (n° 178); Phantom Dewan (n° 179); Arlownay (n° 180); Dark Shade (n° 181); Masked Clown (n° 182); Lucky Trinket (n° 183); Genin (n° 184); Eyearmor (n° 185); Fiend Refrection #2 (n° 186); Gate Deeg (n° 187); Synchar (n° 188); Fusionist (n° 189); Akakieisu (n° 190); LaLa Li-oon (n° 191); Key Mace (n° 192); Turtle Tiger (n° 193); Terra the Terrible (n° 194); Doron (n° 195); Arma Knight (n° 196); Mech Mole Zombie (n° 197); Happy Lover (n° 198); Penguin Knight (n° 199); Petit Dragon (n° 200); Frenzied Panda (n° 201); Air Marmot of Nefariousness (n° 202); Phantom Ghost (n° 203); Mabarrel (n° 204); Dorover (n° 205); Twin Long Rods #1 (n° 206); Droll Bird (n° 207); Petit Angel (n° 208); Winged Cleaver (n° 209); Hinotama Soul (n° 210); Kaminarikozou (n° 211); Meotoko (n° 212); Aqua Madoor (n° 213); Kagemusha of the Blue Flame (n° 214); Flame Ghost (n° 215); Dryad (n° 216); B. Skull Dragon (n° 217); Two-mouth Darkruler (n° 218); Solitude (n° 219); Masked Sorcerer (n° 220); Kumootoko (n° 221); Midnight Fiend (n° 222); Roaring Ocean Snake (n° 223); Trap Master (n° 224); Fiend Sword (n° 225); Skull Stalker (n° 226); Hitodenchak (n° 227); Wood Remains (n° 228); Hourglass of Life (n° 229); Rare Fish (n° 230); Wood Clown (n° 231); Madjinn Gunn (n° 232); Dark Titan of Terror (n° 233); Beautiful Headhuntress (n° 234); Wodan the Resident of the Forest (n° 235); Guardian of the Labyrinth (n° 236); Haniwa (n° 237); Yashinoki (n° 238); Vishwar Randi (n° 239); The Drdek (n° 240); Dark Assailant (n° 241); Candle of Fate (n° 242); Water Element (n° 243); Dissolverock (n° 244); Meda Bat (n° 245); One Who Hunts Souls (n° 246); Root Water (n° 247); Master & Expert (n° 248); Water Omotics (n° 249); Hyo (n° 250); Enchanting Mermaid (n° 251); Nekogal #1 (n° 252); Angelwitch (n° 253); Embryonic Beast (n° 254); Prevent Rat (n° 255); Dimensional Warrior (n° 256); Stone Armadiller (n° 257); Beastking of the Swamps (n° 258); Ancient Sorcerer (n° 259); Lunar Queen Elzaim (n° 260); Wicked Mirror (n° 261); The Little Swordsman of Aile (n° 262); Rock Ogre Grotto #2 (n° 263); Wing Egg Elf (n° 264); The Furious Sea King (n° 265); Princess of Tsurugi (n° 266); Unknown Warrior of Fiend (n° 267); Sectarian of Secrets (n° 268); Versago the Destroyer (n° 269); Wetha (n° 270); Megirus Light (n° 271); Mavelus (n° 272); Ancient Tree of Enlightenment (n° 273); Green Phantom King (n° 274); Ground Attacker Bugroth (n° 275); Ray & Temperature (n° 276); Gorgon Egg (n° 277); Petit Moth (n° 278); King Fog (n° 279); Protector of the Throne (n° 280); Mystic Clown (n° 281); Mystical Sheep #2 (n° 282); Holograh (n° 283); Tao the Chanter (n° 284); Serpent Marauder (n° 285); Gatekeeper (n° 286); Ogre of the Black Shadow (n° 287); Dark Artist (n° 288); Change Slime (n° 289); Moon Envoy (n° 290); Fireyarou (n° 291); Psychic Kappa (n° 292); Masaki the Legendary Swordsman (n° 293); Dragoness the Wicked Knight (n° 294); Bio Plant (n° 295); One-eyed Shield Dragon (n° 296); Cyber Soldier of Darkworld (n° 297); Wicked Dragon with the Ersatz Head (n° 298); Sonic Maid (n° 299); Kurama (n° 300); Yaranzo (n° 351); Kanan the Swordmistress (n° 352); Takriminos (n° 353); Stuffed Animal (n° 354); Megasonic Eye (n° 355); Super War-lion (n° 356); Yamadron (n° 357); Seiyaryu (n° 358); Three-legged Zombies (n° 359); Zera The Mant (n° 360); Flying Penguin (n° 361); Millennium Shield (n° 362); Fairy's Gift (n° 363); Black Luster Soldier (n° 364); Fiend's Mirror (n° 365); Labyrinth Wall (n° 366); Jirai Gumo (n° 367); Shadow Ghoul (n° 368); Wall Shadow (n° 369); Labyrinth Tank (n° 370); Sanga of the Thunder (n° 371); Kazejin (n° 372); Suijin (n° 373); Gate Guardian (n° 374); Dungeon Worm (n° 375); Monster Tamer (n° 376); Ryu-kishin Powered (n° 377); Swordstalker (n° 378); La Jinn the Mystical Genie (n° 379); Blue-eyes Ultimate Dragon (n° 380); Toon Alligator (n° 381); Rude Kaiser (n° 382); Parrot Dragon (n° 383); Dark Rabbit (n° 384); Bickuribox (n° 385); Harpie's Pet Dragon (n° 386); Mystic Lamp (n° 387); Pendulum Machine (n° 388); Giltia the D. Knight (n° 389); Launcher Spider (n° 390); Zoa (n° 391); Metalzoa (n° 392); Zone Eater (n° 393); Steel Scorpion (n° 394); Dancing Elf (n° 395); Ocubeam (n° 396); Leghul (n° 397); Ooguchi (n° 398); Swordsman from a Foreign Land (n° 399); Emperor of the Land and Sea (n° 400); Ushi Oni (n° 401); Monster Eye (n° 402); Leogun (n° 403); Tatsunootoshigo (n° 404); Saber Slasher (n° 405); Yaiba Robo (n° 406); Machine King (n° 407); Giant Mech-soldier (n° 408); Metal Dragon (n° 409); Mechanical Spider (n° 410); Bat (n° 411); Giga-tech Wolf (n° 412); Cyber Soldier (n° 413); Shovel Crusher (n° 414); Mechanicalchacer (n° 415); Blocker (n° 416); Blast Juggler (n° 417); Golgoil (n° 418); Giganto (n° 419); Cyber-Stein (n° 420); Cyber Commander (n° 421); Jinzo #7 (n° 422); Dice Armadillo (n° 423); Sky Dragon (n° 424); Thunder Dragon (n° 425); Stone D. (n° 426); Kaiser Dragon (n° 427); Magician of Faith (n° 428); Goddess of Whim (n° 429); Water Magician (n° 430); Ice Water (n° 431); Waterdragon Fairy (n° 432); Ancient Elf (n° 433); Beautiful Beast Trainer (n° 434); Water Girl (n° 435); White Dolphin (n° 436); Deepsea Shark (n° 437); Metal Fish (n° 438); Bottom Dweller (n° 439); 7 Colored Fish (n° 440); Mech Bass (n° 441); Aqua Dragon (n° 442); Sea King Dragon (n° 443); Turu-Purun (n° 444); Guardian of the Sea (n° 445); Aqua Snake (n° 446); Giant Red Seasnake (n° 447); Spike Seadra (n° 448); 30,000-Year White Turtle (n° 449); Kappa Avenger (n° 450); Kanikabuto (n° 451); Zarigun (n° 452); Millennium Golem (n° 453); Destroyer Golem (n° 454); Barrel Rock (n° 455); Minomushi Warrior (n° 456); Stone Ghost (n° 457); Kaminari Attack (n° 458); Tripwire Beast (n° 459); Bolt Escargot (n° 460); Bolt Penguin (n° 461); The Immortal of Thunder (n° 462); Electric Snake (n° 463); Wing Eagle (n° 464); Punished Eagle (n° 465); Skull Red Bird (n° 466); Crimson Sunbird (n° 467); Queen Bird (n° 468); Armed Ninja (n° 469); Magical Ghost (n° 470); Soul Hunter (n° 471); Air Eater (n° 472); Vermillion Sparrow (n° 473); Sea Kamen (n° 474); Sinister Serpent (n° 475); Ganigumo (n° 476); Alinsection (n° 477); Insect Soldiers of the Sky (n° 478); Cockroach Knight (n° 479); Kuwagata α (n° 480); Burglar (n° 481); Pragtical (n° 482); Garvas (n° 483); Ameba (n° 484); Korogashi (n° 485); Boo Koo (n° 486); Flower Wolf (n° 487); Rainbow Flower (n° 488); Barrel Lily (n° 489); Needle Ball (n° 490); Peacock (n° 491); Hoshiningen (n° 492); Maha Vailo (n° 493); Rainbow Marine Mermaid (n° 494); Musician King (n° 495); Wilmee (n° 496); Yado Karu (n° 497); Morinphen (n° 498); Kattapillar (n° 499); Dragon Seeker (n° 500); Man-eater Bug (n° 501); D. Human (n° 502); Turtle Raccoon (n° 503); Fungi of the Musk (n° 504); Prisman (n° 505); Gale Dogra (n° 506); Crazy Fish (n° 507); Cyber Saurus (n° 508); Bracchio-raidus (n° 509); Laughing Flower (n° 510); Bean Soldier (n° 511); Cannon Soldier (n° 512); Guardian of the Throne Room (n° 513); Brave Scizzar (n° 514); The Statue of Easter Island (n° 515); Muka Muka (n° 516); Sand Stone (n° 517); Boulder Tortoise (n° 518); Fire Kraken (n° 519); Turtle Bird (n° 520); Skullbird (n° 521); Monstrous Bird (n° 522); The Bistro Butcher (n° 523); Star Boy (n° 524); Spirit of the Mountain (n° 525); Neck Hunter (n° 526); Milus Radiant (n° 527); Togex (n° 528); Flame Cerebrus (n° 529); Eldeen (n° 530); Mystical Sand (n° 531); Gemini Elf (n° 532); Kwagar Hercules (n° 533); Minar (n° 534); Kamakiriman (n° 535); Mechaleon (n° 536); Mega Thunderball (n° 537); Niwatori (n° 538); Corroding Shark (n° 539); Skelengel (n° 540); Hane-Hane (n° 541); Misairuzame (n° 542); Tongyo (n° 543); Dharma Cannon (n° 544); Skelgon (n° 545); Wow Warrior (n° 546); Griggle (n° 547); Bone Mouse (n° 548); Frog The Jam (n° 549); Behegon (n° 550); Dark Elf (n° 551); Winged Dragon #2 (n° 552); Mushroom Man #2 (n° 553); Lava Battleguard (n° 554); Tyhone #2 (n° 555); The Wandering Doomed (n° 556); Steel Ogre Grotto #1 (n° 557); Pot the Trick (n° 558); Oscillo Hero (n° 559); Invader from Another Dimension (n° 560); Lesser Dragon (n° 561); Needle Worm (n° 562); Wretched Ghost of the Attic (n° 563); Great Mammoth of Goldfine (n° 564); Man-eating Black Shark (n° 565); Yormungarde (n° 566); Darkworld Thorns (n° 567); Anthrosaurus (n° 568); Drooling Lizard (n° 569); Trakadon (n° 570); B. Dragon Jungle King (n° 571); Empress Judge (n° 572); Little D (n° 573); Witch of the Black Forest (n° 574); Ancient One of the Deep Forest (n° 575); Giant Scorpion of the Tundra (n° 576); Crow Goblin (n° 577); Leo Wizard (n° 578); Abyss Flower (n° 579); Patrol Robo (n° 580); Takuhee (n° 581); Dark Witch (n° 582); Weather Report (n° 583); Binding Chain (n° 584); Mechanical Snail (n° 585); Greenkappa (n° 586); Mon Larvas (n° 587); Living Vase (n° 588); Tentacle Plant (n° 589); Beaked Snake (n° 590); Morphing Jar (n° 591); Muse-A (n° 592); Giant Turtle Who Feeds on Flames (n° 593); Rose Spectre of Dunn (n° 594); Fiend Refrection #1 (n° 595); Ghoul with an Appetite (n° 596); Pale Beast (n° 597); Little Chimera (n° 598); Violent Rain (n° 599); Key Mace #2 (n° 600); Tenderness (n° 601); Penguin Soldier (n° 602); Fairy Dragon (n° 603); Obese Marmot of Nefariousness (n° 604); Liquid Beast (n° 605); Twin Long Rods #2 (n° 606); Great Bill (n° 607); Shining Friendship (n° 608); Bladefly (n° 609); Electric Lizard (n° 610); Hiro's Shadow Scout (n° 611); Lady of Faith (n° 612); Twin-headed Thunder Dragon (n° 613); Hunter Spider (n° 614); Armored Starfish (n° 615); Hourglass of Courage (n° 616); Marine Beast (n° 617); Warrior of Tradition (n° 618); Rock Spirit (n° 619); Snakeyashi (n° 620); Succubus Knight (n° 621); Ill Witch (n° 622); The Thing That Hides in the Mud (n° 623); High Tide Gyojin (n° 624); Fairy of the Fountain (n° 625); Amazon of the Seas (n° 626); Nekogal #2 (n° 627); Witch's Apprentice (n° 628); Armored Rat (n° 629); Ancient Lizard Warrior (n° 630); Maiden of the Moonlight (n° 631); Stone Ogre Grotto (n° 632); Winged Egg of New Life (n° 633); Night Lizard (n° 634); Queen's Double (n° 635); Blue-winged Crown (n° 636); Trent (n° 637); Queen of Autumn Leaves (n° 638); Amphibious Bugroth (n° 639); Acid Crawler (n° 640); Invader of the Throne (n° 641); Mystical Sheep #1 (n° 642); Disk Magician (n° 643); Flame Viper (n° 644); Royal Guard (n° 645); Gruesome Goo (n° 646); Hyosube (n° 647); Machine Attacker (n° 648); Hibikime (n° 649); Whiptail Crow (n° 650); Performance of Sword (n° 701); Hungry Burger (n° 702); Sengenjin (n° 703); Skull Guardian (n° 704); Tri-horned Dragon (n° 705); Serpent Night Dragon (n° 706); Skull Knight (n° 707); Cosmo Queen (n° 708); Chakra (n° 709); Crab Turtle (n° 710); Mikazukinoyaiba (n° 711); Meteor Dragon (n° 712); Meteor B. Dragon (n° 713); Firewing Pegasus (n° 714); Psycho-Puppet (n° 715); Garma Sword (n° 716); Javelin Beetle (n° 717); Fortress Whale (n° 718); Dokurorider (n° 719); Mask of Shine & Dark (n° 720); Magician of Black Chaos (n° 722).

## Magies — 33 cartes

### 320 — Stop Defense
**Effet d’origine :** Force les monstres adverses en position de défense à passer en position d’attaque. Ne les détruit pas et ne réduit pas leurs statistiques.

**Conditions et limites :** Il faut au moins un monstre adverse en défense pour obtenir le soin proposé.

| Rareté | Effet total selon la rareté |
|---|---|
| Normale | Force les monstres adverses en position de défense à passer en position d’attaque. Ne les détruit pas et ne réduit pas leurs statistiques. |
| Rare | Même effet décrit ci-dessus, puis **tu récupères 100 PV** après son succès. |
| Épique | Même effet décrit ci-dessus, puis **tu récupères 300 PV** après son succès. |
| Légendaire | Même effet décrit ci-dessus, puis **tu récupères 500 PV** après son succès. |
| Mythique | Même effet décrit ci-dessus, puis **tu récupères 800 PV** après son succès. |

### 329 — Dragon Capture Jar
**Effet d’origine :** Détruit les monstres de type Dragon présents sur le terrain adverse. Les autres types ne sont pas concernés.

**Conditions et limites :** Au moins un Dragon adverse doit être détruit pour obtenir le soin.

| Rareté | Effet total selon la rareté |
|---|---|
| Normale | Détruit les monstres de type Dragon présents sur le terrain adverse. Les autres types ne sont pas concernés. |
| Rare | Même effet décrit ci-dessus, puis **tu récupères 100 PV** après son succès. |
| Épique | Même effet décrit ci-dessus, puis **tu récupères 300 PV** après son succès. |
| Légendaire | Même effet décrit ci-dessus, puis **tu récupères 500 PV** après son succès. |
| Mythique | Même effet décrit ci-dessus, puis **tu récupères 800 PV** après son succès. |

### 330 — Forest
**Effet d’origine :** Change le terrain actif. Les monstres de type **Bête-Guerrier, Bête, Insecte et Plante** gagnent **500 ATK et 500 DEF**, dans les deux camps. Les autres types ne reçoivent aucun changement. Le terrain reste actif jusqu’à son remplacement.

**Conditions et limites :** Le supplément ne s’applique qu’au propriétaire de la variante de terrain et aux types normalement favorisés. Les pénalités normales restent identiques dans les deux camps. Un nouveau terrain remplace le précédent ; les terrains ne s’empilent pas. Ce partage par propriétaire demande du code supplémentaire.

| Rareté | Effet total selon la rareté |
|---|---|
| Normale | Les types favorisés gagnent **500 ATK et 500 DEF** dans les deux camps. |
| Rare | Tes monstres des types favorisés gagnent **600 ATK et 600 DEF** ; ceux de l’adversaire gardent le bonus normal de 500. |
| Épique | Tes monstres des types favorisés gagnent **800 ATK et 800 DEF** ; ceux de l’adversaire gardent le bonus normal de 500. |
| Légendaire | Tes monstres des types favorisés gagnent **1000 ATK et 1000 DEF** ; ceux de l’adversaire gardent le bonus normal de 500. |
| Mythique | Tes monstres des types favorisés gagnent **1300 ATK et 1300 DEF** ; ceux de l’adversaire gardent le bonus normal de 500. |

### 331 — Wasteland
**Effet d’origine :** Change le terrain actif. Les monstres de type **Zombie, Dinosaure et Rocher** gagnent **500 ATK et 500 DEF**, dans les deux camps. Les autres types ne reçoivent aucun changement. Le terrain reste actif jusqu’à son remplacement.

**Conditions et limites :** Le supplément ne s’applique qu’au propriétaire de la variante de terrain et aux types normalement favorisés. Les pénalités normales restent identiques dans les deux camps. Un nouveau terrain remplace le précédent ; les terrains ne s’empilent pas. Ce partage par propriétaire demande du code supplémentaire.

| Rareté | Effet total selon la rareté |
|---|---|
| Normale | Les types favorisés gagnent **500 ATK et 500 DEF** dans les deux camps. |
| Rare | Tes monstres des types favorisés gagnent **600 ATK et 600 DEF** ; ceux de l’adversaire gardent le bonus normal de 500. |
| Épique | Tes monstres des types favorisés gagnent **800 ATK et 800 DEF** ; ceux de l’adversaire gardent le bonus normal de 500. |
| Légendaire | Tes monstres des types favorisés gagnent **1000 ATK et 1000 DEF** ; ceux de l’adversaire gardent le bonus normal de 500. |
| Mythique | Tes monstres des types favorisés gagnent **1300 ATK et 1300 DEF** ; ceux de l’adversaire gardent le bonus normal de 500. |

### 332 — Mountain
**Effet d’origine :** Change le terrain actif. Les monstres de type **Dragon, Bête Ailée et Tonnerre** gagnent **500 ATK et 500 DEF**, dans les deux camps. Les autres types ne reçoivent aucun changement. Le terrain reste actif jusqu’à son remplacement.

**Conditions et limites :** Le supplément ne s’applique qu’au propriétaire de la variante de terrain et aux types normalement favorisés. Les pénalités normales restent identiques dans les deux camps. Un nouveau terrain remplace le précédent ; les terrains ne s’empilent pas. Ce partage par propriétaire demande du code supplémentaire.

| Rareté | Effet total selon la rareté |
|---|---|
| Normale | Les types favorisés gagnent **500 ATK et 500 DEF** dans les deux camps. |
| Rare | Tes monstres des types favorisés gagnent **600 ATK et 600 DEF** ; ceux de l’adversaire gardent le bonus normal de 500. |
| Épique | Tes monstres des types favorisés gagnent **800 ATK et 800 DEF** ; ceux de l’adversaire gardent le bonus normal de 500. |
| Légendaire | Tes monstres des types favorisés gagnent **1000 ATK et 1000 DEF** ; ceux de l’adversaire gardent le bonus normal de 500. |
| Mythique | Tes monstres des types favorisés gagnent **1300 ATK et 1300 DEF** ; ceux de l’adversaire gardent le bonus normal de 500. |

### 333 — Sogen
**Effet d’origine :** Change le terrain actif. Les monstres de type **Guerrier et Bête-Guerrier** gagnent **500 ATK et 500 DEF**, dans les deux camps. Les autres types ne reçoivent aucun changement. Le terrain reste actif jusqu’à son remplacement.

**Conditions et limites :** Le supplément ne s’applique qu’au propriétaire de la variante de terrain et aux types normalement favorisés. Les pénalités normales restent identiques dans les deux camps. Un nouveau terrain remplace le précédent ; les terrains ne s’empilent pas. Ce partage par propriétaire demande du code supplémentaire.

| Rareté | Effet total selon la rareté |
|---|---|
| Normale | Les types favorisés gagnent **500 ATK et 500 DEF** dans les deux camps. |
| Rare | Tes monstres des types favorisés gagnent **600 ATK et 600 DEF** ; ceux de l’adversaire gardent le bonus normal de 500. |
| Épique | Tes monstres des types favorisés gagnent **800 ATK et 800 DEF** ; ceux de l’adversaire gardent le bonus normal de 500. |
| Légendaire | Tes monstres des types favorisés gagnent **1000 ATK et 1000 DEF** ; ceux de l’adversaire gardent le bonus normal de 500. |
| Mythique | Tes monstres des types favorisés gagnent **1300 ATK et 1300 DEF** ; ceux de l’adversaire gardent le bonus normal de 500. |

### 334 — Umi
**Effet d’origine :** Change le terrain actif. Les monstres de type **Poisson, Serpent de Mer, Tonnerre et Aqua** gagnent **500 ATK et 500 DEF**, dans les deux camps. Les types **Machine et Pyro** perdent **500 ATK et 500 DEF**, dans les deux camps. Les autres types ne reçoivent aucun changement. Le terrain reste actif jusqu’à son remplacement.

**Conditions et limites :** Le supplément ne s’applique qu’au propriétaire de la variante de terrain et aux types normalement favorisés. Les pénalités normales restent identiques dans les deux camps. Un nouveau terrain remplace le précédent ; les terrains ne s’empilent pas. Ce partage par propriétaire demande du code supplémentaire.

| Rareté | Effet total selon la rareté |
|---|---|
| Normale | Les types favorisés gagnent **500 ATK et 500 DEF** dans les deux camps. |
| Rare | Tes monstres des types favorisés gagnent **600 ATK et 600 DEF** ; ceux de l’adversaire gardent le bonus normal de 500. |
| Épique | Tes monstres des types favorisés gagnent **800 ATK et 800 DEF** ; ceux de l’adversaire gardent le bonus normal de 500. |
| Légendaire | Tes monstres des types favorisés gagnent **1000 ATK et 1000 DEF** ; ceux de l’adversaire gardent le bonus normal de 500. |
| Mythique | Tes monstres des types favorisés gagnent **1300 ATK et 1300 DEF** ; ceux de l’adversaire gardent le bonus normal de 500. |

### 335 — Yami
**Effet d’origine :** Change le terrain actif. Les monstres de type **Magicien et Démon** gagnent **500 ATK et 500 DEF**, dans les deux camps. Les types **Elfe/Fée** perdent **500 ATK et 500 DEF**, dans les deux camps. Les autres types ne reçoivent aucun changement. Le terrain reste actif jusqu’à son remplacement.

**Conditions et limites :** Le supplément ne s’applique qu’au propriétaire de la variante de terrain et aux types normalement favorisés. Les pénalités normales restent identiques dans les deux camps. Un nouveau terrain remplace le précédent ; les terrains ne s’empilent pas. Ce partage par propriétaire demande du code supplémentaire.

| Rareté | Effet total selon la rareté |
|---|---|
| Normale | Les types favorisés gagnent **500 ATK et 500 DEF** dans les deux camps. |
| Rare | Tes monstres des types favorisés gagnent **600 ATK et 600 DEF** ; ceux de l’adversaire gardent le bonus normal de 500. |
| Épique | Tes monstres des types favorisés gagnent **800 ATK et 800 DEF** ; ceux de l’adversaire gardent le bonus normal de 500. |
| Légendaire | Tes monstres des types favorisés gagnent **1000 ATK et 1000 DEF** ; ceux de l’adversaire gardent le bonus normal de 500. |
| Mythique | Tes monstres des types favorisés gagnent **1300 ATK et 1300 DEF** ; ceux de l’adversaire gardent le bonus normal de 500. |

### 336 — Dark Hole
**Effet d’origine :** Détruit toutes les cartes présentes sur les deux terrains, y compris tes propres cartes : monstres et cartes de la rangée Magie/Piège.

**Conditions et limites :** Attention : ce nettoyage touche aussi ton camp. Le soin proposé demande qu’au moins une carte soit détruite.

| Rareté | Effet total selon la rareté |
|---|---|
| Normale | Détruit toutes les cartes présentes sur les deux terrains, y compris tes propres cartes : monstres et cartes de la rangée Magie/Piège. |
| Rare | Même effet décrit ci-dessus, puis **tu récupères 100 PV** après son succès. |
| Épique | Même effet décrit ci-dessus, puis **tu récupères 300 PV** après son succès. |
| Légendaire | Même effet décrit ci-dessus, puis **tu récupères 500 PV** après son succès. |
| Mythique | Même effet décrit ci-dessus, puis **tu récupères 800 PV** après son succès. |

### 337 — Raigeki
**Effet d’origine :** Détruit tous les monstres présents sur le terrain adverse. Tes monstres et la rangée Magie/Piège adverse restent en place.

**Conditions et limites :** Au moins un monstre adverse doit être détruit pour obtenir le soin.

| Rareté | Effet total selon la rareté |
|---|---|
| Normale | Détruit tous les monstres présents sur le terrain adverse. Tes monstres et la rangée Magie/Piège adverse restent en place. |
| Rare | Même effet décrit ci-dessus, puis **tu récupères 100 PV** après son succès. |
| Épique | Même effet décrit ci-dessus, puis **tu récupères 300 PV** après son succès. |
| Légendaire | Même effet décrit ci-dessus, puis **tu récupères 500 PV** après son succès. |
| Mythique | Même effet décrit ci-dessus, puis **tu récupères 800 PV** après son succès. |

### 338 — Mooyan Curry
**Effet d’origine :** Te rend **200 PV**. Ne renforce pas tes monstres et ne blesse pas directement l’adversaire.

**Conditions et limites :** Le soin est limité par le plafond de PV du duel. Bad Reaction to Simochi adverse peut transformer la quantité de soin en perte de PV.

| Rareté | Effet total selon la rareté |
|---|---|
| Normale | Tu récupères **200 PV**. |
| Rare | Tu récupères **300 PV**. |
| Épique | Tu récupères **500 PV**. |
| Légendaire | Tu récupères **700 PV**. |
| Mythique | Tu récupères **1000 PV**. |

### 339 — Red Medicine
**Effet d’origine :** Te rend **500 PV**. Ne renforce pas tes monstres et ne blesse pas directement l’adversaire.

**Conditions et limites :** Le soin est limité par le plafond de PV du duel. Bad Reaction to Simochi adverse peut transformer la quantité de soin en perte de PV.

| Rareté | Effet total selon la rareté |
|---|---|
| Normale | Tu récupères **500 PV**. |
| Rare | Tu récupères **600 PV**. |
| Épique | Tu récupères **800 PV**. |
| Légendaire | Tu récupères **1000 PV**. |
| Mythique | Tu récupères **1300 PV**. |

### 340 — Goblin's Secret Remedy
**Effet d’origine :** Te rend **1000 PV**. Ne renforce pas tes monstres et ne blesse pas directement l’adversaire.

**Conditions et limites :** Le soin est limité par le plafond de PV du duel. Bad Reaction to Simochi adverse peut transformer la quantité de soin en perte de PV.

| Rareté | Effet total selon la rareté |
|---|---|
| Normale | Tu récupères **1000 PV**. |
| Rare | Tu récupères **1100 PV**. |
| Épique | Tu récupères **1300 PV**. |
| Légendaire | Tu récupères **1500 PV**. |
| Mythique | Tu récupères **1800 PV**. |

### 341 — Soul of the Pure
**Effet d’origine :** Te rend **2000 PV**. Ne renforce pas tes monstres et ne blesse pas directement l’adversaire.

**Conditions et limites :** Le soin est limité par le plafond de PV du duel. Bad Reaction to Simochi adverse peut transformer la quantité de soin en perte de PV.

| Rareté | Effet total selon la rareté |
|---|---|
| Normale | Tu récupères **2000 PV**. |
| Rare | Tu récupères **2100 PV**. |
| Épique | Tu récupères **2300 PV**. |
| Légendaire | Tu récupères **2500 PV**. |
| Mythique | Tu récupères **2800 PV**. |

### 342 — Dian Keto the Cure Master
**Effet d’origine :** Te rend **5000 PV**. Ne renforce pas tes monstres et ne blesse pas directement l’adversaire.

**Conditions et limites :** Le soin est limité par le plafond de PV du duel. Bad Reaction to Simochi adverse peut transformer la quantité de soin en perte de PV.

| Rareté | Effet total selon la rareté |
|---|---|
| Normale | Tu récupères **5000 PV**. |
| Rare | Tu récupères **5100 PV**. |
| Épique | Tu récupères **5300 PV**. |
| Légendaire | Tu récupères **5500 PV**. |
| Mythique | Tu récupères **5800 PV**. |

### 343 — Sparks
**Effet d’origine :** Retire directement **50 PV à l’adversaire**, sans attaque de monstre. Aucun dégât de contrecoup n’est ajouté à tes propres PV.

**Conditions et limites :** Goblin Fan adverse peut renvoyer les dégâts vers toi. Les PV ne descendent pas sous zéro.

| Rareté | Effet total selon la rareté |
|---|---|
| Normale | L’adversaire perd **50 PV**. |
| Rare | L’adversaire perd **150 PV**. |
| Épique | L’adversaire perd **350 PV**. |
| Légendaire | L’adversaire perd **550 PV**. |
| Mythique | L’adversaire perd **850 PV**. |

### 344 — Hinotama
**Effet d’origine :** Retire directement **100 PV à l’adversaire**, sans attaque de monstre. Aucun dégât de contrecoup n’est ajouté à tes propres PV.

**Conditions et limites :** Goblin Fan adverse peut renvoyer les dégâts vers toi. Les PV ne descendent pas sous zéro.

| Rareté | Effet total selon la rareté |
|---|---|
| Normale | L’adversaire perd **100 PV**. |
| Rare | L’adversaire perd **200 PV**. |
| Épique | L’adversaire perd **400 PV**. |
| Légendaire | L’adversaire perd **600 PV**. |
| Mythique | L’adversaire perd **900 PV**. |

### 345 — Final Flame
**Effet d’origine :** Retire directement **200 PV à l’adversaire**, sans attaque de monstre. Aucun dégât de contrecoup n’est ajouté à tes propres PV.

**Conditions et limites :** Goblin Fan adverse peut renvoyer les dégâts vers toi. Les PV ne descendent pas sous zéro.

| Rareté | Effet total selon la rareté |
|---|---|
| Normale | L’adversaire perd **200 PV**. |
| Rare | L’adversaire perd **300 PV**. |
| Épique | L’adversaire perd **500 PV**. |
| Légendaire | L’adversaire perd **700 PV**. |
| Mythique | L’adversaire perd **1000 PV**. |

### 346 — Ookazi
**Effet d’origine :** Retire directement **500 PV à l’adversaire**, sans attaque de monstre. Aucun dégât de contrecoup n’est ajouté à tes propres PV.

**Conditions et limites :** Goblin Fan adverse peut renvoyer les dégâts vers toi. Les PV ne descendent pas sous zéro.

| Rareté | Effet total selon la rareté |
|---|---|
| Normale | L’adversaire perd **500 PV**. |
| Rare | L’adversaire perd **600 PV**. |
| Épique | L’adversaire perd **800 PV**. |
| Légendaire | L’adversaire perd **1000 PV**. |
| Mythique | L’adversaire perd **1300 PV**. |

### 347 — Tremendous Fire
**Effet d’origine :** Retire directement **1000 PV à l’adversaire**, sans attaque de monstre. Aucun dégât de contrecoup n’est ajouté à tes propres PV.

**Conditions et limites :** Goblin Fan adverse peut renvoyer les dégâts vers toi. Les PV ne descendent pas sous zéro.

| Rareté | Effet total selon la rareté |
|---|---|
| Normale | L’adversaire perd **1000 PV**. |
| Rare | L’adversaire perd **1100 PV**. |
| Épique | L’adversaire perd **1300 PV**. |
| Légendaire | L’adversaire perd **1500 PV**. |
| Mythique | L’adversaire perd **1800 PV**. |

### 348 — Swords of Revealing Light
**Effet d’origine :** Empêche l’adversaire d’attaquer pendant **3 tours** et révèle ses monstres face cachée concernés par l’effet. Ne détruit pas ses monstres et ne l’empêche pas de poser des cartes ou d’utiliser des Magies.

**Conditions et limites :** La révélation reste identique. Les PV indiqués sont un soin à l’activation, pas à chaque tour. La durée mythique proposée reste limitée à cinq tours.

| Rareté | Effet total selon la rareté |
|---|---|
| Normale | Bloque les attaques adverses pendant **3 tours**. |
| Rare | Bloque pendant **3 tours**, et te rend **100 PV**. |
| Épique | Bloque pendant **4 tours**. |
| Légendaire | Bloque pendant **4 tours**, et te rend **300 PV**. |
| Mythique | Bloque pendant **5 tours**. |

### 349 — Spellbinding Circle
**Effet d’origine :** Diminue de **500 points l’ATK et de 500 points la DEF** des monstres présents sur le terrain adverse. Ne détruit pas ces monstres et ne leur interdit pas d’attaquer.

**Conditions et limites :** Ne touche pas les monstres qui seront posés après l’activation. Les statistiques restent au minimum à zéro. Cursebreaker peut retirer ces pénalités.

| Rareté | Effet total selon la rareté |
|---|---|
| Normale | Les monstres adverses présents perdent **500 ATK et 500 DEF**. |
| Rare | Les monstres adverses présents perdent **600 ATK et 600 DEF**. |
| Épique | Les monstres adverses présents perdent **800 ATK et 800 DEF**. |
| Légendaire | Les monstres adverses présents perdent **1000 ATK et 1000 DEF**. |
| Mythique | Les monstres adverses présents perdent **1300 ATK et 1300 DEF**. |

### 350 — Dark-piercing Light
**Effet d’origine :** Retourne face visible les cartes adverses face cachée concernées par la révélation du jeu. Ne les détruit pas et n’ajoute aucun bonus d’attaque.

**Conditions et limites :** Le soin proposé nécessite qu’au moins une carte cachée soit révélée.

| Rareté | Effet total selon la rareté |
|---|---|
| Normale | Retourne face visible les cartes adverses face cachée concernées par la révélation du jeu. Ne les détruit pas et n’ajoute aucun bonus d’attaque. |
| Rare | Même effet décrit ci-dessus, puis **tu récupères 100 PV** après son succès. |
| Épique | Même effet décrit ci-dessus, puis **tu récupères 300 PV** après son succès. |
| Légendaire | Même effet décrit ci-dessus, puis **tu récupères 500 PV** après son succès. |
| Mythique | Même effet décrit ci-dessus, puis **tu récupères 800 PV** après son succès. |

### 653 — Warrior Elimination
**Effet d’origine :** Détruit tous les monstres de type Guerrier présents sur le terrain adverse. Les autres types et tes propres monstres ne sont pas concernés.

**Conditions et limites :** Le soin proposé est accordé seulement si au moins un monstre ciblé est détruit.

| Rareté | Effet total selon la rareté |
|---|---|
| Normale | Détruit tous les monstres de type Guerrier présents sur le terrain adverse. Les autres types et tes propres monstres ne sont pas concernés. |
| Rare | Même effet décrit ci-dessus, puis **tu récupères 100 PV** après son succès. |
| Épique | Même effet décrit ci-dessus, puis **tu récupères 300 PV** après son succès. |
| Légendaire | Même effet décrit ci-dessus, puis **tu récupères 500 PV** après son succès. |
| Mythique | Même effet décrit ci-dessus, puis **tu récupères 800 PV** après son succès. |

### 655 — Cursebreaker
**Effet d’origine :** Supprime les diminutions accumulées dans le modificateur de statistiques de tes monstres actuellement sur le terrain : le modificateur négatif revient à zéro. Ne supprime pas les pénalités propres au terrain.

**Conditions et limites :** Au moins un monstre doit réellement récupérer des statistiques pour obtenir le soin.

| Rareté | Effet total selon la rareté |
|---|---|
| Normale | Supprime les diminutions accumulées dans le modificateur de statistiques de tes monstres actuellement sur le terrain : le modificateur négatif revient à zéro. Ne supprime pas les pénalités propres au terrain. |
| Rare | Même effet décrit ci-dessus, puis **tu récupères 100 PV** après son succès. |
| Épique | Même effet décrit ci-dessus, puis **tu récupères 300 PV** après son succès. |
| Légendaire | Même effet décrit ci-dessus, puis **tu récupères 500 PV** après son succès. |
| Mythique | Même effet décrit ci-dessus, puis **tu récupères 800 PV** après son succès. |

### 656 — Eternal Rest
**Effet d’origine :** Détruit tous les monstres de type Zombie présents sur le terrain adverse. Les autres types et tes propres monstres ne sont pas concernés.

**Conditions et limites :** Le soin proposé est accordé seulement si au moins un monstre ciblé est détruit.

| Rareté | Effet total selon la rareté |
|---|---|
| Normale | Détruit tous les monstres de type Zombie présents sur le terrain adverse. Les autres types et tes propres monstres ne sont pas concernés. |
| Rare | Même effet décrit ci-dessus, puis **tu récupères 100 PV** après son succès. |
| Épique | Même effet décrit ci-dessus, puis **tu récupères 300 PV** après son succès. |
| Légendaire | Même effet décrit ci-dessus, puis **tu récupères 500 PV** après son succès. |
| Mythique | Même effet décrit ci-dessus, puis **tu récupères 800 PV** après son succès. |

### 660 — Stain Storm
**Effet d’origine :** Détruit tous les monstres de type Machine présents sur le terrain adverse. Les autres types et tes propres monstres ne sont pas concernés.

**Conditions et limites :** Le soin proposé est accordé seulement si au moins un monstre ciblé est détruit.

| Rareté | Effet total selon la rareté |
|---|---|
| Normale | Détruit tous les monstres de type Machine présents sur le terrain adverse. Les autres types et tes propres monstres ne sont pas concernés. |
| Rare | Même effet décrit ci-dessus, puis **tu récupères 100 PV** après son succès. |
| Épique | Même effet décrit ci-dessus, puis **tu récupères 300 PV** après son succès. |
| Légendaire | Même effet décrit ci-dessus, puis **tu récupères 500 PV** après son succès. |
| Mythique | Même effet décrit ci-dessus, puis **tu récupères 800 PV** après son succès. |

### 661 — Crush Card
**Effet d’origine :** Détruit les monstres adverses présents dont l’ATK effective est **supérieure ou égale à 1500**. Ne sacrifie pas un de tes monstres pour activer cet effet dans Forbidden Memories.

**Conditions et limites :** Le seuil est inclus : un monstre exactement à la valeur indiquée est détruit. Baisser le seuil rend la carte plus forte, car davantage de monstres sont concernés. Ne touche pas les futures invocations.

| Rareté | Effet total selon la rareté |
|---|---|
| Normale | Détruit les monstres adverses présents ayant **au moins 1500 ATK**. |
| Rare | Détruit les monstres adverses présents ayant **au moins 1400 ATK**. |
| Épique | Détruit les monstres adverses présents ayant **au moins 1200 ATK**. |
| Légendaire | Détruit les monstres adverses présents ayant **au moins 1000 ATK**. |
| Mythique | Détruit les monstres adverses présents ayant **au moins 700 ATK**. |

### 662 — Eradicating Aerosol
**Effet d’origine :** Détruit tous les monstres de type Insecte présents sur le terrain adverse. Les autres types et tes propres monstres ne sont pas concernés.

**Conditions et limites :** Le soin proposé est accordé seulement si au moins un monstre ciblé est détruit.

| Rareté | Effet total selon la rareté |
|---|---|
| Normale | Détruit tous les monstres de type Insecte présents sur le terrain adverse. Les autres types et tes propres monstres ne sont pas concernés. |
| Rare | Même effet décrit ci-dessus, puis **tu récupères 100 PV** après son succès. |
| Épique | Même effet décrit ci-dessus, puis **tu récupères 300 PV** après son succès. |
| Légendaire | Même effet décrit ci-dessus, puis **tu récupères 500 PV** après son succès. |
| Mythique | Même effet décrit ci-dessus, puis **tu récupères 800 PV** après son succès. |

### 663 — Breath of Light
**Effet d’origine :** Détruit tous les monstres de type Rocher présents sur le terrain adverse. Les autres types et tes propres monstres ne sont pas concernés.

**Conditions et limites :** Le soin proposé est accordé seulement si au moins un monstre ciblé est détruit.

| Rareté | Effet total selon la rareté |
|---|---|
| Normale | Détruit tous les monstres de type Rocher présents sur le terrain adverse. Les autres types et tes propres monstres ne sont pas concernés. |
| Rare | Même effet décrit ci-dessus, puis **tu récupères 100 PV** après son succès. |
| Épique | Même effet décrit ci-dessus, puis **tu récupères 300 PV** après son succès. |
| Légendaire | Même effet décrit ci-dessus, puis **tu récupères 500 PV** après son succès. |
| Mythique | Même effet décrit ci-dessus, puis **tu récupères 800 PV** après son succès. |

### 664 — Eternal Draught
**Effet d’origine :** Détruit tous les monstres de type Poisson présents sur le terrain adverse. Les autres types et tes propres monstres ne sont pas concernés.

**Conditions et limites :** Le soin proposé est accordé seulement si au moins un monstre ciblé est détruit.

| Rareté | Effet total selon la rareté |
|---|---|
| Normale | Détruit tous les monstres de type Poisson présents sur le terrain adverse. Les autres types et tes propres monstres ne sont pas concernés. |
| Rare | Même effet décrit ci-dessus, puis **tu récupères 100 PV** après son succès. |
| Épique | Même effet décrit ci-dessus, puis **tu récupères 300 PV** après son succès. |
| Légendaire | Même effet décrit ci-dessus, puis **tu récupères 500 PV** après son succès. |
| Mythique | Même effet décrit ci-dessus, puis **tu récupères 800 PV** après son succès. |

### 669 — Shadow Spell
**Effet d’origine :** Diminue de **1000 points l’ATK et de 1000 points la DEF** des monstres présents sur le terrain adverse. Ne détruit pas ces monstres et ne leur interdit pas d’attaquer.

**Conditions et limites :** Ne touche pas les monstres qui seront posés après l’activation. Les statistiques restent au minimum à zéro. Cursebreaker peut retirer ces pénalités.

| Rareté | Effet total selon la rareté |
|---|---|
| Normale | Les monstres adverses présents perdent **1000 ATK et 1000 DEF**. |
| Rare | Les monstres adverses présents perdent **1100 ATK et 1100 DEF**. |
| Épique | Les monstres adverses présents perdent **1300 ATK et 1300 DEF**. |
| Légendaire | Les monstres adverses présents perdent **1500 ATK et 1500 DEF**. |
| Mythique | Les monstres adverses présents perdent **1800 ATK et 1800 DEF**. |

### 672 — Harpie's Feather Duster
**Effet d’origine :** Détruit les cartes de la rangée Magie/Piège adverse. Ne détruit pas les monstres adverses et ne touche pas tes propres cartes.

**Conditions et limites :** Au moins une carte adverse de cette rangée doit être détruite pour obtenir le soin.

| Rareté | Effet total selon la rareté |
|---|---|
| Normale | Détruit les cartes de la rangée Magie/Piège adverse. Ne détruit pas les monstres adverses et ne touche pas tes propres cartes. |
| Rare | Même effet décrit ci-dessus, puis **tu récupères 100 PV** après son succès. |
| Épique | Même effet décrit ci-dessus, puis **tu récupères 300 PV** après son succès. |
| Légendaire | Même effet décrit ci-dessus, puis **tu récupères 500 PV** après son succès. |
| Mythique | Même effet décrit ci-dessus, puis **tu récupères 800 PV** après son succès. |

## Pièges — 10 cartes

### 681 — House of Adhesive Tape
**Effet d’origine :** Piège à poser avant l’attaque adverse. Se déclenche si le monstre qui attaque possède **500 ATK ou moins**, et détruit ce monstre. S’il dépasse le seuil, ce piège ne le détruit pas.

**Conditions et limites :** Le seuil porte sur l’ATK effective au moment de l’attaque. Aucune perte directe de PV n’est ajoutée. La limite est incluse.

| Rareté | Effet total selon la rareté |
|---|---|
| Normale | Détruit le monstre attaquant si son ATK est **≤ 500**. |
| Rare | Détruit le monstre attaquant si son ATK est **≤ 600**. |
| Épique | Détruit le monstre attaquant si son ATK est **≤ 800**. |
| Légendaire | Détruit le monstre attaquant si son ATK est **≤ 1000**. |
| Mythique | Détruit le monstre attaquant si son ATK est **≤ 1300**. |

### 682 — Eatgaboon
**Effet d’origine :** Piège à poser avant l’attaque adverse. Se déclenche si le monstre qui attaque possède **1000 ATK ou moins**, et détruit ce monstre. S’il dépasse le seuil, ce piège ne le détruit pas.

**Conditions et limites :** Le seuil porte sur l’ATK effective au moment de l’attaque. Aucune perte directe de PV n’est ajoutée. La limite est incluse.

| Rareté | Effet total selon la rareté |
|---|---|
| Normale | Détruit le monstre attaquant si son ATK est **≤ 1000**. |
| Rare | Détruit le monstre attaquant si son ATK est **≤ 1100**. |
| Épique | Détruit le monstre attaquant si son ATK est **≤ 1300**. |
| Légendaire | Détruit le monstre attaquant si son ATK est **≤ 1500**. |
| Mythique | Détruit le monstre attaquant si son ATK est **≤ 1800**. |

### 683 — Bear Trap
**Effet d’origine :** Piège à poser avant l’attaque adverse. Se déclenche si le monstre qui attaque possède **1500 ATK ou moins**, et détruit ce monstre. S’il dépasse le seuil, ce piège ne le détruit pas.

**Conditions et limites :** Le seuil porte sur l’ATK effective au moment de l’attaque. Aucune perte directe de PV n’est ajoutée. La limite est incluse.

| Rareté | Effet total selon la rareté |
|---|---|
| Normale | Détruit le monstre attaquant si son ATK est **≤ 1500**. |
| Rare | Détruit le monstre attaquant si son ATK est **≤ 1600**. |
| Épique | Détruit le monstre attaquant si son ATK est **≤ 1800**. |
| Légendaire | Détruit le monstre attaquant si son ATK est **≤ 2000**. |
| Mythique | Détruit le monstre attaquant si son ATK est **≤ 2300**. |

### 684 — Invisible Wire
**Effet d’origine :** Piège à poser avant l’attaque adverse. Se déclenche si le monstre qui attaque possède **2000 ATK ou moins**, et détruit ce monstre. S’il dépasse le seuil, ce piège ne le détruit pas.

**Conditions et limites :** Le seuil porte sur l’ATK effective au moment de l’attaque. Aucune perte directe de PV n’est ajoutée. La limite est incluse.

| Rareté | Effet total selon la rareté |
|---|---|
| Normale | Détruit le monstre attaquant si son ATK est **≤ 2000**. |
| Rare | Détruit le monstre attaquant si son ATK est **≤ 2100**. |
| Épique | Détruit le monstre attaquant si son ATK est **≤ 2300**. |
| Légendaire | Détruit le monstre attaquant si son ATK est **≤ 2500**. |
| Mythique | Détruit le monstre attaquant si son ATK est **≤ 2800**. |

### 685 — Acid Trap Hole
**Effet d’origine :** Piège à poser avant l’attaque adverse. Se déclenche si le monstre qui attaque possède **3000 ATK ou moins**, et détruit ce monstre. S’il dépasse le seuil, ce piège ne le détruit pas.

**Conditions et limites :** Le seuil porte sur l’ATK effective au moment de l’attaque. Aucune perte directe de PV n’est ajoutée. La limite est incluse.

| Rareté | Effet total selon la rareté |
|---|---|
| Normale | Détruit le monstre attaquant si son ATK est **≤ 3000**. |
| Rare | Détruit le monstre attaquant si son ATK est **≤ 3100**. |
| Épique | Détruit le monstre attaquant si son ATK est **≤ 3300**. |
| Légendaire | Détruit le monstre attaquant si son ATK est **≤ 3500**. |
| Mythique | Détruit le monstre attaquant si son ATK est **≤ 3800**. |

### 686 — Widespread Ruin
**Effet d’origine :** Se déclenche sur une attaque adverse et détruit le monstre qui attaque, sans la limite d’ATK des cinq premiers pièges de destruction.

**Conditions et limites :** Il cible l’attaquant : ce n’est pas un nettoyage de tous les monstres adverses. Le soin proposé est accordé après la destruction réussie.

| Rareté | Effet total selon la rareté |
|---|---|
| Normale | Se déclenche sur une attaque adverse et détruit le monstre qui attaque, sans la limite d’ATK des cinq premiers pièges de destruction. |
| Rare | Même effet décrit ci-dessus, puis **tu récupères 100 PV** après son succès. |
| Épique | Même effet décrit ci-dessus, puis **tu récupères 300 PV** après son succès. |
| Légendaire | Même effet décrit ci-dessus, puis **tu récupères 500 PV** après son succès. |
| Mythique | Même effet décrit ci-dessus, puis **tu récupères 800 PV** après son succès. |

### 687 — Goblin Fan
**Effet d’origine :** Se déclenche lorsque l’adversaire utilise une des Magies de dégâts directs. Les dégâts sont renvoyés vers le joueur qui a lancé cette Magie, au lieu de toucher tes PV.

**Conditions et limites :** Ne renvoie pas les dégâts d’un combat. Le soin proposé est accordé après le renvoi réussi.

| Rareté | Effet total selon la rareté |
|---|---|
| Normale | Se déclenche lorsque l’adversaire utilise une des Magies de dégâts directs. Les dégâts sont renvoyés vers le joueur qui a lancé cette Magie, au lieu de toucher tes PV. |
| Rare | Même effet décrit ci-dessus, puis **tu récupères 100 PV** après son succès. |
| Épique | Même effet décrit ci-dessus, puis **tu récupères 300 PV** après son succès. |
| Légendaire | Même effet décrit ci-dessus, puis **tu récupères 500 PV** après son succès. |
| Mythique | Même effet décrit ci-dessus, puis **tu récupères 800 PV** après son succès. |

### 688 — Bad Reaction to Simochi
**Effet d’origine :** Se déclenche lorsque l’adversaire utilise une Magie de soin. La quantité qu’il devait récupérer est retirée de ses PV à la place.

**Conditions et limites :** Exemple : Red Medicine normale lui fait perdre 500 PV au lieu de lui en rendre 500. Le soin supplémentaire proposé profite au propriétaire du piège après ce déclenchement.

| Rareté | Effet total selon la rareté |
|---|---|
| Normale | Se déclenche lorsque l’adversaire utilise une Magie de soin. La quantité qu’il devait récupérer est retirée de ses PV à la place. |
| Rare | Même effet décrit ci-dessus, puis **tu récupères 100 PV** après son succès. |
| Épique | Même effet décrit ci-dessus, puis **tu récupères 300 PV** après son succès. |
| Légendaire | Même effet décrit ci-dessus, puis **tu récupères 500 PV** après son succès. |
| Mythique | Même effet décrit ci-dessus, puis **tu récupères 800 PV** après son succès. |

### 689 — Reverse Trap
**Effet d’origine :** Se déclenche après un renforcement par équipement adverse et transforme le bonus concerné en diminution équivalente d’ATK et de DEF.

**Conditions et limites :** Exemple : un équipement +500 devient une pénalité de −500 par rapport aux statistiques avant cet équipement : le jeu retire donc 1000 au total après l’ajout initial. Ne transforme pas tous les futurs bonus pour le reste du duel.

| Rareté | Effet total selon la rareté |
|---|---|
| Normale | Se déclenche après un renforcement par équipement adverse et transforme le bonus concerné en diminution équivalente d’ATK et de DEF. |
| Rare | Même effet décrit ci-dessus, puis **tu récupères 100 PV** après son succès. |
| Épique | Même effet décrit ci-dessus, puis **tu récupères 300 PV** après son succès. |
| Légendaire | Même effet décrit ci-dessus, puis **tu récupères 500 PV** après son succès. |
| Mythique | Même effet décrit ci-dessus, puis **tu récupères 800 PV** après son succès. |

### 690 — Fake Trap
**Effet d’origine :** Dans Forbidden Memories, ce piège sert de leurre lorsqu’une attaque adverse le déclenche ; il ne détruit pas le monstre attaquant comme un piège de destruction.

**Conditions et limites :** Son comportement natif est conservé. Le supplément proposé est un soin après son déclenchement, sans lui ajouter un pouvoir de destruction.

| Rareté | Effet total selon la rareté |
|---|---|
| Normale | Dans Forbidden Memories, ce piège sert de leurre lorsqu’une attaque adverse le déclenche ; il ne détruit pas le monstre attaquant comme un piège de destruction. |
| Rare | Même effet décrit ci-dessus, puis **tu récupères 100 PV** après son succès. |
| Épique | Même effet décrit ci-dessus, puis **tu récupères 300 PV** après son succès. |
| Légendaire | Même effet décrit ci-dessus, puis **tu récupères 500 PV** après son succès. |
| Mythique | Même effet décrit ci-dessus, puis **tu récupères 800 PV** après son succès. |

## Rituels — 24 cartes

### 665 — Curse of Millennium Shield
**Effet d’origine :** Permet d’invoquer **Millennium Shield (n° 362)** en sacrifiant les trois monstres requis déjà présents sur ton terrain : **Prevent Rat (n° 255)**, **One-eyed Shield Dragon (n° 296)**, **Armored Rat (n° 629)**. Ces trois monstres sont consommés et le monstre invoqué les remplace. Sans la recette complète, l’invocation ne réussit pas.

**Conditions et limites :** La recette ne devient pas plus facile avec la rareté. Trois occurrences du même nom exigent trois copies distinctes. Le bonus proposé ne crée aucune carte dans ta collection et ne donne aucune variante de rareté : celles-ci restent obtenues uniquement par drop. Si le monstre a déjà un bonus de rareté, retenir le plus élevé entre les deux, sans additionner ces deux bonus.

| Rareté | Effet total selon la rareté |
|---|---|
| Normale | Invoque **Millennium Shield**, avec ses statistiques normales. |
| Rare | Invoque **Millennium Shield**, avec **+100 ATK et +100 DEF** pendant ce duel. |
| Épique | Invoque **Millennium Shield**, avec **+300 ATK et +300 DEF** pendant ce duel. |
| Légendaire | Invoque **Millennium Shield**, avec **+500 ATK et +500 DEF** pendant ce duel. |
| Mythique | Invoque **Millennium Shield**, avec **+800 ATK et +800 DEF** pendant ce duel. |

### 666 — Yamadron Ritual
**Effet d’origine :** Permet d’invoquer **Yamadron (n° 357)** en sacrifiant les trois monstres requis déjà présents sur ton terrain : **Mountain Warrior (n° 29)**, **Koumori Dragon (n° 31)**, **Wings of Wicked Flame (n° 101)**. Ces trois monstres sont consommés et le monstre invoqué les remplace. Sans la recette complète, l’invocation ne réussit pas.

**Conditions et limites :** La recette ne devient pas plus facile avec la rareté. Trois occurrences du même nom exigent trois copies distinctes. Le bonus proposé ne crée aucune carte dans ta collection et ne donne aucune variante de rareté : celles-ci restent obtenues uniquement par drop. Si le monstre a déjà un bonus de rareté, retenir le plus élevé entre les deux, sans additionner ces deux bonus.

| Rareté | Effet total selon la rareté |
|---|---|
| Normale | Invoque **Yamadron**, avec ses statistiques normales. |
| Rare | Invoque **Yamadron**, avec **+100 ATK et +100 DEF** pendant ce duel. |
| Épique | Invoque **Yamadron**, avec **+300 ATK et +300 DEF** pendant ce duel. |
| Légendaire | Invoque **Yamadron**, avec **+500 ATK et +500 DEF** pendant ce duel. |
| Mythique | Invoque **Yamadron**, avec **+800 ATK et +800 DEF** pendant ce duel. |

### 667 — Gate Guardian Ritual
**Effet d’origine :** Permet d’invoquer **Gate Guardian (n° 374)** en sacrifiant les trois monstres requis déjà présents sur ton terrain : **Sanga of the Thunder (n° 371)**, **Kazejin (n° 372)**, **Suijin (n° 373)**. Ces trois monstres sont consommés et le monstre invoqué les remplace. Sans la recette complète, l’invocation ne réussit pas.

**Conditions et limites :** La recette ne devient pas plus facile avec la rareté. Trois occurrences du même nom exigent trois copies distinctes. Le bonus proposé ne crée aucune carte dans ta collection et ne donne aucune variante de rareté : celles-ci restent obtenues uniquement par drop. Si le monstre a déjà un bonus de rareté, retenir le plus élevé entre les deux, sans additionner ces deux bonus.

| Rareté | Effet total selon la rareté |
|---|---|
| Normale | Invoque **Gate Guardian**, avec ses statistiques normales. |
| Rare | Invoque **Gate Guardian**, avec **+100 ATK et +100 DEF** pendant ce duel. |
| Épique | Invoque **Gate Guardian**, avec **+300 ATK et +300 DEF** pendant ce duel. |
| Légendaire | Invoque **Gate Guardian**, avec **+500 ATK et +500 DEF** pendant ce duel. |
| Mythique | Invoque **Gate Guardian**, avec **+800 ATK et +800 DEF** pendant ce duel. |

### 670 — Black Luster Ritual
**Effet d’origine :** Permet d’invoquer **Black Luster Soldier (n° 364)** en sacrifiant les trois monstres requis déjà présents sur ton terrain : **Beaver Warrior (n° 27)**, **Gaia the Fierce Knight (n° 38)**, **Kuriboh (n° 58)**. Ces trois monstres sont consommés et le monstre invoqué les remplace. Sans la recette complète, l’invocation ne réussit pas.

**Conditions et limites :** La recette ne devient pas plus facile avec la rareté. Trois occurrences du même nom exigent trois copies distinctes. Le bonus proposé ne crée aucune carte dans ta collection et ne donne aucune variante de rareté : celles-ci restent obtenues uniquement par drop. Si le monstre a déjà un bonus de rareté, retenir le plus élevé entre les deux, sans additionner ces deux bonus.

| Rareté | Effet total selon la rareté |
|---|---|
| Normale | Invoque **Black Luster Soldier**, avec ses statistiques normales. |
| Rare | Invoque **Black Luster Soldier**, avec **+100 ATK et +100 DEF** pendant ce duel. |
| Épique | Invoque **Black Luster Soldier**, avec **+300 ATK et +300 DEF** pendant ce duel. |
| Légendaire | Invoque **Black Luster Soldier**, avec **+500 ATK et +500 DEF** pendant ce duel. |
| Mythique | Invoque **Black Luster Soldier**, avec **+800 ATK et +800 DEF** pendant ce duel. |

### 671 — Zera Ritual
**Effet d’origine :** Permet d’invoquer **Zera The Mant (n° 360)** en sacrifiant les trois monstres requis déjà présents sur ton terrain : **King of Yamimakai (n° 85)**, **Wicked Dragon with the Ersatz Head (n° 298)**, **Ryu-kishin Powered (n° 377)**. Ces trois monstres sont consommés et le monstre invoqué les remplace. Sans la recette complète, l’invocation ne réussit pas.

**Conditions et limites :** La recette ne devient pas plus facile avec la rareté. Trois occurrences du même nom exigent trois copies distinctes. Le bonus proposé ne crée aucune carte dans ta collection et ne donne aucune variante de rareté : celles-ci restent obtenues uniquement par drop. Si le monstre a déjà un bonus de rareté, retenir le plus élevé entre les deux, sans additionner ces deux bonus.

| Rareté | Effet total selon la rareté |
|---|---|
| Normale | Invoque **Zera The Mant**, avec ses statistiques normales. |
| Rare | Invoque **Zera The Mant**, avec **+100 ATK et +100 DEF** pendant ce duel. |
| Épique | Invoque **Zera The Mant**, avec **+300 ATK et +300 DEF** pendant ce duel. |
| Légendaire | Invoque **Zera The Mant**, avec **+500 ATK et +500 DEF** pendant ce duel. |
| Mythique | Invoque **Zera The Mant**, avec **+800 ATK et +800 DEF** pendant ce duel. |

### 673 — War-lion Ritual
**Effet d’origine :** Permet d’invoquer **Super War-lion (n° 356)** en sacrifiant les trois monstres requis déjà présents sur ton terrain : **Frenzied Panda (n° 201)**, **Leogun (n° 403)**, **Garvas (n° 483)**. Ces trois monstres sont consommés et le monstre invoqué les remplace. Sans la recette complète, l’invocation ne réussit pas.

**Conditions et limites :** La recette ne devient pas plus facile avec la rareté. Trois occurrences du même nom exigent trois copies distinctes. Le bonus proposé ne crée aucune carte dans ta collection et ne donne aucune variante de rareté : celles-ci restent obtenues uniquement par drop. Si le monstre a déjà un bonus de rareté, retenir le plus élevé entre les deux, sans additionner ces deux bonus.

| Rareté | Effet total selon la rareté |
|---|---|
| Normale | Invoque **Super War-lion**, avec ses statistiques normales. |
| Rare | Invoque **Super War-lion**, avec **+100 ATK et +100 DEF** pendant ce duel. |
| Épique | Invoque **Super War-lion**, avec **+300 ATK et +300 DEF** pendant ce duel. |
| Légendaire | Invoque **Super War-lion**, avec **+500 ATK et +500 DEF** pendant ce duel. |
| Mythique | Invoque **Super War-lion**, avec **+800 ATK et +800 DEF** pendant ce duel. |

### 674 — Beastry Mirror Ritual
**Effet d’origine :** Permet d’invoquer **Fiend's Mirror (n° 365)** en sacrifiant les trois monstres requis déjà présents sur ton terrain : **Fiend Refrection #2 (n° 186)**, **Wicked Mirror (n° 261)**, **Fiend Refrection #1 (n° 595)**. Ces trois monstres sont consommés et le monstre invoqué les remplace. Sans la recette complète, l’invocation ne réussit pas.

**Conditions et limites :** La recette ne devient pas plus facile avec la rareté. Trois occurrences du même nom exigent trois copies distinctes. Le bonus proposé ne crée aucune carte dans ta collection et ne donne aucune variante de rareté : celles-ci restent obtenues uniquement par drop. Si le monstre a déjà un bonus de rareté, retenir le plus élevé entre les deux, sans additionner ces deux bonus.

| Rareté | Effet total selon la rareté |
|---|---|
| Normale | Invoque **Fiend's Mirror**, avec ses statistiques normales. |
| Rare | Invoque **Fiend's Mirror**, avec **+100 ATK et +100 DEF** pendant ce duel. |
| Épique | Invoque **Fiend's Mirror**, avec **+300 ATK et +300 DEF** pendant ce duel. |
| Légendaire | Invoque **Fiend's Mirror**, avec **+500 ATK et +500 DEF** pendant ce duel. |
| Mythique | Invoque **Fiend's Mirror**, avec **+800 ATK et +800 DEF** pendant ce duel. |

### 675 — Ultimate Dragon
**Effet d’origine :** Permet d’invoquer **Blue-eyes Ultimate Dragon (n° 380)** en sacrifiant les trois monstres requis déjà présents sur ton terrain : **Blue-eyes White Dragon (n° 1)**, **Blue-eyes White Dragon (n° 1)**, **Blue-eyes White Dragon (n° 1)**. Ces trois monstres sont consommés et le monstre invoqué les remplace. Sans la recette complète, l’invocation ne réussit pas.

**Conditions et limites :** La recette ne devient pas plus facile avec la rareté. Trois occurrences du même nom exigent trois copies distinctes. Le bonus proposé ne crée aucune carte dans ta collection et ne donne aucune variante de rareté : celles-ci restent obtenues uniquement par drop. Si le monstre a déjà un bonus de rareté, retenir le plus élevé entre les deux, sans additionner ces deux bonus.

| Rareté | Effet total selon la rareté |
|---|---|
| Normale | Invoque **Blue-eyes Ultimate Dragon**, avec ses statistiques normales. |
| Rare | Invoque **Blue-eyes Ultimate Dragon**, avec **+100 ATK et +100 DEF** pendant ce duel. |
| Épique | Invoque **Blue-eyes Ultimate Dragon**, avec **+300 ATK et +300 DEF** pendant ce duel. |
| Légendaire | Invoque **Blue-eyes Ultimate Dragon**, avec **+500 ATK et +500 DEF** pendant ce duel. |
| Mythique | Invoque **Blue-eyes Ultimate Dragon**, avec **+800 ATK et +800 DEF** pendant ce duel. |

### 676 — Commencement Dance
**Effet d’origine :** Permet d’invoquer **Performance of Sword (n° 701)** en sacrifiant les trois monstres requis déjà présents sur ton terrain : **Water Omotics (n° 249)**, **Dancing Elf (n° 395)**, **Bean Soldier (n° 511)**. Ces trois monstres sont consommés et le monstre invoqué les remplace. Sans la recette complète, l’invocation ne réussit pas.

**Conditions et limites :** La recette ne devient pas plus facile avec la rareté. Trois occurrences du même nom exigent trois copies distinctes. Le bonus proposé ne crée aucune carte dans ta collection et ne donne aucune variante de rareté : celles-ci restent obtenues uniquement par drop. Si le monstre a déjà un bonus de rareté, retenir le plus élevé entre les deux, sans additionner ces deux bonus.

| Rareté | Effet total selon la rareté |
|---|---|
| Normale | Invoque **Performance of Sword**, avec ses statistiques normales. |
| Rare | Invoque **Performance of Sword**, avec **+100 ATK et +100 DEF** pendant ce duel. |
| Épique | Invoque **Performance of Sword**, avec **+300 ATK et +300 DEF** pendant ce duel. |
| Légendaire | Invoque **Performance of Sword**, avec **+500 ATK et +500 DEF** pendant ce duel. |
| Mythique | Invoque **Performance of Sword**, avec **+800 ATK et +800 DEF** pendant ce duel. |

### 677 — Hamburger Recipe
**Effet d’origine :** Permet d’invoquer **Hungry Burger (n° 702)** en sacrifiant les trois monstres requis déjà présents sur ton terrain : **Battle Steer (n° 14)**, **Bio Plant (n° 295)**, **Griggle (n° 547)**. Ces trois monstres sont consommés et le monstre invoqué les remplace. Sans la recette complète, l’invocation ne réussit pas.

**Conditions et limites :** La recette ne devient pas plus facile avec la rareté. Trois occurrences du même nom exigent trois copies distinctes. Le bonus proposé ne crée aucune carte dans ta collection et ne donne aucune variante de rareté : celles-ci restent obtenues uniquement par drop. Si le monstre a déjà un bonus de rareté, retenir le plus élevé entre les deux, sans additionner ces deux bonus.

| Rareté | Effet total selon la rareté |
|---|---|
| Normale | Invoque **Hungry Burger**, avec ses statistiques normales. |
| Rare | Invoque **Hungry Burger**, avec **+100 ATK et +100 DEF** pendant ce duel. |
| Épique | Invoque **Hungry Burger**, avec **+300 ATK et +300 DEF** pendant ce duel. |
| Légendaire | Invoque **Hungry Burger**, avec **+500 ATK et +500 DEF** pendant ce duel. |
| Mythique | Invoque **Hungry Burger**, avec **+800 ATK et +800 DEF** pendant ce duel. |

### 678 — Revival of Sennen Genjin
**Effet d’origine :** Permet d’invoquer **Sengenjin (n° 703)** en sacrifiant les trois monstres requis déjà présents sur ton terrain : **Hitotsu-me Giant (n° 3)**, **Tiger Axe (n° 64)**, **Millennium Golem (n° 453)**. Ces trois monstres sont consommés et le monstre invoqué les remplace. Sans la recette complète, l’invocation ne réussit pas.

**Conditions et limites :** La recette ne devient pas plus facile avec la rareté. Trois occurrences du même nom exigent trois copies distinctes. Le bonus proposé ne crée aucune carte dans ta collection et ne donne aucune variante de rareté : celles-ci restent obtenues uniquement par drop. Si le monstre a déjà un bonus de rareté, retenir le plus élevé entre les deux, sans additionner ces deux bonus.

| Rareté | Effet total selon la rareté |
|---|---|
| Normale | Invoque **Sengenjin**, avec ses statistiques normales. |
| Rare | Invoque **Sengenjin**, avec **+100 ATK et +100 DEF** pendant ce duel. |
| Épique | Invoque **Sengenjin**, avec **+300 ATK et +300 DEF** pendant ce duel. |
| Légendaire | Invoque **Sengenjin**, avec **+500 ATK et +500 DEF** pendant ce duel. |
| Mythique | Invoque **Sengenjin**, avec **+800 ATK et +800 DEF** pendant ce duel. |

### 679 — Novox's Prayer
**Effet d’origine :** Permet d’invoquer **Skull Guardian (n° 704)** en sacrifiant les trois monstres requis déjà présents sur ton terrain : **M-warrior #1 (n° 160)**, **M-warrior #2 (n° 161)**, **Kamakiriman (n° 535)**. Ces trois monstres sont consommés et le monstre invoqué les remplace. Sans la recette complète, l’invocation ne réussit pas.

**Conditions et limites :** La recette ne devient pas plus facile avec la rareté. Trois occurrences du même nom exigent trois copies distinctes. Le bonus proposé ne crée aucune carte dans ta collection et ne donne aucune variante de rareté : celles-ci restent obtenues uniquement par drop. Si le monstre a déjà un bonus de rareté, retenir le plus élevé entre les deux, sans additionner ces deux bonus.

| Rareté | Effet total selon la rareté |
|---|---|
| Normale | Invoque **Skull Guardian**, avec ses statistiques normales. |
| Rare | Invoque **Skull Guardian**, avec **+100 ATK et +100 DEF** pendant ce duel. |
| Épique | Invoque **Skull Guardian**, avec **+300 ATK et +300 DEF** pendant ce duel. |
| Légendaire | Invoque **Skull Guardian**, avec **+500 ATK et +500 DEF** pendant ce duel. |
| Mythique | Invoque **Skull Guardian**, avec **+800 ATK et +800 DEF** pendant ce duel. |

### 680 — Curse of Tri-Horned Dragon
**Effet d’origine :** Permet d’invoquer **Tri-horned Dragon (n° 705)** en sacrifiant les trois monstres requis déjà présents sur ton terrain : **Feral Imp (n° 6)**, **Torike (n° 47)**, **B. Dragon Jungle King (n° 571)**. Ces trois monstres sont consommés et le monstre invoqué les remplace. Sans la recette complète, l’invocation ne réussit pas.

**Conditions et limites :** La recette ne devient pas plus facile avec la rareté. Trois occurrences du même nom exigent trois copies distinctes. Le bonus proposé ne crée aucune carte dans ta collection et ne donne aucune variante de rareté : celles-ci restent obtenues uniquement par drop. Si le monstre a déjà un bonus de rareté, retenir le plus élevé entre les deux, sans additionner ces deux bonus.

| Rareté | Effet total selon la rareté |
|---|---|
| Normale | Invoque **Tri-horned Dragon**, avec ses statistiques normales. |
| Rare | Invoque **Tri-horned Dragon**, avec **+100 ATK et +100 DEF** pendant ce duel. |
| Épique | Invoque **Tri-horned Dragon**, avec **+300 ATK et +300 DEF** pendant ce duel. |
| Légendaire | Invoque **Tri-horned Dragon**, avec **+500 ATK et +500 DEF** pendant ce duel. |
| Mythique | Invoque **Tri-horned Dragon**, avec **+800 ATK et +800 DEF** pendant ce duel. |

### 691 — Revived of Serpent Night Dragon
**Effet d’origine :** Permet d’invoquer **Serpent Night Dragon (n° 706)** en sacrifiant les trois monstres requis déjà présents sur ton terrain : **Darkfire Dragon (n° 168)**, **Dragoness the Wicked Knight (n° 294)**, **Obese Marmot of Nefariousness (n° 604)**. Ces trois monstres sont consommés et le monstre invoqué les remplace. Sans la recette complète, l’invocation ne réussit pas.

**Conditions et limites :** La recette ne devient pas plus facile avec la rareté. Trois occurrences du même nom exigent trois copies distinctes. Le bonus proposé ne crée aucune carte dans ta collection et ne donne aucune variante de rareté : celles-ci restent obtenues uniquement par drop. Si le monstre a déjà un bonus de rareté, retenir le plus élevé entre les deux, sans additionner ces deux bonus.

| Rareté | Effet total selon la rareté |
|---|---|
| Normale | Invoque **Serpent Night Dragon**, avec ses statistiques normales. |
| Rare | Invoque **Serpent Night Dragon**, avec **+100 ATK et +100 DEF** pendant ce duel. |
| Épique | Invoque **Serpent Night Dragon**, avec **+300 ATK et +300 DEF** pendant ce duel. |
| Légendaire | Invoque **Serpent Night Dragon**, avec **+500 ATK et +500 DEF** pendant ce duel. |
| Mythique | Invoque **Serpent Night Dragon**, avec **+800 ATK et +800 DEF** pendant ce duel. |

### 692 — Turtle Oath
**Effet d’origine :** Permet d’invoquer **Crab Turtle (n° 710)** en sacrifiant les trois monstres requis déjà présents sur ton terrain : **Catapult Turtle (n° 89)**, **30,000-Year White Turtle (n° 449)**, **Kanikabuto (n° 451)**. Ces trois monstres sont consommés et le monstre invoqué les remplace. Sans la recette complète, l’invocation ne réussit pas.

**Conditions et limites :** La recette ne devient pas plus facile avec la rareté. Trois occurrences du même nom exigent trois copies distinctes. Le bonus proposé ne crée aucune carte dans ta collection et ne donne aucune variante de rareté : celles-ci restent obtenues uniquement par drop. Si le monstre a déjà un bonus de rareté, retenir le plus élevé entre les deux, sans additionner ces deux bonus.

| Rareté | Effet total selon la rareté |
|---|---|
| Normale | Invoque **Crab Turtle**, avec ses statistiques normales. |
| Rare | Invoque **Crab Turtle**, avec **+100 ATK et +100 DEF** pendant ce duel. |
| Épique | Invoque **Crab Turtle**, avec **+300 ATK et +300 DEF** pendant ce duel. |
| Légendaire | Invoque **Crab Turtle**, avec **+500 ATK et +500 DEF** pendant ce duel. |
| Mythique | Invoque **Crab Turtle**, avec **+800 ATK et +800 DEF** pendant ce duel. |

### 693 — Contruct of Mask
**Effet d’origine :** Permet d’invoquer **Mask of Shine & Dark (n° 720)** en sacrifiant les trois monstres requis déjà présents sur ton terrain : **Mask of Darkness (n° 102)**, **Masked Clown (n° 182)**, **Masked Sorcerer (n° 220)**. Ces trois monstres sont consommés et le monstre invoqué les remplace. Sans la recette complète, l’invocation ne réussit pas.

**Conditions et limites :** La recette ne devient pas plus facile avec la rareté. Trois occurrences du même nom exigent trois copies distinctes. Le bonus proposé ne crée aucune carte dans ta collection et ne donne aucune variante de rareté : celles-ci restent obtenues uniquement par drop. Si le monstre a déjà un bonus de rareté, retenir le plus élevé entre les deux, sans additionner ces deux bonus.

| Rareté | Effet total selon la rareté |
|---|---|
| Normale | Invoque **Mask of Shine & Dark**, avec ses statistiques normales. |
| Rare | Invoque **Mask of Shine & Dark**, avec **+100 ATK et +100 DEF** pendant ce duel. |
| Épique | Invoque **Mask of Shine & Dark**, avec **+300 ATK et +300 DEF** pendant ce duel. |
| Légendaire | Invoque **Mask of Shine & Dark**, avec **+500 ATK et +500 DEF** pendant ce duel. |
| Mythique | Invoque **Mask of Shine & Dark**, avec **+800 ATK et +800 DEF** pendant ce duel. |

### 694 — Resurrection of Chakra
**Effet d’origine :** Permet d’invoquer **Chakra (n° 709)** en sacrifiant les trois monstres requis déjà présents sur ton terrain : **Claw Reacher (n° 178)**, **Versago the Destroyer (n° 269)**, **Dark Artist (n° 288)**. Ces trois monstres sont consommés et le monstre invoqué les remplace. Sans la recette complète, l’invocation ne réussit pas.

**Conditions et limites :** La recette ne devient pas plus facile avec la rareté. Trois occurrences du même nom exigent trois copies distinctes. Le bonus proposé ne crée aucune carte dans ta collection et ne donne aucune variante de rareté : celles-ci restent obtenues uniquement par drop. Si le monstre a déjà un bonus de rareté, retenir le plus élevé entre les deux, sans additionner ces deux bonus.

| Rareté | Effet total selon la rareté |
|---|---|
| Normale | Invoque **Chakra**, avec ses statistiques normales. |
| Rare | Invoque **Chakra**, avec **+100 ATK et +100 DEF** pendant ce duel. |
| Épique | Invoque **Chakra**, avec **+300 ATK et +300 DEF** pendant ce duel. |
| Légendaire | Invoque **Chakra**, avec **+500 ATK et +500 DEF** pendant ce duel. |
| Mythique | Invoque **Chakra**, avec **+800 ATK et +800 DEF** pendant ce duel. |

### 695 — Puppet Ritual
**Effet d’origine :** Permet d’invoquer **Psycho-Puppet (n° 715)** en sacrifiant les trois monstres requis déjà présents sur ton terrain : **Mysterious Puppeteer (n° 166)**, **Saber Slasher (n° 405)**, **Blocker (n° 416)**. Ces trois monstres sont consommés et le monstre invoqué les remplace. Sans la recette complète, l’invocation ne réussit pas.

**Conditions et limites :** La recette ne devient pas plus facile avec la rareté. Trois occurrences du même nom exigent trois copies distinctes. Le bonus proposé ne crée aucune carte dans ta collection et ne donne aucune variante de rareté : celles-ci restent obtenues uniquement par drop. Si le monstre a déjà un bonus de rareté, retenir le plus élevé entre les deux, sans additionner ces deux bonus.

| Rareté | Effet total selon la rareté |
|---|---|
| Normale | Invoque **Psycho-Puppet**, avec ses statistiques normales. |
| Rare | Invoque **Psycho-Puppet**, avec **+100 ATK et +100 DEF** pendant ce duel. |
| Épique | Invoque **Psycho-Puppet**, avec **+300 ATK et +300 DEF** pendant ce duel. |
| Légendaire | Invoque **Psycho-Puppet**, avec **+500 ATK et +500 DEF** pendant ce duel. |
| Mythique | Invoque **Psycho-Puppet**, avec **+800 ATK et +800 DEF** pendant ce duel. |

### 696 — Javelin Beetle Pact
**Effet d’origine :** Permet d’invoquer **Javelin Beetle (n° 717)** en sacrifiant les trois monstres requis déjà présents sur ton terrain : **Hercules Beetle (n° 52)**, **Kuwagata α (n° 480)**, **Kwagar Hercules (n° 533)**. Ces trois monstres sont consommés et le monstre invoqué les remplace. Sans la recette complète, l’invocation ne réussit pas.

**Conditions et limites :** La recette ne devient pas plus facile avec la rareté. Trois occurrences du même nom exigent trois copies distinctes. Le bonus proposé ne crée aucune carte dans ta collection et ne donne aucune variante de rareté : celles-ci restent obtenues uniquement par drop. Si le monstre a déjà un bonus de rareté, retenir le plus élevé entre les deux, sans additionner ces deux bonus.

| Rareté | Effet total selon la rareté |
|---|---|
| Normale | Invoque **Javelin Beetle**, avec ses statistiques normales. |
| Rare | Invoque **Javelin Beetle**, avec **+100 ATK et +100 DEF** pendant ce duel. |
| Épique | Invoque **Javelin Beetle**, avec **+300 ATK et +300 DEF** pendant ce duel. |
| Légendaire | Invoque **Javelin Beetle**, avec **+500 ATK et +500 DEF** pendant ce duel. |
| Mythique | Invoque **Javelin Beetle**, avec **+800 ATK et +800 DEF** pendant ce duel. |

### 697 — Garma Sword Oath
**Effet d’origine :** Permet d’invoquer **Garma Sword (n° 716)** en sacrifiant les trois monstres requis déjà présents sur ton terrain : **Vishwar Randi (n° 239)**, **Swordstalker (n° 378)**, **Succubus Knight (n° 621)**. Ces trois monstres sont consommés et le monstre invoqué les remplace. Sans la recette complète, l’invocation ne réussit pas.

**Conditions et limites :** La recette ne devient pas plus facile avec la rareté. Trois occurrences du même nom exigent trois copies distinctes. Le bonus proposé ne crée aucune carte dans ta collection et ne donne aucune variante de rareté : celles-ci restent obtenues uniquement par drop. Si le monstre a déjà un bonus de rareté, retenir le plus élevé entre les deux, sans additionner ces deux bonus.

| Rareté | Effet total selon la rareté |
|---|---|
| Normale | Invoque **Garma Sword**, avec ses statistiques normales. |
| Rare | Invoque **Garma Sword**, avec **+100 ATK et +100 DEF** pendant ce duel. |
| Épique | Invoque **Garma Sword**, avec **+300 ATK et +300 DEF** pendant ce duel. |
| Légendaire | Invoque **Garma Sword**, avec **+500 ATK et +500 DEF** pendant ce duel. |
| Mythique | Invoque **Garma Sword**, avec **+800 ATK et +800 DEF** pendant ce duel. |

### 698 — Cosmo Queen's Prayer
**Effet d’origine :** Permet d’invoquer **Cosmo Queen (n° 708)** en sacrifiant les trois monstres requis déjà présents sur ton terrain : **Princess of Tsurugi (n° 266)**, **Queen's Double (n° 635)**, **Queen of Autumn Leaves (n° 638)**. Ces trois monstres sont consommés et le monstre invoqué les remplace. Sans la recette complète, l’invocation ne réussit pas.

**Conditions et limites :** La recette ne devient pas plus facile avec la rareté. Trois occurrences du même nom exigent trois copies distinctes. Le bonus proposé ne crée aucune carte dans ta collection et ne donne aucune variante de rareté : celles-ci restent obtenues uniquement par drop. Si le monstre a déjà un bonus de rareté, retenir le plus élevé entre les deux, sans additionner ces deux bonus.

| Rareté | Effet total selon la rareté |
|---|---|
| Normale | Invoque **Cosmo Queen**, avec ses statistiques normales. |
| Rare | Invoque **Cosmo Queen**, avec **+100 ATK et +100 DEF** pendant ce duel. |
| Épique | Invoque **Cosmo Queen**, avec **+300 ATK et +300 DEF** pendant ce duel. |
| Légendaire | Invoque **Cosmo Queen**, avec **+500 ATK et +500 DEF** pendant ce duel. |
| Mythique | Invoque **Cosmo Queen**, avec **+800 ATK et +800 DEF** pendant ce duel. |

### 699 — Revival of Skeleton Rider
**Effet d’origine :** Permet d’invoquer **Dokurorider (n° 719)** en sacrifiant les trois monstres requis déjà présents sur ton terrain : **Temple of Skulls (n° 146)**, **Cockroach Knight (n° 479)**, **Korogashi (n° 485)**. Ces trois monstres sont consommés et le monstre invoqué les remplace. Sans la recette complète, l’invocation ne réussit pas.

**Conditions et limites :** La recette ne devient pas plus facile avec la rareté. Trois occurrences du même nom exigent trois copies distinctes. Le bonus proposé ne crée aucune carte dans ta collection et ne donne aucune variante de rareté : celles-ci restent obtenues uniquement par drop. Si le monstre a déjà un bonus de rareté, retenir le plus élevé entre les deux, sans additionner ces deux bonus.

| Rareté | Effet total selon la rareté |
|---|---|
| Normale | Invoque **Dokurorider**, avec ses statistiques normales. |
| Rare | Invoque **Dokurorider**, avec **+100 ATK et +100 DEF** pendant ce duel. |
| Épique | Invoque **Dokurorider**, avec **+300 ATK et +300 DEF** pendant ce duel. |
| Légendaire | Invoque **Dokurorider**, avec **+500 ATK et +500 DEF** pendant ce duel. |
| Mythique | Invoque **Dokurorider**, avec **+800 ATK et +800 DEF** pendant ce duel. |

### 700 — Fortress Whale's Oath
**Effet d’origine :** Permet d’invoquer **Fortress Whale (n° 718)** en sacrifiant les trois monstres requis déjà présents sur ton terrain : **White Dolphin (n° 436)**, **Mech Bass (n° 441)**, **Misairuzame (n° 542)**. Ces trois monstres sont consommés et le monstre invoqué les remplace. Sans la recette complète, l’invocation ne réussit pas.

**Conditions et limites :** La recette ne devient pas plus facile avec la rareté. Trois occurrences du même nom exigent trois copies distinctes. Le bonus proposé ne crée aucune carte dans ta collection et ne donne aucune variante de rareté : celles-ci restent obtenues uniquement par drop. Si le monstre a déjà un bonus de rareté, retenir le plus élevé entre les deux, sans additionner ces deux bonus.

| Rareté | Effet total selon la rareté |
|---|---|
| Normale | Invoque **Fortress Whale**, avec ses statistiques normales. |
| Rare | Invoque **Fortress Whale**, avec **+100 ATK et +100 DEF** pendant ce duel. |
| Épique | Invoque **Fortress Whale**, avec **+300 ATK et +300 DEF** pendant ce duel. |
| Légendaire | Invoque **Fortress Whale**, avec **+500 ATK et +500 DEF** pendant ce duel. |
| Mythique | Invoque **Fortress Whale**, avec **+800 ATK et +800 DEF** pendant ce duel. |

### 721 — Dark Magic Ritual
**Effet d’origine :** Permet d’invoquer **Magician of Black Chaos (n° 722)** en sacrifiant les trois monstres requis déjà présents sur ton terrain : **Winged Dragon #1 (n° 7)**, **Dark Magician (n° 35)**, **Blast Juggler (n° 417)**. Ces trois monstres sont consommés et le monstre invoqué les remplace. Sans la recette complète, l’invocation ne réussit pas.

**Conditions et limites :** La recette ne devient pas plus facile avec la rareté. Trois occurrences du même nom exigent trois copies distinctes. Le bonus proposé ne crée aucune carte dans ta collection et ne donne aucune variante de rareté : celles-ci restent obtenues uniquement par drop. Si le monstre a déjà un bonus de rareté, retenir le plus élevé entre les deux, sans additionner ces deux bonus.

| Rareté | Effet total selon la rareté |
|---|---|
| Normale | Invoque **Magician of Black Chaos**, avec ses statistiques normales. |
| Rare | Invoque **Magician of Black Chaos**, avec **+100 ATK et +100 DEF** pendant ce duel. |
| Épique | Invoque **Magician of Black Chaos**, avec **+300 ATK et +300 DEF** pendant ce duel. |
| Légendaire | Invoque **Magician of Black Chaos**, avec **+500 ATK et +500 DEF** pendant ce duel. |
| Mythique | Invoque **Magician of Black Chaos**, avec **+800 ATK et +800 DEF** pendant ce duel. |

## Exemples pour comprendre les valeurs

- Un monstre à 2000 ATK / 1500 DEF équipé de Dragon Treasure Rare, s’il est compatible, passe à **2600 ATK / 2100 DEF** : +600 à chacune des valeurs.
- Red Medicine Mythique utilisée à 7000 PV avec un plafond à 8000 donne **8000 PV**, pas 8300.
- Acid Trap Hole Mythique détruit un attaquant à **3800 ATK**, mais pas à 3810.
- Crush Card Mythique détruit les monstres adverses à **700 ATK ou plus** ; un monstre à 600 ATK reste en place.
- Ultimate Dragon demande **trois Blue-eyes White Dragon** sur ton terrain. Sa variante Mythique invoquerait Blue-eyes Ultimate Dragon avec +800 ATK et +800 DEF pour ce duel, sans ajouter une carte mythique à ta collection.

## Sources et état d’application

Recettes et compatibilités : données WA_MRG.MRG du disque USA fourni. Autres effets : code de la version utilisée, notamment duel_card_effects.c, duel_field_effect_steps.c, duel_monster_removal_rules.c, duel_terrain_boost.c, duel_trap_resolution.c et duel_check_ritual.c. Les règles supplémentaires de Lekak peuvent modifier les compatibilités du disque.

Les colonnes Rare à Mythique décrivent les effets implémentés dans la **v0.7**. Ce guide accompagne le module ; le rendu et les interactions restent à confirmer en duel dans ton jeu.
