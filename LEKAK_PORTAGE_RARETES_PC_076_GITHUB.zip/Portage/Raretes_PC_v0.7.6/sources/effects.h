#ifndef LEKAK_EFFECTS_H
#define LEKAK_EFFECTS_H
#include "pc/mods/modapi.h"
#include "game/duel_card.h"
int Rarity_EffectsInit(const MemoriesModHost *host);
void Rarity_EffectsFrame(void);
void Rarity_RitualRecord(DuelCardRecord *card);
int Rarity_RitualPreview(int card_id);
int Rarity_ApplyDamage(int side,int life,int amount,int kind);
int Rarity_HealingAmount(void);
int Rarity_DamageAmount(void);
int Rarity_PenaltyAmount(void);
void Rarity_ValueLifePointRecovery(void);
void Rarity_ValueDirectDamage(void);
void Rarity_ValueStatPenalty(void);
#endif
