#include "types.h"
#include "psyq/qsort.h"
#include "game/card_list_text_boxes.h"
#include "game/card_list_sort.h"
#include "game/rand_get_interval.h"
#include "game/card_constants.h"
#include "game/duel_card.h"
#include "game/build_deck_transition_state.h"


int Rarity_RawStat(int id,int defense);
void Rarity_Sort(CardList *list)
{
    CardListSortItem *row;
    s32 i;
    s32 n;

    n = list->sort_row_count;
    row = (CardListSortItem *)list;
    switch (list->sort_mode) {
    case 1:
        if (list->kind != 0) {
            for (i = 0; i < n; i++, row++) {
                row->key = 0xFFFF;
                if (row->field_0D != 0) {
                    row->key = row->card_id;
                }
            }
        } else {
            for (i = 0; i < n; row++, i++) {
                row->key = row->card_id;
            }
        }
        qsort(list, n, sizeof(CardListSortItem), func_80032BD4);
        break;
    case 2:
        for (i = 0; i < n; row++, i++) {
            row->key = -1;
            if (row->field_0D != 0) {
                row->key = 0;
            }
        }
        qsort(list, n, sizeof(CardListSortItem), func_80032BD4);
        break;
    case 3:
        for (i = 0; i < n; row++, i++) {
            row->key = 0;
            if (row->field_0D != 0) {
                if ((Rarity_RawStat(row->card_id,0)) >=
                    (Rarity_RawStat(row->card_id,1))) {
                    row->key =
                        (((Rarity_RawStat(row->card_id,0) / 2))
                         << 17) |
                        (((Rarity_RawStat(row->card_id,1) / 2))
                         << 3) |
                        1;
                } else {
                    row->key =
                        (((Rarity_RawStat(row->card_id,1) / 2))
                         << 17) |
                        (((Rarity_RawStat(row->card_id,0) / 2))
                         << 3) |
                        1;
                }
            }
        }
        qsort(list, n, sizeof(CardListSortItem), BuildDeck_CompareCard);
        break;
    case 4:
        for (i = 0; i < n; row++, i++) {
            row->key = 0;
            if (row->field_0D != 0) {
                row->key =
                    (((Rarity_RawStat(row->card_id,0) / 2))
                     << 17) |
                    (((Rarity_RawStat(row->card_id,1) / 2))
                     << 3) |
                    1;
            }
        }
        qsort(list, n, sizeof(CardListSortItem), BuildDeck_CompareCard);
        break;
    case 5:
        for (i = 0; i < n; row++, i++) {
            row->key = 0;
            if (row->field_0D != 0) {
                row->key =
                    (((Rarity_RawStat(row->card_id,1) / 2))
                     << 17) |
                    (((Rarity_RawStat(row->card_id,0) / 2))
                     << 3) |
                    1;
            }
        }
        qsort(list, n, sizeof(CardListSortItem), BuildDeck_CompareCard);
        break;
    case 6:
        for (i = 0; i < n; row++, i++) {
            row->key = -1;
            if (row->field_0D != 0) {
                row->key = (gDuel_adwCardStats[row->card_id - 1] >>
                            CARD_STAT_TYPE_SHIFT) & CARD_STAT_TYPE_MASK;
            }
        }
        qsort(list, n, sizeof(CardListSortItem), func_80032BD4);
        break;
    case 8:
        for (i = 0; i < n; row++, i++) {
            row->key = -1;
            if (row->field_0D != 0) {
                row->key = 0x100;
                if (gBuildDeck_pState->card_sort_rank[row->card_id] != 0) {
                    row->key = gBuildDeck_pState->card_sort_rank[row->card_id];
                }
            }
        }
        qsort(list, n, sizeof(CardListSortItem), func_80032BD4);
        break;
    case 9:
        n = list->row_count;
        for (i = 0; i < n; row++, i++) {
            row->key = -1;
            if (row->field_0D != 0) {
                row->key = Rand_GetInterval(0x1000);
            }
        }
        qsort(list, n, sizeof(CardListSortItem), func_80032BD4);
        break;
    }
    func_80031E04(list, 8);
}

/* The two explicit volatile .data input views retain absolute pad loads under
 * the uniform -G8 compiler/assembler profile used by the surrounding card
 * list sort code. */
#define GINPUT_PAD1_HELD_IN_DATA_VOLATILE
#define GINPUT_PAD1_REPEAT_IN_DATA_VOLATILE