import json,re,subprocess,struct
from pathlib import Path
root=Path('/workspace/scratch/26deabafe062');p=root/'output/Lekak_Raretes_Test_v03';m=json.loads((p/'mod.json').read_text());base=json.loads((root/'inspect/mods/Lekak/mod.json').read_text());bases=[{'copy':i} for i in range(1,723)]+[c for c in base['cards'] if 'copy'in c];N=len(bases)
assert len(m['cards'])==4*N==4960
assert 'passwords' not in m and 'drops' not in m and 'decks' not in m
assert len({c['id'] for c in m['cards']})==4*N
for t in range(4):
 for i,b in enumerate(bases):
  c=m['cards'][t*N+i];assert c['copy']==b['copy'];assert c['drops'] is False and c['opponents'] is False and c['password'] is None and 'replace' not in c
  for k,v in b.items():
   if k not in ['id','password','drops','opponents','frame','count','count_setting','notes','art','thumbnail','title','field_art']:assert c[k]==v,(i,k)
  for k in ['art','thumbnail','title','field_art']:
   if k in b:assert (p/c[k]).is_file()
ident=(p/'sources/identities.h').read_text();keys=re.findall(r'"([^"\n]*)"',ident)
expected={f"Lekakmod:{c['id']}:1" for c in bases[722:]}|{f"lekak-rarities-test:{c['id']}:1" for c in m['cards']}
assert set(k for k in keys if k)==expected
# Test the actual generated C cursor and palette functions at native host width;
# cursor calculation is independent of pointer layout (state is unused).
s=(p/'sources/cursor.c').read_text();a=s.index('s32 Rarity_CursorId(');b=s.index('/*',a);cursor=s[a:b]
r=(p/'sources/rarities.c').read_text();a=r.index('static unsigned short recolour(');b=r.index('\nvoid Rarity_Prepare',a);palette=r[a:b]
src='''#include <assert.h>
#include <stdio.h>
typedef int s32; typedef signed char s8; typedef unsigned char u8;
#define CARD_GRID_SECTION_SIDE_LENGTH 10
#define CARD_GRID_SECTION_ROW_CARD_COUNT 200
#define CARD_GRID_SECTION_CARD_COUNT 100
int rarity_count=1240,rarity_tab,gCardGrid_bCursorRow,gCardGrid_bCursorColumn;
int Rarity_Map(int index){return index>0&&index<=1240?index+rarity_tab*1240:0;}
'''+cursor+palette+'''
int main(void){
for(int t=0;t<5;t++){rarity_tab=t;for(int index=1;index<=1400;index++){int p=index-1;gCardGrid_bCursorRow=(p/200)*10+(p%100)/10;gCardGrid_bCursorColumn=((p%200)>=100?10:0)+p%10;assert(Rarity_CursorId(0)==(index<=1240?index+t*1240:0));}}
for(int tier=1;tier<=4;tier++){assert(recolour(0,tier,0)==0);for(int x=0;x<=31;x++){unsigned short neutral=x|(x<<5)|(x<<10);assert(recolour(neutral,tier,0)==neutral);}}
for(int w=1;w<32768;w++){int r=w&31,g=(w>>5)&31,b=(w>>10)&31;int max=r>g?r:g,min=r<g?r:g;if(b>max)max=b;if(b<min)min=b;for(int tier=1;tier<=4;tier++){unsigned q=recolour(w|0x8000,tier,w%256);assert(q&0x8000);if(max-min>2){int rr=q&31,gg=(q>>5)&31,bb=(q>>10)&31;if(tier==1)assert(gg>rr&&rr==bb);if(tier==2)assert(rr>gg&&gg==bb);if(tier==3)assert(gg==bb&&gg>rr);if(tier==4)assert(bb>=rr&&rr>gg);}}}
puts("PASS: 7000 cursor cells, four palette colours, neutral shades and PS1 transparency bits");return 0;}
'''
q=root/'inspect/rarity_tests/native_test.c';q.write_text(src);subprocess.run(['gcc','-O2',str(q),'-o',str(q.with_suffix(''))],check=True);subprocess.run([str(q.with_suffix(''))],check=True)
# Verify all undefined names against exported-address references of supplied PE.
bin=(root/'inspect/memories-pc.exe').read_bytes();pe=struct.unpack_from('<I',bin,60)[0];ns=struct.unpack_from('<H',bin,pe+6)[0];sz=struct.unpack_from('<H',bin,pe+20)[0];ob=pe+24;baseaddr=struct.unpack_from('<I',bin,ob+28)[0];sec=[]
for i in range(ns):
 o=ob+sz+40*i;vsize,va,rsize,raw=struct.unpack_from('<IIII',bin,o+8);sec.append((va,max(vsize,rsize),raw,rsize))
def address(off):
 for va,size,raw,rs in sec:
  if raw<=off<raw+rs:return baseaddr+va+off-raw
names=[l.split()[-1] for l in subprocess.check_output(['nm','-u',str(p/'rarities.o')],text=True).splitlines()];missing=[]
for n in names:
 needle=n.encode()+b'\0';start=0;found=False
 while True:
  off=bin.find(needle,start)
  if off<0:break
  a=address(off)
  if a is not None and struct.pack('<I',a) in bin:found=True;break
  start=off+1
 if not found:missing.append(n)
assert not missing,missing
print('PASS: 4960 definitions, 518 art files, stable identities,',len(names),'executable symbol references')
