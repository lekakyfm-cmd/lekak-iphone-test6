#include "effects.h"
#ifdef MEMORIES_PC
#include "pc/mods/mods.h"
#endif
#define gDuel_bEffectRequestStatus_IN_DATA
#define DUEL_FIELD_GRID_ALIASES
#include "types.h"
#include "game/file_transfer.h"
#include "game/duel_trap_resolution.h"
#include "game/func_80025028.h"
#include "game/duel_card_object_helpers.h"
#include "unmatched.h"
#include "game/duel_side_state.h"
#include "game/card_constants.h"
#include "game/duel_action_lock.h"
#include "game/duel_effect_request.h"
#include "game/duel_monster_removal_rules.h"
#include "game/sound.h"
#include "game/duel_card_layout.h"
#include "game/duel_grid.h"
#include "game/duel_card.h"
#include "game/func_80019BA0.h"
#include "game/duel_card_record_lifecycle.h"
#include "game/duel_apply_card_object_flags.h"
#include "game/duel_effect.h"
#include "game/view_state.h"
#include "game/func_80022D94.h"
#include "unmatched.h"
#include "game/duel_card_effects.h"
#include "game/display_object_helpers.h"

#define DUEL_EFFECT_REQUEST_VIEW(request) \
    ((DuelEffectRequest *)(request))
#define DISPLAY_OBJECT_VIEW(object) ((DisplayObject *)(object))
#define DUEL_FIELD_EFFECT_OBJECT_VIEW(object) \
    ((DuelFieldEffectObject *)(object))

void Rarity_ValueLifePointRecovery(void) {
    s32 s0;
    s32 s1;
    s32 flag;
    u16 v1;
    DuelEffectRequest *obj;

    s0 = gDuel_wEffectCardID;
    s1 = s0 - DUEL_LIFE_POINT_RECOVERY_FIRST_CARD_ID;
    if (DuelEffect_MarkInitialized() == 0) {
        if (Duel_SelectTrapByCardId(DUEL_BAD_REACTION_TO_SIMOCHI_CARD_ID) != 0) {
            s1 = s0 - (DUEL_LIFE_POINT_RECOVERY_FIRST_CARD_ID -
                       DUEL_LIFE_POINT_EFFECT_COUNT);
        }
        obj = DuelEffect_CreateRequest(5);
        obj->field_00 = 0xA0;
        obj->field_02 = 0x78;
        obj->field_1A = s1;
        SD_SEPlayFull(0x14);
        return;
    }
    flag = gDuel_wCardEffectFlags;
    if (!(flag & 0x40)) {
        gDuel_wCardEffectFlags = flag | 0x60;
        if (D_8009B22A == 0) {
            u8 value=Rarity_HealingAmount()/100; u8 *p = &value;
#ifdef MEMORIES_PC
            {
                /* In 32 bits: a mod's "limits" may let LP near 32767,
                   where the 16-bit sum would wrap negative and pass the
                   test below. Healing never takes LP down to the cap. */
                s32 life = D_8009B1C8->life_points.signed_value;
                s32 healed = life + (*p) * DUEL_LIFE_POINT_RECOVERY_SCALE;
                s32 ceiling = D_8009B1C8->max_life_points;
                if (ceiling < life) ceiling = life;
                if (healed > ceiling) healed = ceiling;
                D_8009B1C8->life_points.unsigned_value = (u16)healed;
            }
#else
            v1 = D_8009B1C8->life_points.unsigned_value +
                 (*p) * DUEL_LIFE_POINT_RECOVERY_SCALE;
            D_8009B1C8->life_points.unsigned_value = v1;
            if (D_8009B1C8->max_life_points < (s16) v1) {
                D_8009B1C8->life_points.unsigned_value =
                    (u16) D_8009B1C8->max_life_points;
            }
#endif
            goto block_14;
        }
        D_8009B210 = 0;
        goto block_9;
    }
block_9:
    if (gDuel_wCardEffectFlags & 0x20) {
        if (Duel_UpdateTrapPresentation() == 0) {
            gDuel_wCardEffectFlags &= 0xFFDF;
            obj = DuelEffect_CreateRequest(9);
            obj->field_00 = 0xA0;
            obj->field_02 = 0x78;
            obj->field_1A = s1;
        }
    } else {
        u8 value=Rarity_HealingAmount()/100; u8 *p = &value;
#ifdef MEMORIES_PC
        v1 = Rarity_ApplyDamage((int)(D_8009B1C8 - D_800E9FF0), D_8009B1C8->life_points.unsigned_value,
                            (*p) * DUEL_LIFE_POINT_RECOVERY_SCALE, 1);
#else
        v1 = D_8009B1C8->life_points.unsigned_value -
             (*p) * DUEL_LIFE_POINT_RECOVERY_SCALE;
#endif
        D_8009B1C8->life_points.unsigned_value = v1;
        if ((s16) v1 < 0) {
            D_8009B1C8->life_points.unsigned_value = 0;
        }
block_14:
        gDuel_wCardEffectFlags = 0;
    }
}

/* Applies one of the five direct-damage cards. The selected table value is
   scaled by 10 and taken off the target side's life points, clamped at zero. */
void Rarity_ValueDirectDamage(void) {
    s32 unit;
    s32 flags;
    u16 remaining;
    DuelEffectRequest *obj;
    DuelSideState *p;

    unit = gDuel_wEffectCardID - DUEL_DIRECT_DAMAGE_FIRST_CARD_ID;
    if (DuelEffect_MarkInitialized() == 0) {
        if (Duel_SelectTrapByCardId(DUEL_GOBLIN_FAN_CARD_ID) != 0) {
            unit = DUEL_LIFE_POINT_EFFECT_COUNT;
        }
        obj = DuelEffect_CreateRequest(6);
        obj->field_00 = 0xA0;
        obj->field_02 = 0x78;
        obj->field_1A = unit;
        SD_SEPlayFull(0x1C);
        return;
    }
    flags = gDuel_wCardEffectFlags;
    if (!(flags & 0x40)) {
        gDuel_wCardEffectFlags = flags | 0x60;
        if (D_8009B22A == 0) {
            p = &D_800E9FF0[D_8009B1D5 ^ 1];
            goto apply;
        }
        D_8009B210 = 0;
    }
    if (gDuel_wCardEffectFlags & 0x20) {
        if (Duel_UpdateTrapPresentation() == 0) {
            gDuel_wCardEffectFlags &= 0xFFDF;
            obj = DuelEffect_CreateRequest(7);
            obj->field_00 = 0xA0;
            obj->field_02 = 0x78;
            obj->field_1A = unit;
            SD_SEPlayFull(0x1C);
        }
    } else {
        p = &D_800E9FF0[D_8009B1D5];
apply:
#ifdef MEMORIES_PC
        remaining = Rarity_ApplyDamage((int)(p - D_800E9FF0), p->life_points.unsigned_value,
                                   Rarity_DamageAmount(), 1);
#else
        remaining = p->life_points.unsigned_value -
                    gDuel_abDirectDamageUnits[unit] *
                        DUEL_DIRECT_DAMAGE_SCALE;
#endif
        p->life_points.unsigned_value = remaining;
        if ((s16) remaining < 0) {
            p->life_points.unsigned_value = 0;
        }
        gDuel_wCardEffectFlags = 0;
    }
}

void Rarity_ValueStatPenalty(void) {
    DuelCardRecord *record;
    DuelEffectObject *object;
    DisplayObject *card;
    s32 timer;
    s32 base_slot;

    if (DuelEffect_MarkInitialized() == 0) {
        D_8009B20C[1] = 0;
        D_8009B1D0 = 0;
    }

    if ((gDuel_wCardEffectFlags & 0x40) != 0) {
        if ((gDuel_bEffectRequestStatus & 1) == 0) {
            gDuel_wCardEffectFlags = 0;
        }
        return;
    }

    timer = *(u16 *)&D_8009B20C[1] - 1;
    D_8009B20C[1] = timer;
    if ((s16)timer > 0) {
        return;
    }
    D_8009B20C[1] = 0x10;

    base_slot = D_8009B1D5 * DUEL_FIELD_SIDE_GRID_SLOT_COUNT +
                DUEL_FIELD_ROW_SIZE;
    record = &D_801A7AD8[D_800907D8[(s16)D_8009B1D0 + base_slot]];
    if ((record->flags & DUEL_CARD_FLAG_OCCUPIED) != 0) {
        card = DISPLAY_OBJECT_VIEW(record->object);
        object = (DuelEffectObject *)DuelEffect_AllocateRequest(0xD);
        object->x = card->field_30.h.field_30;
        object->y = card->field_30.h.field_32;
        object->field_04 = *(u16 *)&card->field_34;
        object->field_14 = object->field_14 + ((s16)D_8009B1D0 << 14);
        if (gDuel_wEffectCardID == DUEL_SPELLBINDING_CIRCLE_CARD_ID) {
            object->field_1A = 2;
            record->stat_modifier =
                record->stat_modifier - Rarity_PenaltyAmount();
            object->field_12 = -Rarity_PenaltyAmount();
        } else {
            object->field_1A = 1;
            record->stat_modifier =
                record->stat_modifier - Rarity_PenaltyAmount();
            object->field_12 = -Rarity_PenaltyAmount();
        }
        SD_SEPlayFull(0x21);
    }

    D_8009B1D0 = D_8009B1D0 + 1;
    if ((s16)D_8009B1D0 >= DUEL_FIELD_ROW_SIZE) {
        gDuel_wCardEffectFlags = gDuel_wCardEffectFlags | 0x40;
    }
}
