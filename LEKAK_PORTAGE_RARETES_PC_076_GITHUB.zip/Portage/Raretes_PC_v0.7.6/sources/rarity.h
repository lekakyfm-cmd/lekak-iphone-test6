#ifndef LEKAK_RARITY_H
#define LEKAK_RARITY_H
#include "types.h"
#include "game/display_object.h"
#include "psyq/libgte.h"
#include "psyq/libgpu.h"
extern int rarity_count;
extern int rarity_tab;
int Rarity_Map(int index);
int Rarity_Of(int id);
int Rarity_Kind(int id);
int Rarity_Slot(int id);
unsigned Rarity_Color(int id);
unsigned Rarity_Flags(unsigned char *state,int index);
int Rarity_Cx(int index);
int Rarity_Cy(int index);
void Rarity_Prepare(int kind);
int Rarity_Page(int page);
int Rarity_Original(int id);
int Rarity_RawStat(int id,int defense);
void Rarity_Refresh(void);
void Rarity_Grid(void);
s32 Rarity_CursorId(u8 *state);
void Rarity_Update(u8 *state);
void Rarity_Hand(DisplayObject *object,s32 a,s32 b,s32 c);
void Rarity_Field(void *record,POLY_GT4 *prim,POLY_FT4 *sprite,s32 *color);
#endif
