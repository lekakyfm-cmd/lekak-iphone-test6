import json,re,subprocess,struct
from pathlib import Path
root=Path('/workspace/scratch/26deabafe062');p=root/'output/Lekak_Raretes_Test_v06';m=json.loads((p/'mod.json').read_text());base=json.loads((root/'inspect/mods/Lekak/mod.json').read_text());bases=[{'copy':i} for i in range(1,723)]+[c for c in base['cards'] if 'copy'in c];N=len(bases)
assert len(m['cards'])==4*N==4960
assert 'passwords' not in m and 'drops' not in m and 'decks' not in m
assert len({c['id'] for c in m['cards']})==4*N
for t in range(4):
 for i,b in enumerate(bases):
  c=m['cards'][t*N+i];assert c['copy']==b['copy'];assert c['drops'] is False and c['opponents'] is False and c['password'] is None and 'replace' not in c
  for k,v in b.items():
   if k not in ['id','password','drops','opponents','frame','count','count_setting','notes','art','thumbnail','title','field_art']:assert c[k]==v,(i,k)
  for k in ['art','thumbnail','title','field_art']:
   if k in b:assert (p/c[k]).is_file()
ident=(p/'sources/identities.h').read_text();keys=re.findall(r'"([^"\n]*)"',ident)
expected={f"Lekakmod:{c['id']}:1" for c in bases[722:]}|{f"lekak-rarities-test:{c['id']}:1" for c in m['cards']}
assert set(k for k in keys if k)==expected
# Verify all undefined names against exported-address references of supplied PE.
bin=(root/'inspect/memories-pc.exe').read_bytes();pe=struct.unpack_from('<I',bin,60)[0];ns=struct.unpack_from('<H',bin,pe+6)[0];sz=struct.unpack_from('<H',bin,pe+20)[0];ob=pe+24;baseaddr=struct.unpack_from('<I',bin,ob+28)[0];sec=[]
for i in range(ns):
 o=ob+sz+40*i;vsize,va,rsize,raw=struct.unpack_from('<IIII',bin,o+8);sec.append((va,max(vsize,rsize),raw,rsize))
def address(off):
 for va,size,raw,rs in sec:
  if raw<=off<raw+rs:return baseaddr+va+off-raw
names=[l.split()[-1] for l in subprocess.check_output(['nm','-u',str(p/'rarities.o')],text=True).splitlines()];missing=[]
for n in names:
 needle=n.encode()+b'\0';start=0;found=False
 while True:
  off=bin.find(needle,start)
  if off<0:break
  a=address(off)
  if a is not None and struct.pack('<I',a) in bin:found=True;break
  start=off+1
 if not found:missing.append(n)
assert not missing,missing
print('PASS: 4960 definitions, 518 art files, stable identities,',len(names),'rarity module references')
other=root/'output/lekak-collection-test_v16/collection.o'
for line in subprocess.check_output(['nm','-u',str(other)],text=True).splitlines():
 n=line.split()[-1];needle=n.encode()+b'\0';off=bin.find(needle);assert off>=0 and struct.pack('<I',address(off)) in bin,n
print('PASS: collection module references match supplied executable')
