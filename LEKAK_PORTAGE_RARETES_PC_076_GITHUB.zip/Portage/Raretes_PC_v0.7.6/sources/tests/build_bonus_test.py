from pathlib import Path
r=Path('output/Lekak_Raretes_Test_v06/sources/rarities.c').read_text();c=Path('output/lekak-collection-test_v16/sources/collection.c').read_text()
a=r.index('static const int monster_bonus');b=r.index('\nint Rarity_ResaleMultiplier',a);bonus=r[a:b]
# Ai helper is validated by compile/symbol checks; runtime mock targets the
# actual stat table, card initialization, cap handling and resale functions.
a=bonus.index('static void ai(');b=bonus.index('\nint Rarity_Original',a);bonus=bonus[:a]+bonus[b:]
a=r.index('int Rarity_ResaleMultiplier');b=r.index('\nint Rarity_ChooseTier',a);bonus+=r[a:b]
a=c.index('static unsigned buy_price');b=c.index('\nstatic int card_rarity',a);prices=c[a:b]
a=c.index('static unsigned sale_price');b=c.index('\nstatic void rebuild',a);prices+=c[a:b]
prefix='''#include <assert.h>
#include <stdio.h>
#include <string.h>
typedef int s32;typedef unsigned char u8;
#define CARD_TABLE_ID_END 128
#define CARD_TYPE_MAGIC 20
int rarity_count=3,mapped[5][3],tiers[128],base_index_by_id[128],gDuel_adwCardStats[128],terrain;
unsigned short boosted_attack[128],boosted_defense[128];
struct Host {int (*applied)(const struct Host *);void *(*find)(const struct Host *,const char *);};
int active=1;int applied(const struct Host *h){(void)h;return active;}
int Rarity_Original(int);int Rarity_ResaleMultiplier(int);
void *find(const struct Host *h,const char *key){(void)h;if(!strcmp(key,"lekak-rarities-test:resale-base"))return Rarity_Original;assert(!strcmp(key,"lekak-rarities-test:resale-multiplier"));return Rarity_ResaleMultiplier;}
struct Host fakehost={applied,find};struct Host *host=&fakehost;
void resolve(void){}
int Rarity_Of(int id){return id>0&&id<128?tiers[id]:0;}
int Cards_Type(int id){return ((unsigned)gDuel_adwCardStats[id-1]>>26)&31;}
int Tables_StatCap(int d){(void)d;return 9999;}
int Duel_GetTerrainBoost(int type){return type<20?terrain:0;}
int original_stat_mock(int id,int d){int val=(((unsigned)gDuel_adwCardStats[id-1]>>(d?9:0))&511)*10+Duel_GetTerrainBoost(Cards_Type(id));return val<0?0:val>9999?9999:val;}
int (*original_stat)(int,int)=original_stat_mock;
typedef struct {int card_id,attack,defense,stat_modifier,terrain_modifier;} DuelCardRecord;
DuelCardRecord card;
u8 *original_record_mock(int a,int b){(void)a;card.card_id=b;card.attack=(((unsigned)gDuel_adwCardStats[b-1])&511)*10;card.defense=(((unsigned)gDuel_adwCardStats[b-1]>>9)&511)*10;card.stat_modifier=0;card.terrain_modifier=Duel_GetTerrainBoost(Cards_Type(b));return (u8 *)&card;}
u8 *(*original_record)(int,int)=original_record_mock;
'''
main='''
int Duel_GetBaseCardStat(int id,int d){return stat(id,d);}
int main(void){
unsigned original[3]={300u|(250u<<9)|(2u<<18),500u|(500u<<9)|(4u<<18),(20u<<26)};
for(int t=0;t<5;t++)for(int k=0;k<3;k++){int id=t*3+k+1;mapped[t][k]=id;tiers[id]=t;base_index_by_id[id]=k+1;gDuel_adwCardStats[id-1]=original[k];}
apply_boosts();int bonus[5]={0,100,300,500,800};unsigned prices[5]={400,1200,3200,8000,20000};
for(int t=0;t<5;t++)for(int k=0;k<3;k++){
int id=mapped[t][k],base=mapped[0][k],atk=k==0?3000:k==1?5000:0,def=k==0?2500:k==1?5000:0;
int add=k<2?bonus[t]:0;assert(Rarity_RawStat(id,0)==atk+add&&Rarity_RawStat(id,1)==def+add);assert((gDuel_adwCardStats[id-1]&~0x3ffffu)==(original[k]&~0x3ffffu));
assert(stat(id,0)==atk+add&&stat(id,1)==def+add);record(0,id);assert(card.attack==atk+add&&card.defense==def+add);
if(k==0)assert(sale_price(id)==prices[t]);if(t==0)assert((unsigned)gDuel_adwCardStats[id-1]==original[k]);
}
int myth=mapped[4][1];assert(stat(myth,0)==5800);assert((gDuel_adwCardStats[myth-1]&511)==511);terrain=500;assert(stat(myth,0)==6300);record(0,myth);card.stat_modifier=500;assert(card.attack+card.terrain_modifier+card.stat_modifier==6800);
terrain=-6000;assert(stat(myth,0)==0);terrain=0;apply_boosts();assert(stat(myth,0)==5800&&sale_price(mapped[4][0])==20000);
assert(boost_stat(9950,4,9999)==9999);assert(boost_stat(0,1,9999)==100);
puts("PASS: +100/+300/+500/+800 ATK and DEF; normal/spell stats unchanged; 5800 and modifiers correct; no double boost after reset; resale stays 400/1200/3200/8000/20000");return 0;}
'''
# Forward declaration before actual collection price helper.
Path('inspect/rarity_tests/bonus_test.c').write_text(prefix+bonus+'\nint Duel_GetBaseCardStat(int,int);\n'+prices+main)
