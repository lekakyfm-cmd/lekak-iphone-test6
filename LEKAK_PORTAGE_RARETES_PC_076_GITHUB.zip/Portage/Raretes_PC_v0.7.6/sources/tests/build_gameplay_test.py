from pathlib import Path
root=Path('/workspace/scratch/26deabafe062');r=(root/'output/Lekak_Raretes_Test_v04/sources/rarities.c').read_text();c=(root/'output/lekak-collection-test_v15/collection.c').read_text()
def cut(s,start,end):return s[s.index(start):s.index(end,s.index(start))]
palette=cut(r,'static const unsigned colours','\nint Rarity_CountSeen')
# Includes Kind/Slot/Color, native palette construction, exact tier selection,
# drop wrapper and award callback. Replace no algorithmic code.
count=cut(r,'int Rarity_CountSeen','\nvoid Rarity_Refresh')
rarity=cut(r,'int Rarity_Of','\nunsigned Rarity_Flags')
buy=cut(c,'static unsigned buy_price','\nstatic int card_rarity')
sale=cut(c,'static unsigned sale_price','\nstatic void rebuild')
prefix='''#include <assert.h>
#include <stdio.h>
#include <string.h>
#include <stdint.h>
typedef unsigned short u16;typedef unsigned u32;typedef int s32;
#define CARD_TABLE_ID_END 128
#define CARD_TYPE_MAGIC 20
#define CARD_TYPE_TRAP 21
#define CARD_TYPE_RITUAL 22
#define CARD_TYPE_EQUIP 23
#define MEMORIES_AFTER 1
struct Event {unsigned type,phase;int a,b,c,result,handled;};typedef struct Event MemoriesModEvent;
typedef struct {short x,y,w,h;} RECT;
struct Host {int (*applied)(const struct Host *);void *(*find)(const struct Host *,const char *);};
int active=1;int applied(const struct Host *h){(void)h;return active;}
int Rarity_ResaleMultiplier(int id);
void *find(const struct Host *h,const char *key){(void)h;assert(!strcmp(key,"lekak-rarities-test:resale-multiplier"));return Rarity_ResaleMultiplier;}
struct Host fakehost={applied,find};struct Host *host=&fakehost;
int mapped[5][5],rarity_count=5,rarity_tab;
unsigned char tier_by_id[128];unsigned short base_index_by_id[128];
int epoch=0,prepared[4]={-1,-1,-1,-1};unsigned short source[256],buffer[256],vram[512][1024],before[512][1024];
int chosen,pool_seen,rolls[10],roll_count,roll_pos;
s32 original_drop_mock(s32 pool){pool_seen=pool;return chosen;}s32 (*original_drop)(s32)=original_drop_mock;
int Rand_GetInterval(int n){assert(n==32768&&roll_pos<roll_count);return rolls[roll_pos++];}
void resolve(void){}
int Rarity_Map(int index){return index>0&&index<=5?mapped[rarity_tab][index-1]:0;}
unsigned char D_800EA1E8[1000];
int Cards_Type(int id){static const int types[5]={0,20,21,23,22};return types[(id-1)%5];}
int seen[128];int Cards_Seen(int id){return seen[id];}void Cards_MarkSeen(int id){seen[id]=1;}
int Duel_GetBaseCardStat(int id,int stat){(void)stat;return (id-1)%5==0?3000:0;}
int StoreImage2(RECT *r,u32 *data){assert(r->x>=0&&r->y>=0&&r->x+r->w<=1024&&r->y+r->h<=512);memcpy(data,&vram[r->y][r->x],2*r->w);return 0;}
int LoadImage2(RECT *r,u32 *data){assert(r->x>=0&&r->y>=0&&r->x+r->w<=1024&&r->y+r->h<=512);memcpy(&vram[r->y][r->x],data,2*r->w);return 0;}
'''
main='''
int main(void){
 for(int t=0;t<5;t++)for(int k=0;k<5;k++){int id=t*5+k+1;mapped[t][k]=id;tier_by_id[id]=t;base_index_by_id[id]=k+1;}
 int totals[5]={0};for(int roll=0;roll<10000;roll++){int t=Rarity_ChooseTier(roll);assert(t>=0&&t<=4);totals[t]++;}
 int expected[5]={8500,1000,300,150,50};for(int t=0;t<5;t++)assert(totals[t]==expected[t]);assert(Rarity_ChooseTier(-1)==-1&&Rarity_ChooseTier(10000)==-1);
 int sample[5]={0,8500,9500,9800,9950};
 for(int k=0;k<5;k++)for(int t=0;t<5;t++){chosen=k+1;rolls[0]=sample[t];roll_count=1;roll_pos=0;assert(drop(2)==mapped[t][k]);assert(pool_seen==2&&roll_pos==1);}
 chosen=2;rolls[0]=32767;rolls[1]=19950;roll_count=2;roll_pos=0;assert(drop(1)==mapped[4][1]&&roll_pos==2);
 chosen=0;roll_pos=roll_count=0;assert(drop(0)==0&&roll_pos==0);chosen=mapped[2][0];assert(drop(0)==chosen&&roll_pos==0);
 for(int t=1;t<=4;t++){for(int k=0;k<5;k++){int id=mapped[t][k];assert(Rarity_Kind(id)==k&&Rarity_Slot(id)==(t-1)*5+k);for(int j=0;j<k;j++)assert(Rarity_Color(id)!=Rarity_Color(mapped[t][j]));assert(sale_price(id)==(k==0?400u:50u)*((unsigned[]){1,3,8,20,50})[t]);}}
 for(int k=0;k<5;k++){assert(Rarity_Color(k+1)==0&&Rarity_Slot(k+1)==-1);assert(sale_price(k+1)==(k==0?400u:50u));}
 active=0;assert(sale_price(mapped[4][0])==400);active=1;
 for(int tier=0;tier<4;tier++)for(int k=0;k<5;k++)for(int gray=0;gray<=31;gray++){unsigned short w=gray|(gray<<5)|(gray<<10);assert(recolour(w,colours[tier][k])==w);assert(recolour(0,colours[tier][k])==0);}
 for(int y=0;y<512;y++)for(int x=0;x<1024;x++)vram[y][x]=0x8000|(x%32)|((y%32)<<5)|(((x+y)%32)<<10);
 memcpy(before,vram,sizeof(vram));for(int kind=0;kind<4;kind++)Rarity_Prepare(kind);
 for(int y=0;y<512;y++)for(int x=0;x<1024;x++)if(!(x>=768&&y>=192&&y<=235))assert(vram[y][x]==before[y][x]);
 for(int k=0;k<5;k++)for(int t=1;t<=4;t++){int slot=(t-1)*5+k;assert(vram[192+slot][768+13]==recolour(before[248+native_frame[k]][256+13],colours[t-1][k]));assert(vram[212+slot][768+13]==recolour(before[241+native_frame[k]][256+13],colours[t-1][k]));}
 for(int k=0;k<5;k++){rarity_tab=0;assert(Rarity_Cy(k+1)==247);for(int t=1;t<=4;t++){rarity_tab=t;int slot=(t-1)*5+k;assert(Rarity_Cx(k+1)==768+16*(slot%16));assert(Rarity_Cy(k+1)==232+slot/16);}}
 MemoriesModEvent ev={0,0,7,0,0,0,0};reward(&ev);assert(!seen[7]);ev.phase=MEMORIES_AFTER;reward(&ev);assert(seen[7]&&Rarity_CountSeen(1)==1&&Rarity_CountSeen(0)==0&&Rarity_CountSeen(2)==0);reward(&ev);assert(Rarity_CountSeen(1)==1);
 puts("PASS: exact drop buckets 85/10/3/1.5/0.5; original card selected first; RNG rejection; 20 type/rarity palettes; originals untouched; resale x1/3/8/20/50; reward discoveries isolated");return 0;
}
'''
(root/'inspect/rarity_tests/gameplay_test.c').write_text(prefix+rarity+palette+count+buy+sale+main)
