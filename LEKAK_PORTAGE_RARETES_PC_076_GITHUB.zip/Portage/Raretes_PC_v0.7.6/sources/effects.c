/* Rarity additions wrap the native effects. Original cards follow the exact
   original handlers; every mutable value here is per duel, never inventory. */
#include "rarity.h"
#include "effects.h"
#include "pc/cards/cards.h"
#include "pc/cards/tables.h"
#include "game/duel_action_lock.h"
#include "game/duel_side_state.h"
#include "game/duel_scene_card_placement.h"
#include "game/duel_magic_effect_dispatch.h"
#include "game/duel_card_effects.h"
#include "game/duel_card_checks.h"
#include "game/duel_trap_resolution.h"
#include "game/func_80025028.h"
#include "game/duel_ritual_controller.h"
#include "game/duel_field_effect_steps.h"
#include "game/duel_swords_effect.h"
#include "game/duel_init_scene.h"
#include "overlays/duel_effects/drawing_helpers.h"
#define DUEL_TERRAIN_AS_ARRAY
#include "game/duel_terrain_boost.h"
#include "game/main_modes.h"
#include "game/main_mode_state.h"
#include <string.h>
extern u8 D_8009B1B8;
static const int bonuses[5]={0,100,300,500,800};
/* Pointer-free, preserved in emulator save states. */
static struct {
 int played,base,tier,owner,second,active,success;
 int terrain,tier_terrain,owner_terrain;
 int trap_pending,trap_owner,trap_bonus;
 int ritual_result,ritual_applied;
 u16 before_flags[30];s16 before_mods[30];
} state;
static int (*native_damage)(int,int,int,int);
int Rarity_ApplyDamage(int side,int life,int amount,int kind){
 if(native_damage)return native_damage(side,life,amount,kind);
 /* The supplied older executable does not export the new helper. */
 return amount>=life?0:life-amount;
}
static s32 (*original_equip)(s32,s32);
static s32 equip(s32 gear,s32 monster){
 /* Match the standard card identities, including Lekak-specific rules.
    The actual variant id is retained for the equipped monster and its bonus. */
 if(!Rarity_Of(gear)&&!Rarity_Of(monster))return original_equip(gear,monster);
 return original_equip(Rarity_Original(gear),Rarity_Original(monster))?monster:0;
}
extern void rarity_number_target(s32,u8 *,SVECTOR *,u16,u16,u16) __asm__("duel_effects__func_801566D4");
static void (*original_number)(s32,u8 *,SVECTOR *,u16,u16,u16);
static void number(s32 value,u8 *color,SVECTOR *offset,u16 mode,u16 size,u16 bias){
 if(state.tier&&state.second&&state.base==gDuel_wEffectCardID){
  int amount=0;
  if(state.base>=338&&state.base<=342)amount=Rarity_HealingAmount();
  if(state.base>=343&&state.base<=347)amount=Rarity_DamageAmount();
  if(amount&&value)value=value<0?-amount:amount;
 }
 original_number(value,color,offset,mode,size,bias);
}
static void (*original_init)(void);
static int (*original_update)(void);
static void (*original_heal)(void),(*original_damage)(void),(*original_penalty)(void);
static void (*original_remove)(void),(*original_swords)(void);
static int (*original_attack_trap)(u8 *),(*original_trap_by_id)(int);
static int (*original_trap_presentation)(void);
static s32 (*original_calc)(DuelCardRecord *);
static int occupied(const DuelCardRecord *c){return (c->flags&DUEL_CARD_FLAG_OCCUPIED)!=0;}
static int card_owner(const DuelCardRecord *c){return c->table_index>=DUEL_CARD_SIDE_RECORD_COUNT;}
static int field_slot(int side,int index){return side*DUEL_CARD_SIDE_RECORD_COUNT+5+index;}
static void heal_side(int side,int amount){
 int life,cap,value;if(side<0||side>1||amount<=0)return;
 life=D_800E9FF0[side].life_points.unsigned_value;
 cap=D_800E9FF0[side].max_life_points;if(cap<life)cap=life;
 value=life+amount;if(value>cap)value=cap;
 D_800E9FF0[side].life_points.unsigned_value=value;
}
static void init_duel(void){memset(&state,0,sizeof(state));original_init();}
static void start_event(MemoriesModEvent *event){
 int i;
 if(event->c||event->phase!=MEMORIES_AFTER||event->handled)return;
 state.played=event->a;state.base=Cards_EffectId(event->a);
 state.tier=Rarity_Of(event->a);state.owner=D_8009B1D5;
 state.second=event->b!=0;state.active=gDuel_wCardEffectFlags!=0;
 state.success=0;state.ritual_result=0;state.ritual_applied=0;
 for(i=0;i<30;i++){state.before_flags[i]=D_801A7AD8[i].flags;state.before_mods[i]=D_801A7AD8[i].stat_modifier;}
}
int Rarity_HealingAmount(void){
 static const int amounts[5]={200,500,1000,2000,5000};
 int i=gDuel_wEffectCardID-338;
 return i>=0&&i<5?amounts[i]+bonuses[state.tier]:0;
}
int Rarity_DamageAmount(void){
 static const int amounts[5]={50,100,200,500,1000};
 int i=gDuel_wEffectCardID-343;
 return i>=0&&i<5?amounts[i]+bonuses[state.tier]:0;
}
int Rarity_PenaltyAmount(void){return (gDuel_wEffectCardID==349?500:1000)+bonuses[state.tier];}
static void healing(void){if(state.tier)Rarity_ValueLifePointRecovery();else original_heal();}
static void damage(void){if(state.tier)Rarity_ValueDirectDamage();else original_damage();}
static void penalty(void){if(state.tier)Rarity_ValueStatPenalty();else original_penalty();}
static void removal(void){
 int fresh=!(gDuel_wCardEffectFlags&0x80);original_remove();
 if(fresh&&state.tier&&gDuel_wEffectCardID==661){
  D_8009B1AC=1500-bonuses[state.tier];
  /* The original initialized the ATK selector flag before this change. */
 }
}
static void swords(void){
 int old=D_800E9FF0[D_8009B1D5^1].swords_turns_remaining;
 original_swords();
 if(state.tier&&gDuel_wCardEffectFlags==0&&
    D_800E9FF0[D_8009B1D5^1].swords_turns_remaining>0){
  static const int turns[5]={3,3,4,4,5};
  D_800E9FF0[D_8009B1D5^1].swords_turns_remaining=turns[state.tier]+1;
  if(state.tier==1)heal_side(state.owner,100);
  if(state.tier==3)heal_side(state.owner,300);
 }
 (void)old;
}
/* Terrain extra is evaluated per record. No modified global type table,
   no accumulation after repeated casts, and penalties remain native. */
static int terrain_extra(DuelCardRecord *card){
 if(!state.tier_terrain||state.terrain!=gDuel_bTerrain[0]||
    card_owner(card)!=state.owner_terrain||Cards_Type(card->card_id)>=CARD_TYPE_MAGIC)return 0;
 return Duel_GetTerrainBoost(Cards_Type(card->card_id))>0?bonuses[state.tier_terrain]:0;
}
static s32 calc(DuelCardRecord *card){
 int extra=terrain_extra(card),a,d;
 if(!extra)return original_calc(card);
 a=card->attack+card->stat_modifier+card->terrain_modifier+extra;
 d=card->defense+card->stat_modifier+card->terrain_modifier+extra;
 if(a<0)a=0;if(d<0)d=0;
 if(a>Tables_StatCap(0))a=Tables_StatCap(0);
 if(d>Tables_StatCap(1))d=Tables_StatCap(1);
 return (s32)(((unsigned)d<<16)|(unsigned)a);
}
int Rarity_RitualPreview(int id){
 int own,bonus;
 if(!state.active||!state.second||!state.tier||Cards_Type(state.played)!=CARD_TYPE_RITUAL||
    id!=D_8009B1A0)return 0;
 own=bonuses[Rarity_Of(id)];bonus=bonuses[state.tier]-own;
 return bonus>0?bonus:0;
}
void Rarity_RitualRecord(DuelCardRecord *card){
 int extra;if(!card||!state.active||!state.second||state.ritual_applied||
    Cards_Type(state.played)!=CARD_TYPE_RITUAL||(D_8009B210&15)!=3||
    card->table_index!=D_8009B19C||card->card_id!=D_8009B1A0)return;
 extra=Rarity_RitualPreview(card->card_id);
 card->attack+=extra;card->defense+=extra;
 if(card->attack>Tables_StatCap(0))card->attack=Tables_StatCap(0);
 if(card->defense>Tables_StatCap(1))card->defense=Tables_StatCap(1);
 state.ritual_applied=1;state.ritual_result=card->card_id;
}
static int utility(int base){
 switch(base){case 320:case 329:case 336:case 337:case 350:case 653:
 case 655:case 656:case 660:case 662:case 663:case 664:case 672:return 1;}
 return 0;
}
static int changed(int base,int side,const u16 *flags,const s16 *mods){
 int i,first=field_slot(side^1,0),last=first+5;
 if(base==655){first=field_slot(side,0);last=first+5;}
 if(base==672){first=field_slot(side^1,5);last=first+5;}
 if(base==336){first=0;last=30;}
 for(i=first;i<last;i++){
  DuelCardRecord *c=&D_801A7AD8[i];
  /* Dark Hole counts only field rows, never a consumed hand spell. */
  if(base==336&&(i%15)<5)continue;
  if(base==320){if((flags[i]&0x8800)==0x8800&&!(c->flags&0x800))return 1;}
  else if(base==350){if((flags[i]&0x9000)==0x9000&&!(c->flags&0x1000))return 1;}
  else if(base==655){if((flags[i]&0x8000)&&mods[i]<0&&c->stat_modifier==0)return 1;}
  else if((flags[i]&0x8000)&&!occupied(c))return 1;
 }
 return 0;
}
static int update(void){
 int result,was=gDuel_wCardEffectFlags;
 result=original_update();
 if(state.active&&state.second&&state.tier&&utility(state.base)&&
    changed(state.base,state.owner,state.before_flags,state.before_mods))state.success=1;
 if(state.active&&state.second&&was&&gDuel_wCardEffectFlags==0){
  if(state.base>=330&&state.base<=335){
   state.terrain=gDuel_bTerrain[0];state.tier_terrain=state.tier;state.owner_terrain=state.owner;
  }
  if(state.tier&&state.success&&utility(state.base))heal_side(state.owner,bonuses[state.tier]);
  state.active=0;
 }
 return result;
}
static void remember_trap(void){
 DuelCardRecord *c;int tier,base;
 state.trap_pending=0;
 if(D_8009B1B8>=30)return;
 c=&D_801A7AD8[D_8009B1B8];tier=Rarity_Of(c->card_id);base=Cards_TrapId(c->card_id);
 if(tier&&base>=686&&base<=690){state.trap_pending=1;state.trap_owner=card_owner(c);state.trap_bonus=bonuses[tier];}
}
static int by_id(int id){int result=original_trap_by_id(id);if(result)remember_trap();return result;}
static int attack_trap(u8 *attacker){
 int i,has_variant=0,best=-1,best_base=999,idx,base,atk,result;
 DuelCardRecord *c,*chosen=0,*fake=0;
 for(i=0;i<5;i++){
  c=&D_801A7AD8[D_800907D8[D_8009B1D5*20+i]];
  if(occupied(c)&&Cards_Type(c->card_id)==CARD_TYPE_TRAP&&Rarity_Of(c->card_id))has_variant=1;
 }
 if(!has_variant){result=original_attack_trap(attacker);if(result)remember_trap();return result;}
 idx=((DisplayObject *)attacker)->field_6A;if(idx<0||idx>=30)return 0;
 atk=(unsigned)Duel_CalcCardStats(&D_801A7AD8[idx])&0xffff;
 for(i=0;i<5;i++){
  c=&D_801A7AD8[D_800907D8[D_8009B1D5*20+i]];if(!occupied(c))continue;
  base=Cards_TrapId(c->card_id);
  if(base==690){if(!fake)fake=c;continue;}
  if(base>=681&&base<=686){
   static const int thresholds[6]={500,1000,1500,2000,3000,25500};
   int limit=Tables_TrapThreshold(base-681,thresholds[base-681]);
   if(base<686)limit+=bonuses[Rarity_Of(c->card_id)];
   if(atk<=limit&&base<best_base){best=i;best_base=base;chosen=c;}
  }
 }
 (void)best;
 if(!chosen)chosen=fake;
 if(!chosen){D_8009B22A=0;return 0;}
 D_8009B22A=Cards_TrapId(chosen->card_id);
 D_8009B1B8=((DisplayObject *)chosen->object)->field_6A;
 remember_trap();return 1;
}
static int presentation(void){
 int result=original_trap_presentation();
 if(!result&&state.trap_pending){heal_side(state.trap_owner,state.trap_bonus);state.trap_pending=0;}
 return result;
}
void Rarity_EffectsFrame(void){
 /* A new duel starts through init_duel. A changed terrain from another mod
    drops ownership metadata until one of our tracked casts installs it. */
 if(state.tier_terrain&&state.terrain!=gDuel_bTerrain[0])state.tier_terrain=0;
}
int Rarity_EffectsInit(const MemoriesModHost *host){
 native_damage=host->symbol(host,"Mods_DamageLife");
 if(!host->hook(host,Duel_CheckEquip,equip,(void **)&original_equip))return 0;
 if(!host->hook(host,rarity_number_target,number,(void **)&original_number))return 0;
 if(!host->register_state(host,&state,sizeof(state),1))return 0;
 if(!host->subscribe(host,MEMORIES_EVENT_EFFECT,-100,start_event))return 0;
 if(!host->hook(host,Duel_InitScene,init_duel,(void **)&original_init))return 0;
 if(!host->hook(host,DuelEffect_UpdateCardEffect,update,(void **)&original_update))return 0;
 if(!host->hook(host,DuelEffect_ApplyLifePointRecovery,healing,(void **)&original_heal))return 0;
 if(!host->hook(host,DuelEffect_ApplyDirectDamage,damage,(void **)&original_damage))return 0;
 if(!host->hook(host,DuelEffect_ApplyStatPenalty,penalty,(void **)&original_penalty))return 0;
 if(!host->hook(host,DuelEffect_ApplyMonsterRemoval,removal,(void **)&original_remove))return 0;
 if(!host->hook(host,DuelEffect_ApplySwords,swords,(void **)&original_swords))return 0;
 if(!host->hook(host,Duel_CalcCardStats,calc,(void **)&original_calc))return 0;
 if(!host->hook(host,Duel_SelectAttackTrap,attack_trap,(void **)&original_attack_trap))return 0;
 if(!host->hook(host,Duel_SelectTrapByCardId,by_id,(void **)&original_trap_by_id))return 0;
 if(!host->hook(host,Duel_UpdateTrapPresentation,presentation,(void **)&original_trap_presentation))return 0;
 return 1;
}
