/* Walk only the newly emitted DMA packets. libgs masks bank bits on its
   sprite paths; restore them in the final E1/UV command, after conversion.
   Packet links, lengths, positions, UVs, colours and render flags stay intact. */
static void rarity_patch_packets(u32 *begin,u32 *end) {
 u32 *node=begin;
 while(node<end){
  unsigned count=node[0]>>24;
  u32 *q=node+1,*limit;
  if(count>(unsigned)(end-q))return;
  limit=q+count;
  while(q<limit){
   unsigned op=q[0]>>24,n=0;
   if(op==0xe1){q[0]=(q[0]&~(15u<<11))|(13u<<11);n=1;}
   else if((op&0xe0)==0x20){
    unsigned textured=op&4,gouraud=op&16,vertices=(op&8)?4:3;
    n=1+vertices+(textured?vertices:0)+(gouraud?vertices-1:0);
    if(n>(unsigned)(limit-q))return;
    if(textured){unsigned i=gouraud?5:4;q[i]=(q[i]&~(15u<<27))|(13u<<27);}
   }else if((op&0xe0)==0x60){
    n=2+((op&4)?1:0)+((op&0x18)?0:1);
   }else if(op>=0xe2&&op<=0xe6)n=1;
   else return;
   if(n>(unsigned)(limit-q))return;
   q+=n;
  }
  node=limit;
 }
}
