#include "rarity.h"
#include "pc/mods/modapi.h"
#include "pc/cards/cards.h"
#include "game/library_runtime.h"
#include "game/library_grid_cursor.h"
#include "game/func_80029EC4.h"
#include "game/func_80029EB0.h"
#include "game/func_800291E0.h"
#include "game/func_80016784.h"
#include "game/func_80015EF4.h"
#include "game/duel_card_record_lifecycle.h"
#include "game/duel_effect_resource_record.h"
#include "game/main_mode_state.h"
#include "game/main_modes.h"
#include "game/card_grid.h"
#include "game/save_data.h"
#include "game/graphics_frame.h"
#include "game/func_8002A2F4.h"
#include "game/text_staging.h"
#include "game/duel_rewards.h"
#include "game/func_80027DF8.h"
#include "game/card_list_sort.h"
#include "game/card_list_render_deck_box_stats.h"
#include "game/func_800323F8.h"
#include "game/build_deck_card_counts.h"
#include "game/duel_get_base_card_stat.h"
#include "game/duel_terrain_boost.h"
#include "game/duel_deck_card.h"
#include "game/duel_card.h"
#include "pc/cards/tables.h"
#include "game/duel_card_stat_display.h"
#include "game/rand_get_interval.h"
#include "game/duel_effect.h"
#include "game/text_box_lifecycle.h"
#include "game/text_box_runtime.h"
#include "game/display_object_helpers.h"
#include <string.h>
#include <stdio.h>
#include "identities.h"
#include "effects.h"
#include "pc/render/soft_gpu.h"
#include "game/display_object_packet_submit.h"
#include "game/gpu_packets.h"
#include "packet_bank.h"
static const MemoriesModHost *host;
int rarity_count=RARITY_BASE_COUNT,rarity_tab;
static int mapped[5][RARITY_BASE_COUNT];
static unsigned char tier_by_id[CARD_TABLE_ID_END];
static unsigned short base_index_by_id[CARD_TABLE_ID_END];
static s32 (*original_drop)(s32);
static s32 (*original_stat)(s32,s32);
static u8 *(*original_record)(s32,s32);
static void (*original_ai)(AiActiveCard *,s32);
void Rarity_Sort(CardList *list);
void Rarity_DeckBox(DisplayObject *,GsOT *);
void Rarity_DeckSetup(u8 *,void *,s32,s32);
void Rarity_AddCard(s32,s32);
static unsigned short boosted_attack[CARD_TABLE_ID_END],boosted_defense[CARD_TABLE_ID_END];
static DisplayObject *(*original_icon)(s32,s32,s32,s32,s32);
static int resolved,epoch,prepared[4]={-1,-1,-1,-1};
static void (*original_enter)(void);
static u8 *(*original_view)(s32,s32,s32);
static DuelCardDisplayObject *(*original_field_create)(s32,s32,s32);
static unsigned short source[256],buffer[256];
static const char *labels[5]={"Library Standard","Library Rare","Library Epic","Library Legendary","Library Mythic"};
static void apply_boosts(void);
static void resolve(void) {
 int i,t,id;
 if(resolved)return;
 if(gCard_nCount<rarity_count*5)return;
 memset(tier_by_id,0,sizeof(tier_by_id));
 memset(base_index_by_id,0,sizeof(base_index_by_id));
 for(i=0;i<RARITY_BASE_COUNT;i++) {
  mapped[0][i]=identities[i].retail ? identities[i].retail : host->card_id(host,identities[i].key[0]);
  if(mapped[0][i]>0&&mapped[0][i]<CARD_TABLE_ID_END)base_index_by_id[mapped[0][i]]=i+1;
  for(t=1;t<=4;t++) { id=host->card_id(host,identities[i].key[t]); mapped[t][i]=id; if(id>0&&id<CARD_TABLE_ID_END){tier_by_id[id]=t;base_index_by_id[id]=i+1;} }
 }
 resolved=1;
 apply_boosts();
 for(t=0;t<=4;t++)for(i=0;i<rarity_count;i++)if(mapped[t][i]<=0){host->log(host,"Missing catalogue entry tier=%d index=%d",t,i+1);}

}
int Rarity_Map(int index) { resolve(); return index>0&&index<=rarity_count?mapped[rarity_tab][index-1]:0; }
int Rarity_Of(int id) { resolve();return id>0&&id<CARD_TABLE_ID_END?tier_by_id[id]:0; }
unsigned Rarity_Flags(unsigned char *state,int index) {int id=Rarity_Map(index);return id?Library_GetCardFlags(state,id):0;}
/* Type order: monster, magic, trap, equip, ritual. Twenty distinct
   type/rarity slots. The native source palettes are never overwritten. */
static const unsigned colours[4][5]={
 {0x00C853,0x1976FF,0xFF4F9A,0xFFD400,0xFF8A00},
 {0xE53935,0xFF8A00,0x8E44D4,0x1976FF,0xFFD400},
 {0x00D9ED,0xFFD400,0xEAEFF5,0xFF8A00,0x00C853},
 {0x8E44D4,0xFF4F9A,0xE53935,0x00C853,0x1976FF}
};
static const int native_frame[5]={0,1,2,1,3};
int Rarity_Kind(int id) {
 switch(Cards_Type(id)) {
 case CARD_TYPE_MAGIC:return 1;case CARD_TYPE_TRAP:return 2;
 case CARD_TYPE_EQUIP:return 3;case CARD_TYPE_RITUAL:return 4;
 default:return 0;
 }
}
int Rarity_Slot(int id){int t=Rarity_Of(id);return t?(t-1)*5+Rarity_Kind(id):-1;}
unsigned Rarity_Color(int id){int t=Rarity_Of(id);return t?colours[t-1][Rarity_Kind(id)]:0;}
int Rarity_Cx(int index) {
 int id=Rarity_Map(index),slot=Rarity_Slot(id);
 return slot>=0?16*(slot%16):*(u16 *)(D_800EA1E8+id*4+0x54);
}
int Rarity_Cy(int index) {
 int slot=Rarity_Slot(Rarity_Map(index));return slot>=0?40+slot/16:247;
}
/* Native BGR555 colour mapping retains each type's shadows, relief,
   transparency and neutral black/white accents. */
static unsigned short recolour(unsigned short w,unsigned colour) {
 int r=w&31,g=(w>>5)&31,b=(w>>10)&31,max=r>g?r:g,min=r<g?r:g;
 int tr=(colour>>19)&31,tg=(colour>>11)&31,tb=(colour>>3)&31;
 int peak=tr>tg?tr:tg,span;
 if(b>max)max=b;if(b<min)min=b;if(tb>peak)peak=tb;
 if(!(w&0x7fff)||max-min<=2||!peak)return w;
 span=max-min;r=min+span*tr/peak;g=min+span*tg/peak;b=min+span*tb/peak;
 return (w&0x8000)|r|(g<<5)|(b<<10);
}
/* Bank CLUTs live at x0..255, y0..43, disjoint from the card texture
   pages (x704 and above). Object coordinates remain virtual markers; the
   packet hook translates them only while submitting the rarity primitive.
   Never put rarity CLUTs in native VRAM: those addresses also contain
   menu textures. Bank 13 holds only the sampled texture pages and CLUTs.
   Read the CPU mirror directly: StoreImage2 would flush the renderer for
   each palette and defeat batching. No full-VRAM copy, no native upload. */
static unsigned short palette_source[4][5][256];
static unsigned char palette_valid[4][5];
int Rarity_Page(int page) {
 unsigned short *bank=SoftGpu_Bank(13);
 const unsigned short *vram=SoftGpu_Vram();
 int x=(page&15)*64,y=(page&16)?256:0;
 /* SpritePrim may keep pixel depth in its attribute, not tpage. Copy
    up to 256 words so 4/8/16-bit views of this page are all covered. */
 int w=256,row;
 if(!bank)return page&~(15<<11);
 if(w>1024-x)w=1024-x;
 for(row=0;row<256;row++){
  int offset=(y+row)*1024+x;
  if(memcmp(bank+offset,vram+offset,w*sizeof(*bank)))
   memcpy(bank+offset,vram+offset,w*sizeof(*bank));
 }
 return (page&~(15<<11))|(13<<11);
}
void Rarity_Prepare(int kind) {
 unsigned short *bank;
 const unsigned short *vram;
 int i,t,k,slot,n,sx,sy,dx,dy;
 if(kind<0||kind>3)return;
 bank=SoftGpu_Bank(13);if(!bank)return;
 vram=SoftGpu_Vram();n=kind>=2?16:256;
 for(k=0;k<5;k++){
  sx=kind==3?608+16*native_frame[k]:kind==2?352+16*native_frame[k]:256;
  sy=kind==0?248+native_frame[k]:kind==1?241+native_frame[k]:kind==3?252:247;
  if(palette_valid[kind][k]&&!memcmp(palette_source[kind][k],vram+sy*1024+sx,n*sizeof(*bank)))continue;
  memcpy(palette_source[kind][k],vram+sy*1024+sx,n*sizeof(*bank));
  for(t=1;t<=4;t++){
   slot=(t-1)*5+k;
   dx=kind>=2?16*(slot%16):0;
   dy=kind==0?slot:kind==1?20+slot:(kind==3?42:40)+slot/16;
   for(i=0;i<n;i++)bank[dy*1024+dx+i]=recolour(palette_source[kind][k][i],colours[t-1][k]);
  }
  palette_valid[kind][k]=1;
 }
}
static void (*original_packet)(SpritePrim *,u8 *,s32,s32,u8 *);
static void packet(SpritePrim *sprite,u8 *bytes,s32 ot,s32 mode,u8 *extra){
 unsigned draw=(unsigned)mode>>16;int kind=-1,old;
 if(draw&&draw!=4&&draw!=5){
  int x=sprite->cxcy.h.cx,y=sprite->cxcy.h.cy;
  if(x==768&&y>=192&&y<212)kind=0;
  else if(x==768&&y>=212&&y<232)kind=1;
  else if(x>=768&&x<=1008&&!(x&15)&&y>=234&&y<236)kind=3;
  if(kind>=0){
   u32 *emitted=D_800FE240;
   old=sprite->tpage;sprite->tpage=Rarity_Page(old);Rarity_Prepare(kind);
   sprite->cxcy.h.cx=x-768;sprite->cxcy.h.cy=y-192;
   original_packet(sprite,bytes,ot,mode,extra);
   rarity_patch_packets(emitted,D_800FE240);
   sprite->tpage=old;sprite->cxcy.h.cx=x;sprite->cxcy.h.cy=y;return;
  }
 }
 original_packet(sprite,bytes,ot,mode,extra);
}
static const int monster_bonus[5]={0,100,300,500,800};
static unsigned boost_stat(unsigned original,int tier,int cap) {
 unsigned value=original+monster_bonus[tier];return value>(unsigned)cap?(unsigned)cap:value;
}
static void apply_boosts(void) {
 int i,t,id,base;unsigned word,a,d,packed_a,packed_d;
 memset(boosted_attack,0,sizeof(boosted_attack));memset(boosted_defense,0,sizeof(boosted_defense));
 for(i=0;i<rarity_count;i++) {
  base=mapped[0][i];if(base<=0||Cards_Type(base)>=CARD_TYPE_MAGIC)continue;
  word=(unsigned)gDuel_adwCardStats[base-1];a=(word&511)*10;d=((word>>9)&511)*10;
  for(t=1;t<=4;t++) {
   id=mapped[t][i];if(id<=0)continue;
   boosted_attack[id]=boost_stat(a,t,Tables_StatCap(0));
   boosted_defense[id]=boost_stat(d,t,Tables_StatCap(1));
   packed_a=boosted_attack[id]/10;if(packed_a>511)packed_a=511;
   packed_d=boosted_defense[id]/10;if(packed_d>511)packed_d=511;
   /* Preserve this card's own type, stars and flags; only the two numeric
      fields change. Wider stats are retained separately, never wrapped. */
   word=(unsigned)gDuel_adwCardStats[id-1];
   gDuel_adwCardStats[id-1]=(word&~0x3ffffu)|packed_a|(packed_d<<9);
  }
 }
}
int Rarity_RawStat(int id,int defense) {
 unsigned word;resolve();
 if(id<=0||id>=CARD_TABLE_ID_END)return 0;
 if(Rarity_Of(id)&&Cards_Type(id)<CARD_TYPE_MAGIC)return defense?boosted_defense[id]:boosted_attack[id];
 word=(unsigned)gDuel_adwCardStats[id-1];return ((word>>(defense?9:0))&511)*10;
}
static void ai(AiActiveCard *out,s32 side) {
 int i;original_ai(out,side);
 /* The first ten are field cards whose effective stats already include
    buffs/debuffs. The remaining slots are hand/deck base stats. */
 for(i=10;i<55;i++)if(Rarity_Of(out[i].card_id)&&Cards_Type(out[i].card_id)<CARD_TYPE_MAGIC){
  out[i].attack=boosted_attack[out[i].card_id];out[i].defense=boosted_defense[out[i].card_id];
 }
}
int Rarity_Original(int id) {
 int index;resolve();if(!host->applied(host)||id<=0||id>=CARD_TABLE_ID_END)return id;
 index=base_index_by_id[id];return index?mapped[0][index-1]:id;
}
static s32 stat(s32 id,s32 defense) {
 int value;
 if(!Rarity_Of(id)||Cards_Type(id)>=CARD_TYPE_MAGIC)return original_stat(id,defense);
 value=(defense?boosted_defense[id]:boosted_attack[id])+Duel_GetTerrainBoost(Cards_Type(id));
 if(value<0)value=0;if(value>Tables_StatCap(defense!=0))value=Tables_StatCap(defense!=0);
 return value;
}
static u8 *record(s32 a,s32 b) {
 DuelCardRecord *card=(DuelCardRecord *)original_record(a,b);
 if(card&&Rarity_Of(card->card_id)&&Cards_Type(card->card_id)<CARD_TYPE_MAGIC){
  card->attack=boosted_attack[card->card_id];card->defense=boosted_defense[card->card_id];
 }
 Rarity_RitualRecord(card);
 return (u8 *)card;
}
int Rarity_ResaleMultiplier(int id) {
 static const int rates[5]={1,3,8,20,50};
 if(!host->applied(host))return 1;
 return rates[Rarity_Of(id)];
}
int Rarity_ChooseTier(int roll) {
 if(roll<0||roll>=10000)return -1;
 if(roll<8500)return 0;if(roll<9500)return 1;
 if(roll<9800)return 2;if(roll<9950)return 3;return 4;
}
static s32 drop(s32 pool) {
 int chosen=original_drop(pool),base,tier,roll,id;
 resolve();
 if(chosen<=0||chosen>=CARD_TABLE_ID_END||Rarity_Of(chosen))return chosen;
 base=base_index_by_id[chosen];if(!base)return chosen;
 /* First the original pool selects the card. Draw rarity second; reject
    the high tail of the game's 15-bit RNG to avoid modulo bias. */
 do {roll=Rand_GetInterval(32768);}while(roll>=30000);
 tier=Rarity_ChooseTier(roll%10000);
 id=mapped[tier][base-1];return id>0?id:chosen;
}
static void reward(MemoriesModEvent *event) {
 if(event->phase==MEMORIES_AFTER&&Rarity_Of(event->a))Cards_MarkSeen(event->a);
}

int Rarity_CountSeen(int tab) {
 int i,n=0;
 if(tab<0||tab>4)return 0;
 for(i=0;i<rarity_count;i++) {
  int id=mapped[tab][i];
  if(id>0&&Cards_Seen(id))n++;
 }
 return n;
}
void Rarity_Refresh(void) {
 TextStagingValues saved;
 DuelEffectChannel *heading=&D_800EB0F8[3];
 DisplayObject *old=heading->field_28;
 u16 flags=old?old->flags:0;
 s32 x=heading->field_3C,y=heading->field_40;
 s32 width=heading->field_3E,height=heading->field_42;
 int n=Rarity_CountSeen(rarity_tab);
 /* The heading is composed once into glyphs. Updating its shared staging
    word cannot change those glyphs, and the selected-card caption uses
    that same word. Rebuild ONLY channel 3 from this category's true seen
    count, then restore the selected-card staging. Preview flags never count. */
 func_8002A2F4(D_800EA1E8);
 saved=D_801D5608[0];
 D_801D5608[0].library_count=n;
 if(old) {
  u8 *box;
  TextBox_Destroy(heading);
  box=TextBox_Create(3,0xF8,x,y,width,height);
  box[0x5A]=16;box[0x5B]=16;
  func_80039A14((DuelEffectChannel *)box);
  if(heading->field_28) {
   DisplayObject_SelectOrderingTable3(heading->field_28);
   ((DisplayObject *)heading->field_28)->flags=flags;
  }
 }
 D_801D5608[0]=saved;
}

static void enter(void) {
 int total=gCard_nCount,t,i,id; resolve();rarity_tab=0;
 /* Build the identical original panels using only the normal catalogue. */
 gCard_nCount=rarity_count;original_enter();gCard_nCount=total;
 /* The original entry only visited the normal catalogue while its size
    was reduced for the panels. Reconcile the real trunk AND deck after
    restoring the complete table, so owned variants become discoveries. */
 Library_MarkOwnedCards();
 for(t=1;t<=4;t++)for(i=0;i<rarity_count;i++) {
  id=mapped[t][i];if(!id)continue;
  *(u16 *)(D_800EA1E8+id*4+0x54)=352;
  D_800EA1E8[id*4+0x56]=Cards_Seen(id)?(0x80|(!*Cards_ChestSlot(gDuel_awPlayerDeck,id))):0;
 }
 Rarity_Refresh();
 prepared[0]=prepared[1]=prepared[2]=prepared[3]=-1;
}
static u8 *view(s32 index,s32 x,s32 y) {
 DisplayObject *obj=(DisplayObject *)original_view(index,x,y);
 int t=Rarity_Of((s16)D_800EA0E8[index].field_30);
 if(obj&&Rarity_RitualPreview((s16)D_800EA0E8[index].field_30)){
  int extra=Rarity_RitualPreview((s16)D_800EA0E8[index].field_30);
  if(x<0)D_800EA0E8[index].field_32=Rarity_RawStat((s16)D_800EA0E8[index].field_30,0)+extra;
  if(y<0)D_800EA0E8[index].field_34=Rarity_RawStat((s16)D_800EA0E8[index].field_30,1)+extra;
 }
 if(t&&obj&&Cards_Type((s16)D_800EA0E8[index].field_30)<CARD_TYPE_MAGIC){
  int id=(s16)D_800EA0E8[index].field_30;
  if(x<0)D_800EA0E8[index].field_32=boosted_attack[id]+Rarity_RitualPreview(id);
  if(y<0)D_800EA0E8[index].field_34=boosted_defense[id]+Rarity_RitualPreview(id);
 }
 if(t&&obj){Rarity_Prepare(0);obj->field_40.h.field_40=768;obj->field_40.h.field_42=192+Rarity_Slot((s16)D_800EA0E8[index].field_30);}
 return (u8 *)obj;
}
static DuelCardDisplayObject *field_create(s32 id,s32 x,s32 y) {
 DuelCardDisplayObject *obj=original_field_create(id,x,y);int t=Rarity_Of(id);
 if(t&&obj)obj->icon_variant=100+Rarity_Slot(id);return obj;
}
static DisplayObject *icon(s32 id,s32 x,s32 y,s32 a,s32 b) {
 DisplayObject *obj=original_icon(id,x,y,a,b);int slot=Rarity_Slot(id);
 if(slot>=0&&obj){Rarity_Prepare(3);obj->field_40.h.field_40=768+16*(slot%16);obj->field_40.h.field_42=234+slot/16;}
 return obj;
}
static void frame(void){resolve();epoch++;Rarity_EffectsFrame();}
static void reset(void){memset(palette_valid,0,sizeof(palette_valid));resolved=0;rarity_tab=0;prepared[0]=prepared[1]=prepared[2]=prepared[3]=-1;}
static void overlay(void) {
 int w,h,s,width;
 if((D_8009B26C[0]&31)!=MAIN_MODE_LIBRARY)return;
 host->overlay_size(host,&w,&h,&s);
 /* The overlay covers the whole window, including the menu bar. Keep
    the title in the game header, centred above the native card counter. */
 s=h/300; if(s<1)s=1;
 width=host->text_width(host,labels[rarity_tab],s);
 while(s>1&&width>w-24){s--;width=host->text_width(host,labels[rarity_tab],s);}
 host->draw_text(host,(w-width)/2+1,h*8/100+1,labels[rarity_tab],0x000000,s);
 host->draw_text(host,(w-width)/2,h*8/100,labels[rarity_tab],0xffffff,s);
}
int MemoriesModInit(const MemoriesModHost *h,MemoriesMod *mod) {
 host=h;if(h->api<4)return 0;
 mod->api=4;mod->frame=frame;mod->reset=reset;mod->overlay=overlay;
 if(!h->provide(h,"rarity",Rarity_Of)
    ||!h->provide(h,"resale-multiplier",Rarity_ResaleMultiplier)
    ||!h->provide(h,"frame-color",Rarity_Color)
    ||!h->provide(h,"resale-base",Rarity_Original))return 0;
 if(!h->hook(h,DisplayObject_SubmitPacket,packet,(void **)&original_packet))return 0;
 if(!Rarity_EffectsInit(h))return 0;
 if(!h->hook(h,CardList_RenderDeckBoxStats,Rarity_DeckBox,0))return 0;
 if(!h->hook(h,func_800323F8,Rarity_DeckSetup,0))return 0;
 if(!h->hook(h,BuildDeck_AddCard,Rarity_AddCard,0))return 0;
 if(!h->hook(h,func_80027DF8,ai,(void **)&original_ai))return 0;
 if(!h->hook(h,func_80032C48,Rarity_Sort,0))return 0;
 if(!h->hook(h,Duel_GetBaseCardStat,stat,(void **)&original_stat))return 0;
 if(!h->hook(h,Duel_SetupCardRecord,record,(void **)&original_record))return 0;
 if(!h->hook(h,func_80031574,icon,(void **)&original_icon))return 0;
 if(!h->hook(h,Duel_SelectCardDrop,drop,(void **)&original_drop))return 0;
 if(!h->subscribe(h,MEMORIES_EVENT_REWARD,0,reward))return 0;
 if(!h->hook(h,func_8002BFCC,enter,(void **)&original_enter))return 0;
 if(!h->hook(h,Library_DrawCardGrid,Rarity_Grid,0))return 0;
 if(!h->hook(h,Library_GetGridCursorCardId,Rarity_CursorId,0))return 0;
 if(!h->hook(h,Library_UpdateGridCursor,Rarity_Update,0))return 0;
 if(!h->hook(h,func_800291E0,view,(void **)&original_view))return 0;
 if(!h->hook(h,func_80016784,Rarity_Hand,0))return 0;
 if(!h->hook(h,func_80024C1C,field_create,(void **)&original_field_create))return 0;
 if(!h->hook(h,func_80015EF4,Rarity_Field,0))return 0;
 return 1;
}
