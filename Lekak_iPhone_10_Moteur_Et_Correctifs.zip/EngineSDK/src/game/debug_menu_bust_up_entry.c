#include "../types.h"
#include "display_effect_update_menu_record.h"
#include "rand_get_interval.h"
#include "func_8003134C.h"
#include "menu_record.h"
#include "display_object.h"
#include "display_object_brightness.h"
#include "display_object_layout.h"
#include "../unmatched.h"
#include "campaign_scene_package.h"
#include "frontend_debug_state.h"
#include "debug_menu_bust_up_entry.h"

void func_8003134C(void)
{
}

void DebugMenu_UpdateBustUpEntry(void)
{
    u8 flags = D_8009B2EB;

    if (!(flags & FRONTEND_STEP_FLAG_ENTERED)) {
        D_8009B2EB = flags | FRONTEND_STEP_FLAG_ENTERED;
        D_8009B2DE = 0;
        Campaign_LoadScenePackage(0);
    }

    func_8003134C();

    if (D_8009B2DE == 0) {
        DisplayObject *first = D_800EB184[0];
        DisplayObject *second = D_8009B2E4;
        u16 second_flags;

        first->flags |= DISPLAY_OBJECT_FLAG_RENDERABLE;

        second_flags = second->flags;
        D_8009B2EB = 0;
        second_flags |= DISPLAY_OBJECT_FLAG_RENDERABLE;
        second->flags = second_flags;
    } else {
        s32 value = Rand_GetInterval(4);
        DisplayEffect_UpdateMenuRecord(D_800EB010, value);
    }
}
