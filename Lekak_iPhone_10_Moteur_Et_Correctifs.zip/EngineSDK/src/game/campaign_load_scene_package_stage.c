#define DUEL_PACKAGE_STAGE_RAW_ARENAS
#include "../types.h"
#include "../psyq/libgte.h"
#include "../psyq/libgpu.h"
#include "file_transfer.h"
#include "duel_load_package_stage.h"
#include "../unmatched.h"
#include "../ygo_types.h"
#include "campaign_scene_package.h"

#include "high_memory_addresses.h"

void Campaign_LoadScenePackageStage(FileTransferDescriptor *p, s32 stage)
{
    s32 v_0;
    s32 v_1;
    s32 v_2;
    s32 v_3;
    s32 w;
    s32 t;
    s32 m;
    s32 c;

    switch (stage) {
    case 0:
        *(s16 *)&p->field_30.h.counter = 0x340;
        *(u16 *)&p->w = 0x40;
        m = 0xFFDDFFFF;
        v_0 = D_8009B0F4;
        *(u16 *)&p->h = 0x10;
        v_0 &= m;
        D_8009B0F4 = v_0;
        w = D_8009B0F4;
        *(s16 *)&p->field_30.h.field_32 = 0;
        w |= 0x10000;
        D_8009B0F4 = w;
        p->done = 2;
        t = (p->value_08 = D_8009B118);
        *(s32 *)&p->phase_size = 16 * FILE_SECTOR_SIZE;
        p->value_0C = t + FILE_SECTOR_SIZE;
        break;

    case 1:
        *(s32 *)&p->phase_size = FILE_SECTOR_SIZE;
        m = 0xFFDCFFFF;
        v_1 = D_8009B0F4;
        t = D_8009B118;
        v_1 &= m;
        D_8009B0F4 = v_1;
        p->value_0C = t;
        p->value_08 = t;
        p->done = 1;
        break;

    case 2:
        c = D_8009B118;
        p->x = 0x100;
        p->y = 0xF0;
        p->w = 0x100;
        p->h = 1;
        LoadImage2((RECT *)p, (u32 *G32)c);
        *(s32 *)&p->value_0C = (s32)D_801A8000;
        *(s32 *)&p->value_08 = (s32)D_801A8000;
        m = 0xFFDCFFFF;
        v_2 = D_8009B0F4;
        p->phase_size = 0x1000;
        v_2 &= m;
        D_8009B0F4 = v_2;
        p->done = 1;
        break;

    case 3:
        *(s32 *)&p->phase_size = CAMPAIGN_DIALOG_PORTRAIT_PHASE_SIZE;
        m = 0xFFDCFFFF;
        v_3 = D_8009B0F4;
        t = (s32)D_80010000;
        v_3 &= m;
        D_8009B0F4 = v_3;
        p->value_0C = t;
        p->value_08 = t;
        p->done = 1;
        break;
    }
}
