# GameShark codes — Yu-Gi-Oh! Forbidden Memories (SLUS-01411)

Every code I could find, with a one-line description each. Addresses were
checked against the retail executable; the **Notes** at the end say how, and
credit the people who wrote the codes.

Format is the standard PS1 one, `TTAAAAAA VVVV`, where the address is
`0x80000000 | AAAAAA`. A `50xxxxxx` line is a repeat directive for the line
after it; a `D0`/`C0` line is a condition guarding the line after it.

**Do not trust these blindly.** Unchiga hit incorrect Free Duel record codes
while building the rematch mod for the recomp, and two of the duelist codes
below are provably wrong — see that section.

---

## Life points

| code | what it does |
|---|---|
| `800EA004 270F` | player's LP fixed at 9999 |
| `800EA004 0000` | player's LP to zero |
| `800EA024 270F` | opponent's LP fixed at 9999 |
| `800EA024 0000` | opponent's LP to zero |

## Cards you own

| code | what it does |
|---|---|
| `301D0250 0063` … `301D0521 0063` | 99 copies of one card — 722 codes, one per card. Card *N* is at `0x801D0250 + (N-1)`, one byte each |
| `5000FF02 0000` / `801D0250 C8C8` / `50006A02 0000` / `80105F96 C8C8` | Published as 200 copies of every card at once (GameShark 2.2+), but the second destination is outside the trunk |
| `5000FF02 0000` / `801D0250 FAFA` / `50006A02 0000` / `80105F96 FAFA` | `Todas cartas 250 copias.jpg` makes the same off-target second write while changing each byte to 250 |
| `B1050002 0000` / `801D0250 C8C8` | 200-copy variant published for Caetla |
| `5000FF02 0000` / `801D0250 0505` / `50006A02 0000` / `801D044E 0505` | all 722 cards owned and marked seen in the Library |
| `50001202 0101` / `80105D98 0101` (+11 more pairs) | unlimited use of every card |

The first serial write in each "all cards" pair emits 255 halfword writes,
covering the first 510 trunk bytes at `0x801D0250-0x801D044D`. The remaining
212 bytes require 106 writes beginning at `0x801D044E`, as the owned-and-seen
code does. `0x80105F96` is outside the `0x801D0250-0x801D0521` trunk, so the
published 200-copy code and the 250-copy image cannot fill all 722 cards as
written. Replacing that destination with `0x801D044E` is the layout-derived
correction; it is not the address printed by either source.

## Starchips and passwords

| code | what it does |
|---|---|
| `801D07E0 423F` / `801D07E2 000F` | 999999 starchips — one 32-bit value written as two halves |
| `50005B01 0000` / `801D0698 0000` | passwords can be entered without limit |
| `D0038C60 3021` / `80038C60 000F` / `D0038C62 0080` / `80038C62 3406` | password entry costs no stars — **patches an instruction**, see below |
| `D016A87C 1823` / `8016A87E 2400` | buying cards does not subtract stars |
| `D016A882 1480` / `8016A882 2400` | bought cards arrive immediately at the password screen |
| `D016A6E0 0005` / `8016A6E0 A9BE` / `D016A6E2 1040` / `8016A6E2 0805` | no limit on re-buying a card you already own |

## Duelists

Each duelist has a 4-byte record: **wins** at the base, **losses** two bytes
later. Duelist IDs 1–39 occupy slots 1–39 of a 40-record grid table beginning
at `gFreeDuel_aDuelistRecords` (`0x801D071C`); their first record is at
`0x801D0720`.

The following table preserves the **published** addresses and labels for
comparison. It is not a corrected address list; the first rows and the
late-boss labels need the qualifications below.

| published wins / losses | duelist |
|---|---|
| `801D0720` / `801D0724` | Simon Muran |
| `801D0726` / `801D0728` | Teana |
| `801D072A` / `801D072C` | Jono |
| `801D072E` / `801D0730` | Villager 1 |
| `801D0732` / `801D0734` | Villager 2 |
| `801D0734` / `801D0736` | Villager 3 |
| `801D0738` / `801D073A` | Seto |
| `801D073C` / `801D073E` | Heishin |
| `801D0740` / `801D0742` | Rex Raptor |
| `801D0744` / `801D0746` | Weevil Underwood |
| `801D0748` / `801D074A` | Mai Valentine |
| `801D074C` / `801D074E` | Bandit Keith |
| `801D0750` / `801D0752` | Shadi |
| `801D0754` / `801D0756` | Yami Bakura |
| `801D0758` / `801D075A` | Pegasus |
| `801D075C` / `801D075E` | Isis |
| `801D0760` / `801D0762` | Kaiba |
| `801D0764` / `801D0766` | Mage Soldier |
| `801D0768` / `801D076A` | Juno 2nd |
| `801D076C` / `801D076E` | Teana 2nd |
| `801D0770` / `801D0772` | Ocean Mage |
| `801D0774` / `801D0776` | High Mage Secmeton |
| `801D0778` / `801D077A` | Forest Mage |
| `801D077C` / `801D077E` | High Mage Anubisus |
| `801D0780` / `801D0782` | Mountain Mage |
| `801D0784` / `801D0786` | High Mage Atenza |
| `801D0788` / `801D078A` | Desert Mage |
| `801D078C` / `801D078E` | High Mage Martis |
| `801D0790` / `801D0792` | Meadow Mage |
| `801D0794` / `801D0796` | High Mage Kepura |
| `801D0798` / `801D079A` | Labyrinth Mage |
| `801D079C` / `801D079E` | Seto 2nd |
| `801D07A0` / `801D07A2` | Guardian Sebek |
| `801D07A4` / `801D07A6` | Guardian Neku |
| `801D07A8` / `801D07AA` | Heishin 2nd |
| `801D07AC` / `801D07AE` | Seto 3rd |
| `801D07B0` / `801D07B2` | Nitemare |
| `801D07B4` / `801D07B6` | Darknite |
| `801D07B8` / `801D07BA` | Duel Master K |

The archive recommends `270F` at a wins address and `0000` at a losses
address.
The normal Free Duel update clamps each counter to 999 (`0x03E7`), so 9999 is
a cheat-forced value rather than the natural gameplay maximum. Incrementing
that counter from 9999 through the normal updater reduces it to 999.

**The earlier two-row correction was itself wrong.** Matching
[`FreeDuel_Init`](../../src/overlays/free_duel/screen_runtime.c) uses
`0x801D071C + 4 * (row * 5 + column)`, adding two bytes for a loss.
[`FreeDuel_UpdateScreen`](../../src/overlays/free_duel/screen_runtime.c) passes
that same grid index to the duel initializer, which stores it unchanged as
the opponent ID. Using the early ID/name mapping in the
[primary game description](the-game.md#64-the-dropped-card), the corrected
pairs are:

| Grid slot / ID | Listed duelist | Wins | Losses |
|---:|---|---|---|
| 1 | Simon Muran | `801D0720` | `801D0722` |
| 2 | Teana | `801D0724` | `801D0726` |
| 3 | Jono | `801D0728` | `801D072A` |
| 4 | Villager 1 | `801D072C` | `801D072E` |
| 5 | Villager 2 | `801D0730` | `801D0732` |
| 6 | Villager 3 | `801D0734` | `801D0736` |

Thus the first five published rows need correction; Villager 3's published
pair already fits. Moving it to `801D0736`/`801D0738`, as this note
previously advised, would instead select Villager 3's loss and slot 7's win.
The duelist records occupy `[0x801D0720, 0x801D07BC)` without gaps; slot 0
at `0x801D071C` is the non-duelist Build Deck tile.

The resident name-table comparison in the
[primary description](the-game.md#64-the-dropped-card) now resolves the
two boss labels too: global string `0x834D` names ID 37 `DarkNite`, while
`0x834E` names ID 38 `Nitemare`. Thus the corrected pairs are:

| In-game label | Wins | Losses |
|---|---|---|
| DarkNite | `801D07B0` | `801D07B2` |
| Nitemare | `801D07B4` | `801D07B6` |

The published table above is retained as evidence of the reversed labels.
No record-stride change or hidden grid-to-opponent remapping is needed.

| code | what it does |
|---|---|
| `801D06F4 FFFF` / `801D06F6 FFFF` | unlocks duelist IDs 1–31; IDs 32–38 remain locked, while Duel Master K (39) remains independently available |
| `D00E9E28 C000` / `D009B390 0100` / `8009B36C 0000` | Free Duel against glitched duelists for guaranteed drops — Select to enable, Triangle to leave |

## During a duel

| code | what it does |
|---|---|
| `801A7D1E 0000` | opponent never plays a card |
| `801A7D1E 8402` | opponent attacks repeatedly until you lose |
| `C009B168 9000` / `800FE068 0050` / `800FE06A 0000` | hold Up when placing a monster to put it on the opponent's field |
| `D009B390 0140` | Select+X on an opponent's monster takes control of it; O and move the cursor to exit |
| `801A7B72 270F` / `801A7B74 270F` | your first monster — ATK / DEF to 9999 |
| `801A7D16 270F` / `801A7D18 270F` | opponent's first monster — ATK / DEF to 9999 |
| `801A7D16 0000` / `801A7D18 0000` | opponent's first monster — ATK / DEF to zero |
| `801A7AE6 270F` / `801A7AE8 270F` | first card in your hand — ATK / DEF to 9999 |

Those are slots in a repeating record array. **The field and hands share
30 records at `0x801A7AD8`, 28 (`0x1C`) bytes each, with ATK at `+0xE` and
DEF at `+0x10`.** The player's ten field slots are records `5-14`, not
`0-9`; the opponent's are `20-29`. The hands use `0-4` and `15-19`.
The retail field map and matching hand reconstruction establish the
[full layout](the-game.md#51-setup).

The published codes above already agree with that layout: the first player
monster's ATK address is `base + 5 * 0x1C + 0xE = 0x801A7B72`, the first
opponent monster uses record 20, and the first player hand card uses record
0 (`0x801A7AE6`). Adjacent records remain 28 bytes apart. The code table is
unchanged; the earlier derived player-field range was wrong.

There are also 25 "slot machine" codes that cycle a card's ATK/DEF through
1000-step values. They are 32–145 lines each and all target these same
addresses.

## Presentation and debug

| code | what it does |
|---|---|
| `8009B062 0101` | skips the intro FMV — needed for many other codes to work |
| `80184594 000B` | opens the Debug Menu |
| `801E1B88 08B7` | no music |
| `80092AC8 CBB5` | slow motion |
| `800F284A 4468` | the 3D card viewer stops rotating |
| `D002C322 1040` / `8002C322 2400` | every card shows in the Library — **patches an instruction**, see below |
| `D0168188 023A` / `8016818A 1000` | enable code, version 1 (must be on) |
| `D0168100 000A` / `80168102 1000` | enable code, version 2 |
| `D01683D4 0002` / `801683D4 A0F8` / `D01683D6 1440` / `801683D6 0805` | all Free Duel opponents unlocked |

## The codes that patch instructions

Two of them write into the main executable, and those name functions.

**`D002C322 1040` / `8002C322 2400` — "all cards in library"** (hugopocked).
`0x8002C320` holds `beqz $v0, .L8002C358`, whose upper halfword is `0x1040`.
Writing `0x2400` makes the word `0x2400000D` — an `addiu $zero, $zero`, a
no-op. Exact matching C for the containing `func_8002BFCC` now shows the
complete loop: for each card ID it calls
`Campaign_TestStoryFlag(card_id + 0x120)`, increments the visible-card count,
and marks the card's display record when that flag is set. The patched branch
normally skips those writes when the flag is clear, so deleting it makes every
card visible for that Library initialization. It does not set the persistent
seen flags or change trunk quantities.

**`D0038C60 3021` / `80038C60 000F` / `D0038C62 0080` / `80038C62 3406` — "no
stars needed at the password screen"** (hugopocked). `0x80038C60` holds
`addu $a2, $a0, $zero`; the patch writes `ori $a2, $zero, 0xF`. Exact C now
shows that the containing function, **`Text_HandleChoiceCommand`
(`0x80038BF0`)**, handles the `FB` text control byte. `$a2` carries its
optional choice mask, whose low nibble is stored in
`gDialog_bChoiceEnabled` and tested by `Dialog_HighlightChoice`; forcing
`0xF` enables all four mask bits. This site does not carry or modify a
numeric starchip cost. Any password-screen effect of the published code is
therefore an indirect choice-enablement behavior, not a price change.

The overlay instruction patches need an identified runtime image, not just
an address in `0x8016xxxx`–`0x8018xxxx`. Several verified WA images reuse
`0x80168000`, while the main-menu image comes from **SU** at `0x80180000`;
the range does not identify one archive or module. The
[current module crosswalk](../overlays/module-crosswalk.md) records those
distinctions. Three patch codes verify against the password-shop phase, all
by hugopocked:

**`D016A87C 1823` / `8016A87E 2400` — "buying cards does not subtract
stars".** `0x8016A87C` holds `subu $v1, $v1, $s0`, the subtraction of the
card's star cost; the patch makes it `addiu $zero, $zero, 0x1823`, a no-op.

**`D016A882 1480` / `8016A882 2400` — "bought cards arrive immediately".**
`0x8016A880` holds `bnez $a0, +3`; the patch turns the branch into a no-op.

**`D016A6E0 0005` / `8016A6E0 A9BE` / `D016A6E2 1040` / `8016A6E2 0805` —
"no limit on re-buying a card you already own".** `0x8016A6E0` holds
`beqz $v0, +5`; the patch replaces it with `j 0x8016A6F8` and enters the
purchase path regardless of the password flag.

**`D01683D4 0002` / `801683D4 A0F8` / `D01683D6 1440` / `801683D6 0805` —
"all Free Duel opponents unlocked".** Verified against the Free Duel overlay,
also on the disc (`docs/DISC.txt` in `MaChInEgUn3/ygofm-decomp`). `0x801683D4` holds `bnez $v0, +2`, the
branch in the loop that clears a grid entry whose unlock flag is off; the
patch makes it `j 0x801683E0`, skipping the clear, so every entry stays
available. Related: the plain-data code `801D06F4 FFFF` / `801D06F6 FFFF`
writes four bytes of the flag array, which hold the flags of duelists 1–31;
duelists 32–38 sit in the next byte, `0x801D06F8`. A controlled runtime trace
confirmed that split: the four-byte write exposed ids 1–31, left ids 32–38
unavailable, and did not affect the independently available Duel Master K
entry at id 39.

### Located enable-code guards

The two "enable" codes test `u16[0x80168188] == 0x023A` and
`u16[0x80168100] == 0x000A`, respectively. **Both occur in the same retail
WA startup phase**, not in the configured Free Duel or password images.
The old "neither located overlay" assessment missed this separately
documented load.

Matching `Main_RunBootSequence` requests WA sector `0x1690` for `0x36`
sectors. Its callback, `Main_LoadBootPackageStage`, consumes
`0x18000 + 0x1000 + 0x800` bytes
before copying the final `0x1800` bytes to the address held at
`D_800101D8`, whose resident value is `0x80168000`. The resulting phase is
WA sectors `[5827, 5830)`, archive bytes `[0xB61800, 0xB63000)`, loaded at
`0x80168000..0x80169800`. In its mode-zero path, the caller enters this
image at `0x801680F4` and polls `0x80168160`.

The phase contains the retail "SOFTWARE TERMINATED / CONSOLE MAY HAVE BEEN
MODIFIED" warning and its phone number. This confirms that the guarded image
is the boot compliance module, not a Free Duel or password overlay.

The static, little-endian guard comparison against the verified archive
slices is:

| Image or variant | `u16[0x80168188]` | `u16[0x80168100]` |
|---|---:|---:|
| Expected by the published guards | `0x023A` | `0x000A` |
| WA startup phase `[5827, 5830)` | **`0x023A`** | **`0x000A`** |
| Free Duel | `0x00CC` | `0x800A` |
| Password and the name-entry variant | `0xE685` | `0x0010` |
| Both overworld variants | `0x0048` | `0x0004` |
| SU main menu | outside the image | outside the image |

The configured images and hashes are pinned in
[`overlays.json`](../../config/slus_01411/overlays.json). The additional
startup phase is pinned in the
[loader evidence](../overlays/runtime-loader.md#startup-phase-and-enable-code-sites);
the name-entry phase at sectors `[7968, 7983)` is documented in its
[shared-image note](../../src/overlays/name_entry/README.md).
The comparison reads little-endian halfwords at `address - load_address`,
not at a raw disc offset. As positive controls, the same mapping recovers
Free Duel word `0x14400002` at `0x801683D4` and password word `0x00701823`
at `0x8016A87C`, the known patch sites above.

The full words establish the immediate effect of the published writes:

| Published label | Guarded RAM word | Original instruction | Word after the high-halfword write |
|---|---|---|---|
| Enable, version 1 | `0x80168188`: `0x1040023A` | `beq $v0, $zero, 0x80168A74` | `0x1000023A`: unconditional branch to the same target |
| Enable, version 2 | `0x80168100`: `0x1062000A` | `beq $v1, $v0, 0x8016812C` | `0x1000000A`: unconditional branch to the same target |

Version 2 writes the high halfword at `0x80168102`, corresponding to WA
offset `0xB61902`. It is the **same byte change** as the branch alteration
documented in the repository's
[anti-piracy-patched archive comparison](../overlays/README.md#the-anti-piracy-patched-dump-does-not-affect-these-modules).
The labels "version 1" and "version 2" therefore do not require different
retail images to find matching sites.

Neither guard matches the four configured WA images or the name-entry
variant, and the SU main-menu image does not cover these addresses. Those
negative controls explain why checking only the configured module catalog
left the codes unplaced. The startup image now supplies both sites, but
their full gameplay purpose and the need for each published enable code
remain unverified. No patched game or emulator trace was used here.

## From other sources

Found outside the main archives, so worth less confidence:

| code | what it does | where |
|---|---|---|
| `8009B364 00??` | field terrain — 00 normal, 01 forest, 02 wasteland, 03 mountain, 04 meadow, 05 sea, 06 dark | NightMare185, a 2002 GeoCities page |
| `300EA02D 0002` | opponent spams one card and draws badly | Legend of Dark, neoseeker 2012 |
| `D00EF6CA ????` | "reverse joker command" | almarsguides' Action Replay page |

**These I would not trust at all yet.** Posted to the gamehacking forum in 2013
by "Duncan Idaho", who says himself that they crash the game, and six of them
write 16-bit values to odd addresses:

```
Trigger Trap:        800F1C01 0020 / 800E9FF6 0020 / 801D5678 0020
Cards used by CPU:   800EA00E 0028 / 800EA028 0028 / 80103F00 0028
                     801060B7 0028 / 801AB491 0028 / 801D560C 0028
Cards used by you:   800EA008 0023 / 801060F6 0023 / 801AB3F5 0023
                     801AB449 0023 / 801AB49D 0023 / 801D5608 0023
```

---

## Notes

**Layout facts these codes establish.** Beyond the card array above: the trunk
is 722 one-byte entries from `0x801D0250` — sources publishing only 250 give
the wrong count; the Library's seen state is the separate save flag
`0x120 + card`, tested by `func_8002BFCC`; life points are a per-side record
at stride `0x20`. `Library_MarkOwnedCards` derives seen flags from owned and
deck cards when the screen starts, but the visibility loop itself reads the
flag array rather than a bit in the trunk quantity byte.

**How the checking worked.** Every `D0`/`C0`-family line states what a value
already is, so it can be compared against `SLUS_014.11`. That is conclusive
only on a **code** address, where the halfword is an instruction that never
changes — a mismatch there proves the code was written for a different build.
On a **data** address the file holds only the power-on value, so a mismatch
means nothing. Three code guards checked out, none failed, and a deliberately
wrong guard does fail, so the check is real rather than decorative.

Nobody here ran a patched binary, so what a code *does* remains its author's
claim. What was verified is the address and the instruction.

**Sources.** gamehacking.org (70 code groups plus its separate master-codes
table), almarsguides.com (its GameShark *and* Action Replay pages — they differ),
kodewerx, neoseeker, a 2002 GeoCities page, and a 2013 gamehacking forum
thread. The issue #368 tutorial set supplied `Todas cartas 250 copias.jpg`.
cheatcc and gamefaqs are Cloudflare-blocked. `ps2-home.com` thread 8745 is
titled "[GAME FIX CODES] SLUS_014.11" and is the one source I could not read —
by its title it is patch codes, which is the most valuable class here, so it is
worth another attempt.

**Credit.** The codes are the work of **Police NYPD**, **roughnight**,
**hugopocked**, **StalkerX**, **00Kevin**, **Mantidactyle**, **M1CR0H4CK3R**,
**NightMare185** and **Legend of Dark** — those are the handles the archives
credit each code to. This decodes and cites their work; it does not
redistribute the archives.
