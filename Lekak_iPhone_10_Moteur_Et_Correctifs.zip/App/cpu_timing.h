#ifndef LEKAK_CPU_TIMING_H
#define LEKAK_CPU_TIMING_H
#include <stdint.h>
/* Functional data-load stall model: main RAM reads take an opcode cycle plus
 * six waitstates. No instruction-cache refill, write queue, MMIO waitstates,
 * GTE latency or DMA bus arbitration model. Do not claim cycle accuracy.
 * Ref: psx-spx, DMA Channels / DRAM Hyper Page mode. */
static inline unsigned LekakCpu_LoadWait(uint32_t instruction,uint32_t address){
 unsigned op=instruction>>26;
 if(!((op>=0x20&&op<=0x26)||op==0x32))return 0;
 return (address&0x1fffffffu)<0x200000u?6:0;
}
#endif
