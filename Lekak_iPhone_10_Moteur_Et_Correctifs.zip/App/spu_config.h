#ifndef LEKAK_SPU_CONFIG_H
#define LEKAK_SPU_CONFIG_H
#include <stdint.h>
#include "spu_dsp.h"
/* Selected configuration and bounded manual RAM writes; ADPCM/ADSR voices; functional reverb; bounded DMA adapter; no speaker output.
 * A nominal 44.1kHz boundary applies direct main gain/current mode. Master/CD
 * configuration is distinct from current main gain; no invented ready DMA. */
typedef struct LekakSpuConfig {
 uint16_t main_gain[2],current_gain[2],cd_gain[2],external_gain[2],control,status;
 uint32_t phase,reads,writes,ticks;
 uint16_t ram_control,transfer_start,fifo[32],reverb_gain[2],reverb_start,irq_address;
 uint32_t transfer_address,fifo_count,manual_halfwords;
 uint8_t ram[0x80000];
 LekakSpuDsp dsp;
 uint16_t voice[24][8],key_off[2],disabled_flags[6];
} LekakSpuConfig;
static inline int LekakSpu_Address(uint32_t a){a&=0x1fffffffu;return a>=0x1f801c00u&&a<=0x1f801e7fu;}
static inline void LekakSpu_Cycle(LekakSpuConfig *s){
 if(++s->phase<768)return;
 s->phase=0;s->ticks++;s->dsp.ram=s->ram;
 s->dsp.reverb_enabled=!!(s->control&0x80u);
 s->dsp.cd_enabled=!!(s->control&1u);
 s->dsp.cd_gain[0]=(int16_t)s->cd_gain[0];s->dsp.cd_gain[1]=(int16_t)s->cd_gain[1];
 if(s->control&0x8000u){
  const uint16_t muted[2]={0,0};LekakSpuDsp_Frame(&s->dsp,(s->control&0x4000u)?s->main_gain:muted);
 }
 for(unsigned i=0;i<2;i++)s->current_gain[i]=(uint16_t)(s->main_gain[i]<<1);
 s->status=s->control&0x3fu;
 if((s->status&0x30u)==0x20u)s->status|=0x180u;
 if((s->status&0x30u)==0x30u)s->status|=0x280u;
 /* Functional bounded transfer at a sample boundary, not bus-cycle accurate.
  * Retire actual FIFO contents before reporting ready; wrap in 512 KiB RAM. */
 if((s->control&0x30u)==0x10u&&s->fifo_count){
  for(unsigned i=0;i<s->fifo_count;i++){
   s->ram[s->transfer_address]=(uint8_t)s->fifo[i];
   s->ram[(s->transfer_address+1)&0x7ffffu]=(uint8_t)(s->fifo[i]>>8);
   s->transfer_address=(s->transfer_address+2)&0x7ffffu;
  }
  s->manual_halfwords+=s->fifo_count;s->fifo_count=0;
 }
}
/* Return 0 for outside device, -1 for unsupported width/register/mode.
 * Output and state remain unchanged on rejection. No sweep silently accepted. */
static inline int LekakSpu_Read(LekakSpuConfig *s,uint32_t a,unsigned width,uint32_t *out){
 if(!LekakSpu_Address(a))return 0;
 a&=0x1fffffffu;if(width!=2||(a&1u))return -1;
 uint16_t v;
 if(a>=0x1f801dc0u&&a<=0x1f801dfeu){*out=s->dsp.reverb.registers[(a-0x1f801dc0u)/2];s->reads++;return 1;}
 if(a<0x1f801d80u){
  unsigned n=(a-0x1f801c00u)/16,reg=((a-0x1f801c00u)&15)/2;
  *out=reg==6?(uint16_t)s->dsp.voices[n].level:s->voice[n][reg];s->reads++;return 1;
 }
 switch(a){
 case 0x1f801d80:case 0x1f801d82:v=s->main_gain[(a-0x1f801d80)/2];break;
 case 0x1f801db0:case 0x1f801db2:v=s->cd_gain[(a-0x1f801db0)/2];break;
 case 0x1f801db4:case 0x1f801db6:v=s->external_gain[(a-0x1f801db4)/2];break;
 case 0x1f801db8:case 0x1f801dba:v=s->current_gain[(a-0x1f801db8)/2];break;
 case 0x1f801d98:case 0x1f801d9a:v=(uint16_t)(s->dsp.reverb.voice_mask>>((a-0x1f801d98)*8));break;
 case 0x1f801d9c:case 0x1f801d9e:v=(uint16_t)(s->dsp.end_mask>>((a-0x1f801d9c)*8));break;
 case 0x1f801d84:case 0x1f801d86:v=s->reverb_gain[(a-0x1f801d84)/2];break;
 case 0x1f801da2:v=s->reverb_start;break;
 case 0x1f801da4:v=s->irq_address;break;
 case 0x1f801dac:v=s->ram_control;break;
 case 0x1f801da6:v=s->transfer_start;break;
 case 0x1f801daa:v=s->control;break;
 case 0x1f801dae:v=s->status;break;
 default:return -1;
 }
 *out=v;s->reads++;return 1;
}
static inline int LekakSpu_Write(LekakSpuConfig *s,uint32_t a,unsigned width,uint32_t value){
 if(!LekakSpu_Address(a))return 0;
 a&=0x1fffffffu;if(width!=2||(a&1u)||value>0xffffu)return -1;
 uint16_t v=(uint16_t)value;
 if(a>=0x1f801dc0u&&a<=0x1f801dfeu){s->dsp.reverb.registers[(a-0x1f801dc0u)/2]=v;s->writes++;return 1;}
 if(a==0x1f801d98u||a==0x1f801d9au){
  unsigned shift=(a-0x1f801d98u)*8;uint32_t mask=shift?255u:65535u;
  s->dsp.reverb.voice_mask=(s->dsp.reverb.voice_mask&~(mask<<shift))|(((uint32_t)v&mask)<<shift);s->writes++;return 1;
 }
 if(a<0x1f801d80u){
  unsigned reg=((a-0x1f801c00u)&15)/2;
  if(reg<2&&(v&0x8000u))return -1;
  unsigned n=(a-0x1f801c00u)/16;Voice *p=&s->dsp.voices[n];
  s->voice[n][reg]=v;
  switch(reg){case 0:p->left=(int16_t)v;break;case 1:p->right=(int16_t)v;break;
   case 2:p->pitch=(v&0x3fff);break;case 3:p->start=(uint32_t)v*8;break;
   case 4:p->adsr1=v;break;case 5:p->adsr2=v;break;
   case 6:p->level=(int16_t)v;break;case 7:p->loop=(uint32_t)v*8;p->loop_set=1;break;}
  s->writes++;return 1;
 }
 if(a>=0x1f801d90u&&a<=0x1f801d9au){
  /* Store disabled pitch modulation/noise/reverb configuration only. */
  if(v)return -1;
  s->disabled_flags[(a-0x1f801d90u)/2]=v;s->writes++;return 1;
 }
 switch(a){
 case 0x1f801d88:case 0x1f801d8a:
  LekakSpuDsp_Key(&s->dsp,(uint32_t)(a==0x1f801d8a?v&255:v)<<((a-0x1f801d88)*8),1);
  break;
 case 0x1f801d8c:case 0x1f801d8e:
  s->key_off[(a-0x1f801d8c)/2]=v;
  LekakSpuDsp_Key(&s->dsp,(uint32_t)(a==0x1f801d8e?v&255:v)<<((a-0x1f801d8c)*8),0);break;
 case 0x1f801d80:case 0x1f801d82:
  if(v&0x8000u)return -1;
  s->main_gain[(a-0x1f801d80)/2]=v;break;
 case 0x1f801db0:case 0x1f801db2:s->cd_gain[(a-0x1f801db0)/2]=v;break;
 case 0x1f801db4:case 0x1f801db6:s->external_gain[(a-0x1f801db4)/2]=v;break;
 case 0x1f801d84:case 0x1f801d86:s->reverb_gain[(a-0x1f801d84)/2]=v;s->dsp.reverb.gain[(a-0x1f801d84)/2]=v;break;
 case 0x1f801da2:s->reverb_start=v;s->dsp.reverb.base=s->dsp.reverb.current=(uint32_t)v*8;break;
 case 0x1f801da4:s->irq_address=v;break;
 case 0x1f801dac:
  if(v!=4||s->fifo_count)return -1;
  s->ram_control=v;break;
 case 0x1f801da6:
  if(s->ram_control!=4||s->fifo_count||(s->status&0x30u)||(s->control&0x30u))return -1;
  s->transfer_start=v;s->transfer_address=(uint32_t)v*8;break;
 case 0x1f801da8:
  if(s->ram_control!=4||s->fifo_count==32||(s->control&0x30u)>0x10u)return -1;
  s->fifo[s->fifo_count++]=v;
  if((s->status&0x30u)==0x10u)s->status|=0x400u;
  break;
 case 0x1f801daa:
  /* Stop/manual-write or functional DMA modes. Noise/external or CD reverb/IRQ remain explicit stops. */
  if(v&~0xc0b3u)return -1;
  if((v&0x30u)&&s->ram_control!=4)return -1;
  s->control=v;break;
 default:return -1;
 }
 s->writes++;return 1;
}
#endif
