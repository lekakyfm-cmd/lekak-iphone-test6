/* Voice decoder, ADSR and Gaussian interpolation adapted from upstream MIT
 * src/pc/audio/spu.c at 0d78202729967a5bbdbc886aa128e48e82bef7ac.
 * Private state, no platform hooks, CD ring, replacement audio or global state.
 * No noise/IRQ/capture/sweeps. Functional reverb, no hardware FIR. Output retained for diagnostics, no speaker. */
#include "spu_dsp.h"
#include "spu_gauss.h"
enum { OFF, ATTACK, DECAY, SUSTAIN, RELEASE };
static void decode_block(LekakSpuDsp *s, Voice *voice, unsigned v)
{
    static const int k0[5] = {0, 60, 115, 98, 122}, k1[5] = {0, 0, -52, -55, -60};
    uint8_t block[16];
    for(unsigned i=0;i<16;i++)block[i]=s->ram[(voice->address+i)&0x7ffffu];
    const uint8_t *data=block;
    int shift = data[0] & 15, filter = (data[0] >> 4) > 4 ? 4 : data[0] >> 4, flags = data[1], i;
    if (shift > 12) {
        shift = 9;
    }
    if ((flags & 4) && !voice->loop_set) {
        voice->loop = voice->address;
    }
    voice->block[0] = voice->block[28];
    voice->block[1] = voice->block[29];
    voice->block[2] = voice->block[30];
    for (i = 0; i < 28; i++) {
        int nibble = (data[2 + i / 2] >> ((i & 1) * 4)) & 15;
        int sample = ((int16_t)(nibble << 12) >> shift) +
                     ((voice->history[0] * k0[filter] + voice->history[1] * k1[filter] + 32) >> 6);
        sample = sample < -32768 ? -32768 : sample > 32767 ? 32767 : sample;
        voice->history[1] = voice->history[0];
        voice->history[0] = (int16_t)sample;
        voice->block[3 + i] = (int16_t)sample;
    }
    voice->address = (voice->address + 16) & (0x7ffffu);
    if (flags & 1) {
        s->end_mask |= 1u << v;
        voice->address = voice->loop;
        voice->stop = !(flags & 2);
    }
}

static void envelope(Voice *voice)
{
    int rate, exponential, decreasing, shift, step, cycles;
    switch (voice->phase) {
    case ATTACK: rate = (voice->adsr1 >> 8) & 0x7f; exponential = voice->adsr1 >> 15; decreasing = 0; break;
    case DECAY: rate = ((voice->adsr1 >> 4) & 15) * 4; exponential = 1; decreasing = 1; break;
    case SUSTAIN: rate = (voice->adsr2 >> 6) & 0x7f; exponential = voice->adsr2 >> 15; decreasing = (voice->adsr2 >> 14) & 1; break;
    case RELEASE: rate = (voice->adsr2 & 31) * 4; exponential = (voice->adsr2 >> 5) & 1; decreasing = 1; break;
    default: return;
    }
    if (--voice->wait > 0) {
        return;
    }
    shift = rate >> 2;
    step = decreasing ? -8 + (rate & 3) : 7 - (rate & 3);
    cycles = 1 << (shift > 11 ? shift - 11 : 0);
    step *= 1 << (shift < 11 ? 11 - shift : 0);
    if (exponential && !decreasing && voice->level > 0x6000) {
        cycles *= 4;
    }
    if (exponential && decreasing) {
        step = (step * voice->level) >> 15;
    }
    voice->wait = cycles;
    voice->level += step;
    if (voice->level < 0) {
        voice->level = 0;
    }
    if (voice->phase == ATTACK && voice->level >= 0x7fff) {
        voice->level = 0x7fff;
        voice->phase = DECAY;
        voice->wait = 0;
    } else if (voice->phase == DECAY && voice->level <= (((voice->adsr1 & 15) + 1) * 0x800)) {
        voice->phase = SUSTAIN;
        voice->wait = 0;
    } else if (voice->phase == RELEASE && voice->level == 0) {
        voice->phase = OFF;
    }
    if (voice->level > 0x7fff) {
        voice->level = 0x7fff;
    }
}


void LekakSpuDsp_Key(LekakSpuDsp *s,uint32_t mask,int on){
 for(unsigned v=0;v<24;v++)if(mask&(1u<<v)){
  Voice *p=&s->voices[v];
  if(!on){if(p->phase!=OFF){p->phase=RELEASE;p->wait=0;}p->keyed=0;continue;}
  p->address=p->start;p->counter=0;p->position=28;
  p->history[0]=p->history[1]=0;p->block[28]=p->block[29]=p->block[30]=0;
  p->level=0;p->wait=0;p->stop=0;p->phase=ATTACK;p->keyed=1;
  s->end_mask&=~(1u<<v);
 }
}
void LekakSpuDsp_Frame(LekakSpuDsp *s,const uint16_t *master){
 int32_t left=0,right=0,wet_left=0,wet_right=0;
 for(unsigned v=0;v<24;v++){
  Voice *p=&s->voices[v];if(p->phase==OFF)continue;
  while(p->position>=28){
   if(p->stop){p->phase=OFF;p->level=0;break;}
   decode_block(s,p,v);p->position-=28;
  }
  if(p->phase==OFF)continue;
  int f=(p->counter>>4)&255;const int16_t *t=&p->block[p->position];
  int sample=(Spu_Gauss[255-f]*t[0]+Spu_Gauss[511-f]*t[1]+Spu_Gauss[256+f]*t[2]+Spu_Gauss[f]*t[3])>>15;
  p->counter+=p->pitch;p->position+=(int)(p->counter>>12);p->counter&=4095;
  envelope(p);sample=(sample*p->level)>>15;
  int vl=(sample*(int16_t)((uint16_t)p->left<<1))>>15;
  int vr=(sample*(int16_t)((uint16_t)p->right<<1))>>15;
  left+=vl;right+=vr;
  if(s->reverb.voice_mask&(1u<<v)){wet_left+=vl;wet_right+=vr;}
 }
 if(++s->reverb.phase==2){
  s->reverb.phase=0;LekakSpuReverb_Step(&s->reverb,s->ram,wet_left,wet_right,s->reverb_enabled);
 }
 left+=s->reverb.output[0];right+=s->reverb.output[1];
 if(s->cd_enabled){left+=(s->cd_input[0]*(int32_t)s->cd_gain[0])>>15;right+=(s->cd_input[1]*(int32_t)s->cd_gain[1])>>15;}
 left=(int32_t)(((int64_t)left*(int16_t)(master[0]<<1))>>15);
 right=(int32_t)(((int64_t)right*(int16_t)(master[1]<<1))>>15);
 s->last[0]=(int16_t)(left<-32768?-32768:left>32767?32767:left);
 s->last[1]=(int16_t)(right<-32768?-32768:right>32767?32767:right);
 if(!s->frames)s->pcm_hash=2166136261u;
 s->frames++;if(s->last[0]||s->last[1])s->nonzero_frames++;
 for(unsigned i=0;i<2;i++){uint16_t x=(uint16_t)s->last[i];s->pcm_hash=(s->pcm_hash^(x&255))*16777619u;s->pcm_hash=(s->pcm_hash^(x>>8))*16777619u;}
}
