#ifndef LEKAK_PAD_DRIVER_H
#define LEKAK_PAD_DRIVER_H
#include "pc/memory.h"
#include <string.h>
/* Functional BIOS digital-pad worker, not serial hardware. Connections and
 * buttons are explicit virtual inputs. Default inputs are disconnected. */
typedef struct LekakPadDriver {
 uint32_t buffers[2],polls,initializations;
 uint16_t pressed[2];
 uint16_t scheduled[2];
 uint32_t press_frame,release_frame,repeat_frames;
 int initialized,started,connected[2];
} LekakPadDriver;
static inline void LekakPad_InputAt(LekakPadDriver *p,uint32_t frame){
 if(!p->press_frame)return;
 int held=frame>=p->press_frame&&(!p->release_frame||frame<p->release_frame);
 if(p->repeat_frames&&frame>=p->press_frame&&p->release_frame>p->press_frame)held=(frame-p->press_frame)%p->repeat_frames<p->release_frame-p->press_frame;
 for(unsigned i=0;i<2;i++)p->pressed[i]=held?p->scheduled[i]:0;
}
static inline int LekakPad_Init(LekakPadDriver *p,MemoriesMemory *m,uint32_t a,uint32_t n,uint32_t b,uint32_t k){
 /* Restrict this adapter to the documented standard allocation. */
 if(n!=0x22||k!=0x22)return 0;
 void *first=Memories_Resolve(m,a,n,1),*second=Memories_Resolve(m,b,k,1);
 if(!first||!second)return 0;
 memset(first,0,n);memset(second,0,k);
 p->buffers[0]=a;p->buffers[1]=b;p->initialized=1;p->started=0;p->initializations++;return 1;
}
static inline int LekakPad_Poll(LekakPadDriver *p,MemoriesMemory *m,int enabled){
 if(!p->started||!enabled)return 1;
 uint8_t *b[2];for(unsigned i=0;i<2;i++){b[i]=Memories_Resolve(m,p->buffers[i],0x22,1);if(!b[i])return 0;}
 for(unsigned i=0;i<2;i++){
  b[i][0]=p->connected[i]?0:0xff;
  if(p->connected[i]){uint16_t released=(uint16_t)~p->pressed[i];b[i][1]=0x41;b[i][2]=(uint8_t)released;b[i][3]=(uint8_t)(released>>8);}
 }
 p->polls++;return 1;
}
#endif
