#ifndef LEKAK_RULES_H
#define LEKAK_RULES_H
#include <stdint.h>
/* Read-only snapshot supplied by the future game/save adapter. Values must be
 * from one save slot. No process-wide unlocked state is cached here. */
typedef struct {
 void *context;
 uint64_t total_wins;
 unsigned distinct_seen;
 uint64_t (*wins)(void *, const char *identity);
 int (*unlocked)(void *, const char *identity);
 int (*seen)(void *, const char *identity);
 unsigned (*owned)(void *, const char *identity);
} LekakProgressSnapshot;
const char *LekakRules_Duelist(unsigned index);
int LekakRules_Ready(unsigned index, const LekakProgressSnapshot *snapshot);
uint32_t LekakRules_Price(int attack, int monster);
/* 0 means the existing game colour; other values are 0xRRGGBB. */
uint32_t LekakRules_NameRGB(int attack, int monster);
#endif
