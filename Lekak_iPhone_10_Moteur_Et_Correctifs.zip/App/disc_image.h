#ifndef LEKAK_DISC_IMAGE_H
#define LEKAK_DISC_IMAGE_H
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <limits.h>
/* Borrowed validated single data-track image. Caller owns FILE and must keep
 * its coordinated/security-scoped access alive through execution. */
typedef struct LekakDiscImage { FILE *file; uint32_t stride,sectors,reads; } LekakDiscImage;
static inline int LekakDiscImage_Init(LekakDiscImage *d,FILE *f,uint32_t stride){
 if(!d||!f||(stride!=2048&&stride!=2352))return 0;
 long saved=ftell(f);if(saved<0||fseek(f,0,SEEK_END))return 0;
 long length=ftell(f);int restored=fseek(f,saved,SEEK_SET)==0;
 if(!restored||length<=0||length%stride||(unsigned long)length/stride>UINT32_MAX)return 0;
 *d=(LekakDiscImage){f,stride,(uint32_t)((unsigned long)length/stride),0};return 1;
}
/* Selected decoder sector size: 2048 payload or 2340 bytes starting at the
 * raw Mode2 header. ISO has no raw header/ECC bytes: never synthesize these. */
static inline int LekakDiscImage_ReadData(LekakDiscImage *d,uint32_t lba,uint8_t *out,unsigned size){
 if(!d||!d->file||!out||(d->stride!=2048&&d->stride!=2352)||lba>=d->sectors||(size!=2048&&size!=2340))return 0;
 if(size==2340&&d->stride!=2352)return 0;
 uint64_t offset=(uint64_t)lba*d->stride;
 uint8_t raw[2352];if(offset>LONG_MAX||fseek(d->file,(long)offset,SEEK_SET)||fread(raw,1,d->stride,d->file)!=d->stride)return 0;
 unsigned skip=0;
 if(d->stride==2352){if(raw[15]!=2||((raw[18]&0x20)&&size!=2340)||memcmp(raw+16,raw+20,4))return 0;skip=size==2340?12:24;}
 memcpy(out,raw+skip,size);d->reads++;return 1;
}
static inline int LekakDiscImage_Read(LekakDiscImage *d,uint32_t lba,uint8_t out[2048]){
 return LekakDiscImage_ReadData(d,lba,out,2048);
}
#endif
