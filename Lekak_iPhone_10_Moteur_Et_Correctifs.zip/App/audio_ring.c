#include "audio_ring.h"
void LekakAudioRing_Init(LekakAudioRing *r){
 atomic_init(&r->write_position,0);atomic_init(&r->read_position,0);atomic_init(&r->dropped,0);
}
int LekakAudioRing_Push(LekakAudioRing *r,int16_t l,int16_t right){
 unsigned w=atomic_load_explicit(&r->write_position,memory_order_relaxed);
 unsigned at=atomic_load_explicit(&r->read_position,memory_order_acquire);
 if(w-at>=LEKAK_AUDIO_CAPACITY){atomic_fetch_add_explicit(&r->dropped,1,memory_order_relaxed);return 0;}
 r->frames[w&(LEKAK_AUDIO_CAPACITY-1)][0]=l;r->frames[w&(LEKAK_AUDIO_CAPACITY-1)][1]=right;
 atomic_store_explicit(&r->write_position,w+1,memory_order_release);return 1;
}
int LekakAudioRing_Pop(LekakAudioRing *r,int16_t out[2]){
 unsigned at=atomic_load_explicit(&r->read_position,memory_order_relaxed);
 unsigned w=atomic_load_explicit(&r->write_position,memory_order_acquire);
 if(at==w){out[0]=out[1]=0;return 0;}
 out[0]=r->frames[at&(LEKAK_AUDIO_CAPACITY-1)][0];out[1]=r->frames[at&(LEKAK_AUDIO_CAPACITY-1)][1];
 atomic_store_explicit(&r->read_position,at+1,memory_order_release);return 1;
}
void LekakAudioRing_Sink(void *context,int16_t l,int16_t r){LekakAudioRing_Push(context,l,r);}
