#ifndef LEKAK_JOY_CONTROL_H
#define LEKAK_JOY_CONTROL_H
#include <stdint.h>
/* Only the disabled JOY_CTRL configuration is supported. Serial TX/RX,
 * ACK interrupts, reset timing and bus transactions are not implemented.
 * The game IRQ callback writes zero to deselect/disable the port. */
typedef struct LekakJoyControl { uint32_t reads,writes; } LekakJoyControl;
static inline int LekakJoy_Read(LekakJoyControl *j,uint32_t a,unsigned width,uint32_t *v){
 if((a&0x1fffffffu)!=0x1f80104au||width!=2)return 0;
 j->reads++;*v=0;return 1;
}
static inline int LekakJoy_Write(LekakJoyControl *j,uint32_t a,unsigned width,uint32_t v){
 if((a&0x1fffffffu)!=0x1f80104au||width!=2)return 0;
 if(v)return -1;
 j->writes++;return 1;
}
#endif
