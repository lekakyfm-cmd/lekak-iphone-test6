#ifndef LEKAK_GUEST_EXEC_H
#define LEKAK_GUEST_EXEC_H
#include "pc/memory.h"
#include "disc_image.h"
#define LEKAK_EXEC_TRACE 24
#define LEKAK_EXEC_CONSOLE 4096
#define LEKAK_EXEC_RETURN 0xFFFFFFFCu
/* Owned by this software kernel, below the EXE load range. This is not a
 * claim about the retail BIOS's private addresses. */
#define LEKAK_DEFAULT_IRQ_CONTEXT 0x80000400u
#define LEKAK_EXCEPTION_RETURN 0xFFFFFFF8u
#define LEKAK_PAD_ENABLE_FN 0xFFFFFFECu
#define LEKAK_PAD_DISABLE_FN 0xFFFFFFE8u
#define LEKAK_CHAIN_FIRST_RETURN 0xFFFFFFE4u
#define LEKAK_CHAIN_SECOND_RETURN 0xFFFFFFE0u
#define LEKAK_CARD_IRQ_TAIL 0xFFFFFFDCu
typedef struct LekakExecResult {
    uint64_t total_steps;
    uint32_t steps, pc, instruction, detail, registers[32];
    uint32_t trace_pc[LEKAK_EXEC_TRACE], trace_ins[LEKAK_EXEC_TRACE], trace_count;
    int returned;
    uint32_t critical_enters, critical_exits;
    uint32_t irq_status, irq_mask, irq_reads, irq_writes;
    uint32_t dma_control,dma_interrupt,bios_calls,interrupt_hook;
    uint32_t timer_reads,timer_writes,interrupt_chains[4];
    uint32_t cd_driver_removals;
    uint32_t spu_reads,spu_writes,spu_ticks,spu_control,spu_status;
    uint32_t spu_manual_halfwords,spu_frames,spu_nonzero_frames,spu_pcm_hash;
    uint32_t spu_dma_transfers,spu_dma_words,bios_event_callbacks;
    uint16_t spu_main_gain[2],spu_current_gain[2],spu_cd_gain[2];
    uint32_t cd_streaming,cd_decoded_ready,cd_fifo_size,cd_fifo_pos,cd_last_command;
    uint32_t cd_sectors_decoded,cd_data_irqs,cd_data_bytes,cd_next_lba,cd_dma_transfers,cd_dma_words;
    uint32_t cd_reads,cd_writes,cd_commands,cd_acks,cd_completions,cd_flags,cd_enable;
    int cd_iso_driver_registered;
    uint32_t memory_megabytes;
    uint32_t gpu_status,gp0_commands,gp1_commands,gpu_reads;
    uint32_t gpu_display_start,gpu_display_horizontal,gpu_display_vertical;
    uint64_t nominal_cycles;
    uint32_t video_lines,video_frames,hblank_edges,vblank_edges,timer_counts[3],timer_irq_events[3];
    uint32_t irq_entries,irq_returns;
    uint32_t gpu_dma_transfers,gpu_dma_words;
    uint32_t native_boot_check_calls;
    uint32_t mdec_dma_transfers[2],mdec_dma_words[2],mdec_status,mdec_commands,mdec_macroblocks;
    uint32_t xa_audio_sectors,xa_audio_frames,xa_audio_consumed,xa_audio_queued;
    uint32_t bios_cause_patches;
    uint32_t bios_pad_ack_patches,cp0_sr,cp0_sr_reads,cp0_sr_writes;
    uint32_t otc_dma_transfers,otc_dma_words;
    int pad_ack_patch_enabled;
    uint32_t bios_pad_error_patches,pad_poll_callbacks;
    int pad_poll_enabled,pad_error_patch_enabled;
    uint32_t pad_buffers[2],pad_initializations,pad_polls,irq_chain_calls;
    int pad_initialized,pad_started;
    uint32_t joy_control_reads,joy_control_writes;
    int card_initialized,card_pad_shared;
    uint32_t bios_card_early_patches,bios_card_delay_patches,bios_card_info_patches;
    int card_running;
    int bu_driver_registered;
    uint32_t console_bytes;
    int console_truncated;
    char console_output[LEKAK_EXEC_CONSOLE];
    int logical_interrupts_enabled;
    char reason[128];
} LekakExecResult;
typedef struct LekakExecPads { int connected[2]; uint16_t pressed[2]; uint32_t press_frame,release_frame,repeat_frames; } LekakExecPads;
/* Bounded functional MIPS-I diagnostic with logical SYS(1/2) critical flag.
 * Selected BIOS startup services, nominal timers/video blank events,
 * bounded priority-chain IRQ hooks and synchronous GPU linked DMA are adapted.
 * Known BIOS patch policies, limited SR and OTC DMA are adapted as well.
 * Standard pad buffers and VBlank polling use explicit virtual inputs.
 * RAM data-load stalls, disabled JOY_CTRL and card idle/sharing configuration
 * are partial adapters, not a full timing or card I/O implementation.
 * Selected single-data-track CD streaming/FIFO/manual DMA3 and SPU gain
 * configuration, ADPCM/ADSR/reverb, manual RAM and selected DMA4 are functional
 * adapters with nominal timing/backpressure. Selected polling/callback BIOS
 * events derive from masked root-counter IRQs,
 * no fabricated completion or retail BIOS private-node addresses.
 * Full CP0 exceptions, other DMA modes/BIOS services, serial pads, full CD/SPU,
 * scanout and cycle-accurate PS1 execution are unsupported and halt.
 * RAM may change: run on a fresh private copy of the loaded executable. */
int LekakExec_Run(MemoriesMemory *,uint32_t entry,uint32_t gp,uint32_t sp,
                  uint32_t budget,LekakExecResult *);
/* Fixed digital-pad snapshot for deterministic local tests. NULL means no
 * controller connected. No iPhone touch controls or serial device timing. */
int LekakExec_RunWithPads(MemoriesMemory *,uint32_t entry,uint32_t gp,uint32_t sp,
                         uint32_t budget,LekakExecResult *,const LekakExecPads *);
/* FILE/image is borrowed for this synchronous bounded call only. */
int LekakExec_RunWithDisc(MemoriesMemory *,uint32_t entry,uint32_t gp,uint32_t sp,
                         uint32_t budget,LekakExecResult *,const LekakExecPads *,LekakDiscImage *);
/* Persistent single-threaded execution. RAM/disc are borrowed until Destroy;
 * only one session may own the global rasterizer at a time. Slices yield at
 * completed instructions/branch pairs/DMA transactions, never mid-operation.
 * Quota is1..1000000; an atomic operation may exceed it. Runtime faults are
 * terminal; invalid quotas do not mutate the session. All setters run on the
 * execution thread between slices. */
typedef struct LekakExecSession LekakExecSession;
enum { LEKAK_EXEC_FAULT=-1, LEKAK_EXEC_FINISHED=0, LEKAK_EXEC_YIELDED=1 };
LekakExecSession *LekakExec_Create(MemoriesMemory *,uint32_t,uint32_t,uint32_t,
                                 const LekakExecPads *,LekakDiscImage *);
int LekakExec_Slice(LekakExecSession *,uint32_t,LekakExecResult *);
void LekakExec_SetPads(LekakExecSession *,const LekakExecPads *);
typedef void (*LekakExecAudioSink)(void *,int16_t,int16_t);
/* Nominal44100Hz callback, including silence while SPU is disabled. Sink must
 * not reenter or mutate the session. NULL disables sample capture. */
void LekakExec_SetAudioSink(LekakExecSession *,LekakExecAudioSink,void *);
void LekakExec_Destroy(LekakExecSession *);
#endif
