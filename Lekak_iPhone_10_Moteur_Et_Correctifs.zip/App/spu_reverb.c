/* Functional reverb equations: https://psx-spx.consoledev.net/soundprocessingunitspu/
 * Q15 signed coefficients, saturating RAM writes, base-relative circular buffer.
 * Stereo processed together every second sample; held output, no 39-tap FIR.
 * No capture or SPU IRQ. Does not claim sample-exact hardware output. */
#include "spu_reverb.h"
static int16_t sat(int64_t v){return (int16_t)(v<-32768?-32768:v>32767?32767:v);}
static int32_t mul(int64_t x,uint16_t v){return (int32_t)((x*(int16_t)v)>>15);}
static uint32_t address(const LekakSpuReverb *s,int32_t offset){
 int64_t size=0x80000u-s->base;
 int64_t at=(int64_t)s->current-s->base+offset;at%=size;if(at<0)at+=size;
 return s->base+(uint32_t)at;
}
static int16_t rd(const LekakSpuReverb *s,const uint8_t *ram,int32_t offset){
 uint32_t a=address(s,offset);return (int16_t)((uint16_t)ram[a]|((uint16_t)ram[a+1]<<8));
}
static void wr(LekakSpuReverb *s,uint8_t *ram,int32_t offset,int64_t value){
 uint32_t a=address(s,offset);uint16_t v=(uint16_t)sat(value);
 ram[a]=(uint8_t)v;ram[a+1]=(uint8_t)(v>>8);s->writes++;
}
void LekakSpuReverb_Step(LekakSpuReverb *s,uint8_t *ram,int32_t l,int32_t r,int enabled){
 const uint16_t *v=s->registers;
 int32_t input[2]={mul(sat(l),v[30]),mul(sat(r),v[31])};
 if(enabled){
  /* Snapshot both reflections before writing, preserving cross-channel input. */
  int32_t same[2],diff[2];
  for(unsigned ch=0;ch<2;ch++){
   int32_t prev=rd(s,ram,(int32_t)v[10+ch]*8-2);
   int64_t result=mul(input[ch]+mul(rd(s,ram,(int32_t)v[16+ch]*8),v[7])-prev,v[2])+prev;
   same[ch]=v[2]==0x8000u?-(int32_t)result:(int32_t)result;
   prev=rd(s,ram,(int32_t)v[18+ch]*8-2);
   result=mul(input[ch]+mul(rd(s,ram,(int32_t)v[24+(ch^1)]*8),v[7])-prev,v[2])+prev;
   diff[ch]=v[2]==0x8000u?-(int32_t)result:(int32_t)result;
  }
  for(unsigned ch=0;ch<2;ch++){wr(s,ram,(int32_t)v[10+ch]*8,same[ch]);wr(s,ram,(int32_t)v[18+ch]*8,diff[ch]);}
 }
 for(unsigned ch=0;ch<2;ch++){
  int32_t out=mul(rd(s,ram,(int32_t)v[12+ch]*8),v[3])+
   mul(rd(s,ram,(int32_t)v[14+ch]*8),v[4])+
   mul(rd(s,ram,(int32_t)v[20+ch]*8),v[5])+
   mul(rd(s,ram,(int32_t)v[22+ch]*8),v[6]);
  for(unsigned apf=0;apf<2;apf++){
   int32_t dest=(int32_t)v[26+apf*2+ch]*8;
   int32_t prior=rd(s,ram,dest-(int32_t)v[apf]*8);
   out=sat(out-mul(prior,v[8+apf]));
   if(enabled)wr(s,ram,dest,out);
   out=sat(mul(out,v[8+apf])+prior);
  }
  s->output[ch]=sat(mul(out,s->gain[ch]));
 }
 s->current+=2;if(s->current>=0x80000u)s->current=s->base;s->ticks++;
}
