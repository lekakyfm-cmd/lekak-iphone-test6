#ifndef LEKAK_CD_REGISTERS_H
#define LEKAK_CD_REGISTERS_H
#include "disc_image.h"
#include "xa_audio.h"
/* Selected single-data-track indexed interface, image-backed decoder/host
 * FIFOs and data stream. Timing and backpressure are functional approximations,
 * not HC05/spindle/overrun emulation. Unsupported commands/audio explicitly halt. */
typedef struct LekakCdRegisters {
 LekakDiscImage *image;
 uint8_t index,enable,flags,params[16],param_count,response[16],response_count,response_pos;
 uint8_t command,mode,muted,second,busy,volume[4];
 uint8_t volume_applied[4];
 uint8_t ack[16],ack_count;
 uint8_t decoded[2340],fifo[2340];
 uint32_t next_lba,stream_delay,sectors_decoded,data_irqs,data_bytes;
 unsigned decoded_size,fifo_size,fifo_pos;
 int streaming,decoded_ready;
 uint8_t filter_file,filter_channel;
 LekakXaAudio xa;
 uint32_t delay,reads,writes,commands,acks,completions;
} LekakCdRegisters;
static inline int LekakCd_Address(uint32_t a){a&=0x1fffffffu;return a>=0x1f801800u&&a<=0x1f801803u;}
static inline unsigned LekakCd_Irq(const LekakCdRegisters *c){return (c->flags&c->enable&7u)?4u:0u;}
static inline void LekakCd_AudioFrame(LekakCdRegisters *c,int16_t out[2]){
 int16_t input[2];LekakXa_Frame(&c->xa,input);
 int mix[2]={((int)input[0]*c->volume_applied[0]+(int)input[1]*c->volume_applied[3])/128,
             ((int)input[0]*c->volume_applied[1]+(int)input[1]*c->volume_applied[2])/128};
 for(unsigned i=0;i<2;i++)out[i]=c->muted?0:(int16_t)(mix[i]<-32768?-32768:mix[i]>32767?32767:mix[i]);
}
static inline int LekakCd_Cycle(LekakCdRegisters *c){
 if(c->flags)return 0;
 if(c->delay&&--c->delay)return 0;
 if(c->busy){c->busy=0;c->flags=3;memcpy(c->response,c->ack,c->ack_count);c->response_count=c->ack_count;c->response_pos=0;c->param_count=0;c->acks++;return 0;}
 if(c->second){c->second=0;c->flags=2;c->response[0]=2;c->response_count=1;c->response_pos=0;c->completions++;return 0;}
 /* Bounded functional decoder/host FIFO: backpressure when IRQ or unread
  * decoder slot is occupied. No real spindle/overrun/seek timing claim. */
 if(c->streaming&&!c->decoded_ready){
  if(c->stream_delay&&--c->stream_delay)return 0;
  unsigned size=(c->mode&0x60u)?2340:2048;
  if(!LekakDiscImage_ReadData(c->image,c->next_lba,c->decoded,size))return -1;
  if((c->mode&0x40u)&&(c->decoded[6]&4u)){
   if(!(c->mode&8u)||(c->decoded[4]==c->filter_file&&c->decoded[5]==c->filter_channel)){
    int decoded=LekakXa_Decode(&c->xa,c->decoded);if(decoded<0)return -1;if(!decoded){c->stream_delay=1;return 0;}
   }
   c->next_lba++;c->sectors_decoded++;c->stream_delay=(c->mode&0x80u)?225792:451584;return 0;
  }
  if((c->mode&0x40u)&&!(c->mode&0x20u)){memmove(c->decoded,c->decoded+12,2048);size=2048;}
  c->next_lba++;c->decoded_size=size;c->decoded_ready=1;c->sectors_decoded++;
  c->stream_delay=(c->mode&0x80u)?225792:451584;
  c->flags=1;c->response[0]=0x22;c->response_count=1;c->response_pos=0;c->data_irqs++;
 }
 return 0;
}
static inline int LekakCd_ReadData(LekakCdRegisters *c,unsigned width,uint32_t *out){
 if((width!=1&&width!=2&&width!=4)||c->fifo_pos>c->fifo_size||width>c->fifo_size-c->fifo_pos)return -1;
 uint32_t v=0;for(unsigned i=0;i<width;i++)v|=(uint32_t)c->fifo[c->fifo_pos+i]<<(8*i);
 c->fifo_pos+=width;c->data_bytes+=width;*out=v;return 1;
}
static inline int LekakCd_Bcd(uint8_t v){return (v&15u)<10&&(v>>4)<10;}
static inline unsigned LekakCd_Unbcd(uint8_t v){return (v>>4)*10+(v&15u);}
/* 0 outside device, 1 supported, -1 unsupported/invalid. Output unchanged on
 * rejected FIFO reads. Empty-response reads reject, not fabricated bytes. */
static inline int LekakCd_Read(LekakCdRegisters *c,uint32_t a,uint8_t *v){
 if(!LekakCd_Address(a))return 0;
 unsigned port=a&3u;uint8_t result;
 if(port==0)result=c->index|(c->param_count?0:8)|(c->param_count<16?16:0)|(c->response_pos<c->response_count?32:0)|(c->busy?128:0)|(c->fifo_pos<c->fifo_size?64:0);
 else if(port==1){if(c->response_pos==c->response_count)return -1;result=c->response[c->response_pos++];}
 else if(port==2){uint32_t data;if(LekakCd_ReadData(c,1,&data)<0)return -1;result=(uint8_t)data;}
 else result=0xe0u|((c->index&1)?c->flags:c->enable);
 *v=result;c->reads++;return 1;
}
static inline int LekakCd_Write(LekakCdRegisters *c,uint32_t a,uint8_t v){
 if(!LekakCd_Address(a))return 0;
 unsigned port=a&3u;
 if(!port){if(v&~3u)return -1;c->index=v;}
 else if(port==1&&c->index==0){
  if(!c->image||!c->image->file||!c->image->sectors||c->busy||c->second)return -1;
  uint8_t ack[5]={c->streaming?0x22:2,0,0,0,0},count=1;
  uint32_t location=0;
  if(v==2){
   if(c->streaming||c->param_count!=3)return -1;
   for(unsigned i=0;i<3;i++)if(!LekakCd_Bcd(c->params[i]))return -1;
   unsigned mm=LekakCd_Unbcd(c->params[0]),ss=LekakCd_Unbcd(c->params[1]),ff=LekakCd_Unbcd(c->params[2]);
   if(ss>=60||ff>=75)return -1;
   uint32_t frame=(mm*60+ss)*75+ff;
   if(frame<150||frame-150>=c->image->sectors)return -1;
   location=frame-150;
  }else if(v==6||v==0x1b){
   if(c->streaming||c->param_count||c->next_lba>=c->image->sectors)return -1;
   if((c->mode&0x20u)&&c->image->stride!=2352)return -1;
   ack[0]=0x22;
  }else if(v==0x15||v==0x16){
   if(c->param_count||c->next_lba>=c->image->sectors)return -1;
   ack[0]=0x42;
  }else if(v==0x0e){
   if(c->streaming||c->param_count!=1||(c->params[0]&~0xe8u))return -1;
   if((c->params[0]&0x40u)&&c->image->stride!=2352)return -1;
  }else if(v==0x0d){
   if(c->param_count!=2)return -1;
  }else if(v==0x14){
   if(c->param_count!=1||c->params[0]>1)return -1;
   uint64_t seconds=c->params[0]?2:((uint64_t)c->image->sectors+150)/75;
   if(seconds/60>99)return -1;
   unsigned mm=(unsigned)(seconds/60),ss=(unsigned)(seconds%60);
   ack[1]=(uint8_t)((mm/10)*16+mm%10);ack[2]=(uint8_t)((ss/10)*16+ss%10);count=3;
  }else{
   if(c->param_count)return -1;
   if(v==0x0f){ack[1]=c->mode;ack[3]=c->filter_file;ack[4]=c->filter_channel;count=5;}
   else if(v==0x13){ack[1]=ack[2]=1;count=3;} /* Validated single-data-track image. */
   else if(v!=1&&v!=9&&v!=0x0a&&v!=0x0b&&v!=0x0c)return -1;
  }
  memcpy(c->ack,ack,count);c->ack_count=count;
  if(v==2)c->next_lba=location;
  if(v==6||v==0x1b){
   /* Starting a new read/seek invalidates this model's old decoder slot.
    * Keeping an ACKed but unrequested sector would permanently suppress INT1
    * for the newly selected location. Host FIFO remains under BFRD control. */
   c->decoded_ready=0;c->decoded_size=0;c->streaming=1;c->stream_delay=(c->mode&0x80u)?225792:451584;}
  c->command=v;c->busy=1;c->delay=2000;c->commands++;
  if(v==0x0e)c->mode=c->params[0];
  if(v==0x0d){c->filter_file=c->params[0];c->filter_channel=c->params[1];}
  if(v==0x0a){c->streaming=0;c->decoded_ready=0;c->fifo_size=c->fifo_pos=0;c->mode=0x20;c->second=1;}
  if(v==0x15||v==0x16){c->streaming=0;c->decoded_ready=0;c->decoded_size=0;c->second=1;}
  if(v==9){c->streaming=0;c->second=1;c->ack[0]=2;}
  if(v==0x0b)c->muted=1;
  if(v==0x0c)c->muted=0;
 }
 else if(port==2&&c->index==0){if(c->param_count==16)return -1;c->params[c->param_count++]=v;}
 else if(port==2&&c->index==1){if(v&~0x1fu)return -1;c->enable=v;}
 else if(port==3&&c->index==1){
  if(v&~0x5fu)return -1;
  c->flags&=~(v&7u);
  if(v&0x40)c->param_count=0;
  if(!c->flags&&c->second)c->delay=2000;
 }
 else if(port==3&&c->index==0){
  if(v==0)c->fifo_size=c->fifo_pos=0;
  else if(v==0x80){
   /* SDK reasserts BFRD between partial DMA blocks. While asserted with
    * unread FIFO bytes, retain the current position rather than reload. */
   if(c->fifo_pos==c->fifo_size){
    if(!c->decoded_ready)return -1;
    memcpy(c->fifo,c->decoded,c->decoded_size);c->fifo_size=c->decoded_size;c->fifo_pos=0;c->decoded_ready=0;
   }
  }else return -1;
 }
 else if(c->index>=2&&port>=2){
  if(c->index==3&&port==3){if(v&~0x20u)return -1;if(v&0x20u)memcpy(c->volume_applied,c->volume,4);}
  else c->volume[c->index==2?(port==2?0:1):(port==1?2:3)]=v;
 }
 else if(port==1&&c->index==3)c->volume[2]=v;
 else return -1; /* XA decoder/manual sound-map configuration absent. */
 c->writes++;return 1;
}
#endif
