#ifndef LEKAK_AUDIO_RING_H
#define LEKAK_AUDIO_RING_H
#include <stdint.h>
#include <stdatomic.h>
#define LEKAK_AUDIO_CAPACITY 16384u
/* One producer, one consumer. Fixed storage; full drops new samples,
 * underflow returns silence. Counters use unsigned modular arithmetic. */
typedef struct LekakAudioRing {
 atomic_uint write_position,read_position,dropped;
 int16_t frames[LEKAK_AUDIO_CAPACITY][2];
} LekakAudioRing;
void LekakAudioRing_Init(LekakAudioRing *);
int LekakAudioRing_Push(LekakAudioRing *,int16_t,int16_t);
int LekakAudioRing_Pop(LekakAudioRing *,int16_t out[2]);
void LekakAudioRing_Sink(void *,int16_t,int16_t);
#endif
