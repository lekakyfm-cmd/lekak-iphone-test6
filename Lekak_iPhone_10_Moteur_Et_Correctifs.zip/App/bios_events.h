#ifndef LEKAK_BIOS_EVENTS_H
#define LEKAK_BIOS_EVENTS_H
#include <stdint.h>
/* Private software event table, polling and bounded callback dispatch. No hardware event
 * fabricated; no threads, blocking WaitEvent or BIOS RAM table. */
typedef struct LekakBiosEvent {uint32_t class_id,spec,mode,callback;unsigned used,enabled,ready;} LekakBiosEvent;
typedef struct LekakBiosEvents {LekakBiosEvent slots[16];} LekakBiosEvents;
static inline LekakBiosEvent *LekakEvent_Get(LekakBiosEvents *s,uint32_t h){
 if(h<0xf1000000u||h>=0xf1000010u)return 0;
 LekakBiosEvent *e=&s->slots[h-0xf1000000u];return e->used?e:0;
}
static inline uint32_t LekakEvent_Open(LekakBiosEvents *s,uint32_t c,uint32_t spec){
 for(unsigned i=0;i<16;i++)if(!s->slots[i].used){s->slots[i]=(LekakBiosEvent){c,spec,0x2000,0,1,0,0};return 0xf1000000u+i;}
 return 0xffffffffu;
}
static inline void LekakEvent_Deliver(LekakBiosEvents *s,uint32_t c,uint32_t spec,int ready){
 for(unsigned i=0;i<16;i++){LekakBiosEvent *e=&s->slots[i];if(e->used&&e->enabled&&e->mode==0x2000&&e->class_id==c&&e->spec==spec)e->ready=!!ready;}
}
#endif
