#ifndef LEKAK_SPU_DSP_H
#define LEKAK_SPU_DSP_H
#include <stdint.h>
#include "spu_reverb.h"
typedef struct Voice {
    int16_t left, right;
    uint16_t pitch, adsr1, adsr2;
    uint32_t start, loop;
    int phase, level, keyed;
    int loop_set;
    uint32_t address, counter;
    int32_t wait;
    int16_t block[3 + 28], history[2]; /* three samples of the previous block, then this one */
    int position, stop;
} Voice;

typedef struct LekakSpuDsp {
 Voice voices[24];
 LekakSpuReverb reverb;
 int reverb_enabled;
 int cd_enabled;
 int16_t cd_input[2],cd_gain[2];
 uint8_t *ram;
 uint32_t end_mask,frames,nonzero_frames,pcm_hash;
 int16_t last[2];
} LekakSpuDsp;
void LekakSpuDsp_Key(LekakSpuDsp *,uint32_t,int);
void LekakSpuDsp_Frame(LekakSpuDsp *,const uint16_t *);
#endif
