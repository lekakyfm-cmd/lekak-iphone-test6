#include "lekak_rules.h"
#include <stdio.h>
#include <string.h>
typedef struct { unsigned kind, target; const char *ref; } LekakCondition;
#include "lekak_progress_data.h"
const char *LekakRules_Duelist(unsigned index) {
 return index < 40 ? duelist_ids[index] : NULL;
}
static uint64_t value(const LekakCondition *c, const LekakProgressSnapshot *s) {
 unsigned count = 0;
 switch (c->kind) {
 case 0: return s->wins ? s->wins(s->context,c->ref) : 0;
 case 1: return s->total_wins;
 case 2: return s->unlocked && s->unlocked(s->context,c->ref) > 0;
 case 3: return s->seen && s->seen(s->context,c->ref) > 0;
 case 4: return s->owned ? s->owned(s->context,c->ref) : 0;
 case 5:
  if (!s->unlocked) return 0;
  for (unsigned i=0;i<(!strcmp(c->ref,"first6")?6u:37u);i++)
   count += s->unlocked(s->context,duelist_ids[i]) > 0;
  return count;
 case 6:
  if (!s->wins) return 0;
  if (!strcmp(c->ref,"retail39")) {
   for (unsigned i=1;i<40;i++) {
    char id[12];snprintf(id,sizeof(id),"%u",i);
    count += s->wins(s->context,id) >= 1;
   }
  } else for (unsigned i=0;i<37;i++) count += s->wins(s->context,duelist_ids[i]) >= 1;
  return count;
 case 7: return s->distinct_seen;
 default: return 0;
 }
}
int LekakRules_Ready(unsigned index, const LekakProgressSnapshot *snapshot) {
 if (index>=40 || !snapshot) return 0;
 for (unsigned i=0;i<condition_counts[index];i++)
  if (value(&conditions[index][i],snapshot)<conditions[index][i].target) return 0;
 return 1;
}
uint32_t LekakRules_Price(int attack, int monster) {
 uint32_t price=500;
 if (!monster) return price;
 int64_t ceiling=1500;
 while ((int64_t)attack>ceiling) {
  if (price>999999u/2) return 999999;
  price*=2;ceiling+=500;
 }
 return price;
}
uint32_t LekakRules_NameRGB(int attack, int monster) {
 if (!monster || attack<=1500) return 0;
 if (attack<=2000) return 0xFFEB3C;
 if (attack<=2500) return 0xFF9123;
 if (attack<=3000) return 0xFF4141;
 if (attack<=3500) return 0xC85AFF;
 if (attack<4000) return 0x4687FF;
 if (attack<=4500) return 0x50FF1E;
 return 0x2DFFF5;
}
