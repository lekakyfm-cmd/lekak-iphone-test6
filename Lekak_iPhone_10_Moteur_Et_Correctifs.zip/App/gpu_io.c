#include "gpu_io.h"
#include "pc/render/soft_gpu.h"
#include "pc/render/packets.h"
#include <string.h>
static int polyline(uint32_t command){return (command&0xe8000000u)==0x48000000u;}
static int poly_end(uint32_t command,uint32_t value,size_t at){
 return at>=((command&0x10000000u)?4u:3u)&&
  (!(command&0x10000000u)||!(at&1u))&&(value&0xf000f000u)==0x50005000u;
}
MemoriesGpuResult LekakGpuIo_ValidateDrawing(const uint32_t *words,size_t count){
 if(!words&&count)return MEMORIES_GPU_ARGUMENT;
 size_t at=0;
 while(at<count){
  size_t n=Memories_GpuCommandWords(words[at]);
  if(polyline(words[at])){
   n=1;while(n<count-at&&n<LEKAK_GPU_PACKET_WORDS&&!poly_end(words[at],words[at+n],n))n++;
   if(n==LEKAK_GPU_PACKET_WORDS)return MEMORIES_GPU_CAPACITY;
   if(n==count-at)return MEMORIES_GPU_TRUNCATED_COMMAND;
   n++;
  }
  if(!n)return MEMORIES_GPU_UNSUPPORTED_COMMAND;
  if(n>count-at)return MEMORIES_GPU_TRUNCATED_COMMAND;
  at+=n;
 }
 return MEMORIES_GPU_OK;
}
static void ready(LekakGpuIo *g){
 g->status&=~0x0a000000u;
 if(g->transfer_mode==2)g->status|=0x08000000u;
 unsigned direction=g->status>>29&3u;
 if(direction==1||direction==2||(direction==3&&g->transfer_mode==2))g->status|=0x02000000u;
}
static uint16_t pixel(LekakGpuIo *g,uint16_t value,int write){
 uint32_t p=g->transfer_position++,x=(g->transfer_x+p%g->transfer_width)&1023u;
 uint32_t y=(g->transfer_y+p/g->transfer_width)&511u;
 if(write)SoftGpu_Load((int)x,(int)y,1,1,&value);
 else SoftGpu_Store((int)x,(int)y,1,1,&value);
 if(g->transfer_position==g->transfer_pixels){g->transfer_mode=0;ready(g);}
 return value;
}
static void reset(LekakGpuIo *g){
 g->status=0x14802000u;g->read_latch=0;g->count=g->expected=0;
 g->transfer_mode=0;
 g->display_start=0;g->horizontal=0xc00200u;g->vertical=0x040010u;
 memset(g->attributes,0,sizeof(g->attributes));
 SoftGpu_Reset();
 const uint32_t attributes[]={0xe1000000u,0xe2000000u,0xe3000000u,0xe4000000u,0xe5000000u,0xe6000000u};
 SoftGpu_Gp0(attributes,6);
}
void LekakGpuIo_Init(LekakGpuIo *g){
 memset(g,0,sizeof(*g));reset(g);
 /* Deterministic initial VRAM, separate from GP1 reset (which preserves it). */
 SoftGpu_Fill(0,0,SOFT_GPU_WIDTH,SOFT_GPU_HEIGHT,0);
}
int LekakGpuIo_Read(LekakGpuIo *g,uint32_t address,uint32_t *value){
 uint32_t a=address&0x1fffffffu;
 if(a!=0x1f801810u&&a!=0x1f801814u)return 0;
 if(a==0x1f801810u&&g->transfer_mode==2){
  uint32_t word=pixel(g,0,0);
  if(g->transfer_mode==2)word|=(uint32_t)pixel(g,0,0)<<16;
  g->read_latch=word;
 }
 *value=a==0x1f801810u?g->read_latch:g->status;g->reads++;return 1;
}
int LekakGpuIo_Write(LekakGpuIo *g,uint32_t address,uint32_t value){
 uint32_t a=address&0x1fffffffu;
 if(a==0x1f801814u){
  unsigned op=value>>24,parameter=value&0xffffffu;
  switch(op){
   case 0:reset(g);break;
   case 1:g->count=g->expected=0;g->transfer_mode=0;ready(g);break;
   case 2:g->status&=~0x01000000u;break;
   case 3:g->status=(g->status&~0x800000u)|((parameter&1)<<23);break;
   case 4:
    g->status=(g->status&~0x62000000u)|((parameter&3)<<29);
    ready(g);
    break;
   case 5:g->display_start=parameter&0x7ffffu;break;
   case 6:g->horizontal=parameter;break;
   case 7:g->vertical=parameter&0xfffffu;break;
   case 8:
    /* Do not accept interlace or v1 reverse mode. */
    if(parameter&0xa0u)return -1;
    g->status=(g->status&~0x007f0000u)|((parameter&0x3fu)<<17)|((parameter&0x40u)<<10);
    break;
   case 9:if(parameter&1)return -1;break;
   default:
    if(op<0x10||op>0x1f)return -1;
    switch(parameter&15u){
     case 2:g->read_latch=g->attributes[1];break;
     case 3:g->read_latch=g->attributes[2];break;
     case 4:g->read_latch=g->attributes[3];break;
     case 5:g->read_latch=g->attributes[4];break;
     case 7:g->read_latch=2;break; /* Selected retail v2 model. */
     case 8:g->read_latch=0;break;
     default:break; /* Unspecified indices retain the previous latch. */
    }
  }
  g->gp1_commands++;return 1;
 }
 if(a!=0x1f801810u)return 0;
 if(g->transfer_mode==1){
  pixel(g,(uint16_t)value,1);
  if(g->transfer_mode==1)pixel(g,(uint16_t)(value>>16),1);
  return 1;
 }
 if(g->transfer_mode==2)return -1;
 if(!g->count){
  if((value>>24)==1){g->gp0_commands++;return 1;} /* No texture cache in backend. */
  unsigned op=value>>24;
  g->expected=(op==0xa0||op==0xc0)?3u:(uint32_t)Memories_GpuCommandWords(value);
  if(!polyline(value)&&(!g->expected||g->expected>16))return -1;
 }
 if(g->count==LEKAK_GPU_PACKET_WORDS)return -1;
 g->words[g->count++]=value;
 if(polyline(g->words[0])&&poly_end(g->words[0],value,g->count-1))g->expected=g->count;
 if(g->count==g->expected){
  unsigned command=g->words[0]>>24;
  if(command==0xa0||command==0xc0){
   g->transfer_x=g->words[1]&1023u;g->transfer_y=g->words[1]>>16&511u;
   g->transfer_width=((g->words[2]-1)&1023u)+1;
   g->transfer_pixels=g->transfer_width*((((g->words[2]>>16)-1)&511u)+1);
   g->transfer_position=0;g->transfer_mode=command==0xa0?1u:2u;
   g->count=g->expected=0;g->gp0_commands++;ready(g);return 1;
  }
  if(LekakGpuIo_ValidateDrawing(g->words,g->count)!=MEMORIES_GPU_OK||SoftGpu_Gp0(g->words,g->count)!=g->count)return -1;
  unsigned op=g->words[0]>>24;
  if(op>=0xe1&&op<=0xe6){
   const uint32_t masks[]={0x3fffu,0xfffffu,0x7ffffu,0x7ffffu,0x3fffffu,3u};
   g->attributes[op-0xe1]=g->words[0]&masks[op-0xe1];
   if(op==0xe1)g->status=(g->status&~0x7ffu)|(g->words[0]&0x7ffu);
   if(op==0xe6)g->status=(g->status&~0x1800u)|((g->words[0]&3u)<<11);
  }
  g->gp0_commands++;g->count=g->expected=0;
 }
 return 1;
}
