#ifndef LEKAK_DISPLAY_TIMING_H
#define LEKAK_DISPLAY_TIMING_H
#include "timer_registers.h"
#include "gpu_io.h"
/* NTSC crystal ratio. Caller supplies nominal CPU cycles including the
 * supported RAM-load stalls, NOT a cycle-accurate CPU. GPU phase uses half
 * cycles for 3412.5 clocks/line. Non-interlaced PAL/NTSC only; no scanout. */
typedef struct LekakDisplayTiming {
 uint64_t cycles,fraction;
 unsigned half_cycle,line,dot_phase,frames,hblank_edges,vblank_edges;
 int hblank,vblank;
} LekakDisplayTiming;
static inline unsigned LekakDisplay_Cycle(LekakDisplayTiming *v,LekakTimerRegisters *t,LekakGpuIo *g){
 unsigned irq=LekakTimer_CpuCycle(t);v->cycles++;
 v->fraction+=107386350u;
 while(v->fraction>=33868800u){
  v->fraction-=33868800u;
  unsigned pal=(g->status>>20)&1,line_length=pal?6810:6825,lines=pal?314:263;
  if(++v->half_cycle>=line_length){v->half_cycle=0;v->dot_phase=0;if(++v->line>=lines){v->line=0;v->frames++;}}
  unsigned start=(g->horizontal&0xfff)*2,end=((g->horizontal>>12)&0xfff)*2;
  int hblank=v->half_cycle<start||v->half_cycle>=end;
  if(hblank&&!v->hblank){v->hblank_edges++;if(t->mode[1]&0x100)irq|=LekakTimer_Tick(t,1);}
  LekakTimer_Blank(t,0,hblank);v->hblank=hblank;
  start=g->vertical&0x3ff;end=(g->vertical>>10)&0x3ff;
  int vblank=v->line<start||v->line>=end;
  if(vblank&&!v->vblank){v->vblank_edges++;irq|=1;}
  LekakTimer_Blank(t,1,vblank);v->vblank=vblank;
  unsigned resolution=(g->status>>17)&3;
  unsigned divisor=(g->status&0x10000)?7:(resolution==0?10:(resolution==1?8:(resolution==2?5:4)));
  if(++v->dot_phase>=divisor*2){v->dot_phase=0;if(t->mode[0]&0x100)irq|=LekakTimer_Tick(t,0);}
 }
 return irq;
}
#endif
