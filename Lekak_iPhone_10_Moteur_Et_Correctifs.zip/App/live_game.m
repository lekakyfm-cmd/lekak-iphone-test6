#import "live_game.h"
#import <AVFoundation/AVFoundation.h>
#import <QuartzCore/QuartzCore.h>
#include "guest_exec.h"
#include "disc_loader.h"
#include "display_snapshot.h"
#include "audio_ring.h"
#include "pc/render/soft_gpu.h"
#include <stdatomic.h>
#include <stdlib.h>
#include <unistd.h>

static UIImage *LiveFrame(const LekakExecResult *r){
 NSMutableData *data=[NSMutableData dataWithLength:640*512*4];unsigned width=0,height=0;
 if(!LekakDisplay_CopyRGBA(SoftGpu_Vram(),r->gpu_status,r->gpu_display_start,r->gpu_display_vertical,data.mutableBytes,data.length,&width,&height))return nil;
 data.length=(NSUInteger)width*height*4;
 CGDataProviderRef provider=CGDataProviderCreateWithCFData((__bridge CFDataRef)data);
 CGColorSpaceRef space=CGColorSpaceCreateDeviceRGB();
 CGImageRef frame=CGImageCreate(width,height,8,32,width*4,space,(CGBitmapInfo)kCGImageAlphaLast,provider,NULL,NO,kCGRenderingIntentDefault);
 UIImage *image=frame?[UIImage imageWithCGImage:frame]:nil;
 if(frame)CGImageRelease(frame);CGColorSpaceRelease(space);CGDataProviderRelease(provider);return image;
}
@interface LekakLiveGameController () {
 atomic_bool _stop,_paused,_framePending;
 atomic_uint _buttons;
 LekakAudioRing *_audioRing;
 BOOL _closing,_started;
}
@property(nonatomic,strong) NSURL *discURL;
@property(nonatomic,copy) void (^completion)(NSDictionary *);
@property(nonatomic,strong) UIImageView *screen;
@property(nonatomic,strong) UILabel *status;
@property(nonatomic,strong) AVAudioEngine *audio;
@property(nonatomic,strong) AVAudioSourceNode *audioSource;
@end
@implementation LekakLiveGameController
- (instancetype)initWithDiscURL:(NSURL *)url completion:(void (^)(NSDictionary *))completion {
 if((self=[super init])){
  self.discURL=url;self.completion=completion;
  atomic_init(&_stop,0);atomic_init(&_paused,0);atomic_init(&_framePending,0);atomic_init(&_buttons,0);
  _audioRing=malloc(sizeof(*_audioRing));if(_audioRing)LekakAudioRing_Init(_audioRing);
 }return self;
}
- (void)dealloc {[[NSNotificationCenter defaultCenter] removeObserver:self];[self.audio stop];free(_audioRing);}
- (UIButton *)button:(NSString *)label mask:(unsigned)mask {
 UIButton *b=[UIButton buttonWithType:UIButtonTypeSystem];[b setTitle:label forState:UIControlStateNormal];
 b.tag=mask;b.backgroundColor=[UIColor colorWithWhite:0.16 alpha:1];b.layer.cornerRadius=8;
 [b setTitleColor:UIColor.whiteColor forState:UIControlStateNormal];b.titleLabel.font=[UIFont boldSystemFontOfSize:18];
 b.titleLabel.adjustsFontSizeToFitWidth=YES;b.titleLabel.minimumScaleFactor=0.6;
 [b.heightAnchor constraintEqualToConstant:44].active=YES;
 [b addTarget:self action:@selector(press:) forControlEvents:UIControlEventTouchDown|UIControlEventTouchDragEnter];
 [b addTarget:self action:@selector(release:) forControlEvents:UIControlEventTouchUpInside|UIControlEventTouchUpOutside|UIControlEventTouchCancel|UIControlEventTouchDragExit];return b;
}
- (UIStackView *)row:(NSArray<UIView *> *)items {
 UIStackView *row=[[UIStackView alloc] initWithArrangedSubviews:items];row.axis=UILayoutConstraintAxisHorizontal;
 row.distribution=UIStackViewDistributionFillEqually;row.spacing=4;return row;
}
- (void)viewDidLoad {
 [super viewDidLoad];self.title=@"Lekak — experimental";self.view.backgroundColor=UIColor.blackColor;
 self.navigationItem.leftBarButtonItem=[[UIBarButtonItem alloc] initWithTitle:@"Fermer / Close" style:UIBarButtonItemStylePlain target:self action:@selector(closeGame)];
 self.status=[UILabel new];self.status.text=@"Import du BIN / Importing BIN…";self.status.textColor=UIColor.whiteColor;
 self.status.numberOfLines=3;self.status.font=[UIFont systemFontOfSize:13];
 self.screen=[UIImageView new];self.screen.backgroundColor=UIColor.blackColor;self.screen.contentMode=UIViewContentModeScaleAspectFit;
 self.screen.layer.magnificationFilter=kCAFilterNearest;self.screen.layer.minificationFilter=kCAFilterNearest;
 [self.screen.heightAnchor constraintGreaterThanOrEqualToConstant:100].active=YES;
 NSLayoutConstraint *ratio=[self.screen.heightAnchor constraintEqualToAnchor:self.screen.widthAnchor multiplier:0.75];ratio.priority=UILayoutPriorityDefaultHigh;ratio.active=YES;
 NSArray *rows=@[
 [self row:@[[self button:@"L2" mask:1u<<8],[self button:@"L1" mask:1u<<10],[self button:@"SELECT" mask:1],[self button:@"START" mask:8],[self button:@"R1" mask:1u<<11],[self button:@"R2" mask:1u<<9]]],
 [self row:@[[self button:@"←" mask:1u<<7],[self button:@"↑" mask:1u<<4],[self button:@"↓" mask:1u<<6],[self button:@"→" mask:1u<<5],[self button:@"□" mask:1u<<15],[self button:@"△" mask:1u<<12],[self button:@"○" mask:1u<<13],[self button:@"×" mask:1u<<14]]]];
 NSMutableArray *items=[NSMutableArray arrayWithObjects:self.status,self.screen,nil];[items addObjectsFromArray:rows];
 UIStackView *layout=[[UIStackView alloc] initWithArrangedSubviews:items];layout.axis=UILayoutConstraintAxisVertical;layout.spacing=8;layout.translatesAutoresizingMaskIntoConstraints=NO;
 [self.view addSubview:layout];UILayoutGuide *safe=self.view.safeAreaLayoutGuide;
 [NSLayoutConstraint activateConstraints:@[[layout.leadingAnchor constraintEqualToAnchor:safe.leadingAnchor constant:12],[layout.trailingAnchor constraintEqualToAnchor:safe.trailingAnchor constant:-12],[layout.topAnchor constraintEqualToAnchor:safe.topAnchor constant:8],[layout.bottomAnchor constraintEqualToAnchor:safe.bottomAnchor constant:-8]]];
 [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(background:) name:UIApplicationWillResignActiveNotification object:nil];
 [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(foreground:) name:UIApplicationDidBecomeActiveNotification object:nil];
 [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(audioInterrupted:) name:AVAudioSessionInterruptionNotification object:nil];
}
- (void)viewDidAppear:(BOOL)animated {[super viewDidAppear:animated];if(!_started){_started=YES;[self startAudio];[self startWorker];}}
- (void)press:(UIButton *)b {atomic_fetch_or_explicit(&_buttons,(unsigned)b.tag,memory_order_relaxed);}
- (void)release:(UIButton *)b {atomic_fetch_and_explicit(&_buttons,~(unsigned)b.tag,memory_order_relaxed);}
- (void)background:(NSNotification *)note {(void)note;atomic_store(&_paused,1);atomic_store(&_buttons,0);[self.audio pause];}
- (void)foreground:(NSNotification *)note {(void)note;if(_closing)return;[self.audio startAndReturnError:NULL];atomic_store(&_paused,0);}
- (void)audioInterrupted:(NSNotification *)note {
 if([note.userInfo[AVAudioSessionInterruptionTypeKey] unsignedIntegerValue]==AVAudioSessionInterruptionTypeBegan)[self background:note];else [self foreground:note];
}
- (void)closeGame {
 if(_closing)return;_closing=YES;self.navigationItem.leftBarButtonItem.enabled=NO;
 self.status.text=@"Arrêt / Stopping…";atomic_store(&_buttons,0);atomic_store(&_stop,1);
}
- (void)startAudio {
 if(!_audioRing||!atomic_is_lock_free(&_audioRing->write_position)||!atomic_is_lock_free(&_audioRing->read_position))return;
 NSError *error=nil;AVAudioSession *session=AVAudioSession.sharedInstance;
 if(![session setCategory:AVAudioSessionCategoryPlayback error:&error]||![session setActive:YES error:&error])return;
 self.audio=[AVAudioEngine new];AVAudioFormat *format=[[AVAudioFormat alloc] initStandardFormatWithSampleRate:44100 channels:2];
 LekakAudioRing *ring=_audioRing;
 self.audioSource=[[AVAudioSourceNode alloc] initWithFormat:format renderBlock:^OSStatus(BOOL *silent,const AudioTimeStamp *time,AVAudioFrameCount count,AudioBufferList *buffers){
  (void)time;BOOL allSilent=YES;
  if(buffers->mNumberBuffers!=2||!buffers->mBuffers[0].mData||!buffers->mBuffers[1].mData)return -50;
  for(unsigned i=0;i<count;i++){
   int16_t pair[2];LekakAudioRing_Pop(ring,pair);if(pair[0]||pair[1])allSilent=NO;
   ((float *)buffers->mBuffers[0].mData)[i]=(float)pair[0]/32768.0f;
   ((float *)buffers->mBuffers[1].mData)[i]=(float)pair[1]/32768.0f;
  }*silent=allSilent;return 0;
 }];
 [self.audio attachNode:self.audioSource];[self.audio connect:self.audioSource to:self.audio.mainMixerNode format:format];[self.audio startAndReturnError:&error];
}
- (void)startWorker {
 dispatch_async(dispatch_get_global_queue(QOS_CLASS_USER_INITIATED,0), ^{
  NSURL *privateURL=[NSURL fileURLWithPath:[NSTemporaryDirectory() stringByAppendingPathComponent:[NSUUID.UUID.UUIDString stringByAppendingString:@".bin"]]];
  BOOL scoped=[self.discURL startAccessingSecurityScopedResource];__block NSError *importError=nil;
  NSFileCoordinator *coordinator=[[NSFileCoordinator alloc] initWithFilePresenter:nil];NSError *coordError=nil;
  [coordinator coordinateReadingItemAtURL:self.discURL options:0 error:&coordError byAccessor:^(NSURL *readURL){[[NSFileManager defaultManager] copyItemAtURL:readURL toURL:privateURL error:&importError];}];
  if(scoped)[self.discURL stopAccessingSecurityScopedResource];
  FILE *file=NULL;MemoriesMemory *ram=NULL;LekakExecSession *guest=NULL;LekakDiscImage image={0};LekakDiscResult disc={0};LekakExecResult result={0};
  NSString *failure=nil;int code=LEKAK_EXEC_YIELDED;
  if(coordError||importError)failure=@"Import impossible / Import failed. Download the BIN in Files first.";
  else if(!atomic_load(&self->_stop)){
   file=fopen(privateURL.fileSystemRepresentation,"rb");ram=calloc(1,sizeof(*ram));
   if(!ram||!LekakDisc_Load(file,ram,&disc)||!LekakDiscImage_Init(&image,file,disc.sector_bytes))failure=@"BIN USA invalide / Invalid USA BIN.";
   else{
    LekakExecPads pads={{1,0},{0,0},0,0,0};
    guest=LekakExec_Create(ram,disc.entry,disc.gp?disc.gp:0x8009af08u,disc.stack_base?disc.stack_base+disc.stack_bytes:0x801fff00u,&pads,&image);
    if(!guest)failure=@"Mémoire insuffisante / Not enough memory.";
    else{
     if(self->_audioRing)LekakExec_SetAudioSink(guest,LekakAudioRing_Sink,self->_audioRing);
     dispatch_async(dispatch_get_main_queue(),^{if(!self->_closing)self.status.text=@"Jeu original — intégration Lekak en cours\nOriginal game — Lekak integration pending\nSauvegardes non disponibles / Saves unavailable";});
     double origin=CACurrentMediaTime();uint32_t frame=UINT32_MAX;
     while(!atomic_load(&self->_stop)){
      @autoreleasepool {
       if(atomic_load(&self->_paused)){usleep(10000);origin=CACurrentMediaTime()-(double)result.nominal_cycles/33868800.0;continue;}
       pads.pressed[0]=(uint16_t)atomic_load_explicit(&self->_buttons,memory_order_relaxed);LekakExec_SetPads(guest,&pads);
       code=LekakExec_Slice(guest,8192,&result);
       if(result.video_frames!=frame&&!atomic_load(&self->_framePending)){
        frame=result.video_frames;UIImage *snapshot=LiveFrame(&result);
        if(snapshot){atomic_store(&self->_framePending,1);dispatch_async(dispatch_get_main_queue(),^{self.screen.image=snapshot;atomic_store(&self->_framePending,0);});}
       }
       if(code!=LEKAK_EXEC_YIELDED)break;
       double delay=origin+(double)result.nominal_cycles/33868800.0-CACurrentMediaTime();
       while(delay>0&&!atomic_load(&self->_stop)&&!atomic_load(&self->_paused)){
        usleep((useconds_t)(MIN(delay,0.01)*1000000));delay=origin+(double)result.nominal_cycles/33868800.0-CACurrentMediaTime();
       }
      }
     }
    }
   }
  }
  if(code==LEKAK_EXEC_FAULT)failure=[NSString stringWithUTF8String:result.reason];
  LekakExec_Destroy(guest);if(file)fclose(file);free(ram);[[NSFileManager defaultManager] removeItemAtURL:privateURL error:NULL];
  NSDictionary *report=@{@"revision":@9,@"mode":@"live-original-disc",@"lekak_integrated":@NO,@"saves_available":@NO,
   @"steps":@(result.total_steps),@"cycles":@(result.nominal_cycles),@"video_frames":@(result.video_frames),@"pad_polls":@(result.pad_polls),
   @"pc":[NSString stringWithFormat:@"%08X",result.pc],@"reason":failure?:@"User stopped",@"audio_dropped":@(self->_audioRing?atomic_load(&self->_audioRing->dropped):0)};
  dispatch_async(dispatch_get_main_queue(),^{
   [self.audio stop];if(self.completion)self.completion(report);
   if(self->_closing)[self dismissViewControllerAnimated:YES completion:nil];
   else {self.status.text=[NSString stringWithFormat:@"Arrêt / Stopped: %@\nPC %@ — Partager le rapport depuis l’écran précédent.",report[@"reason"],report[@"pc"]];self.navigationItem.leftBarButtonItem.enabled=YES;self.navigationItem.leftBarButtonItem.action=@selector(dismissStopped);}
  });
 });
}
- (void)dismissStopped {[self dismissViewControllerAnimated:YES completion:nil];}
@end
