#import <UIKit/UIKit.h>
/* Single guest worker, private imported disc and native live UI. Completion
 * runs on the main thread after guest/audio resources stop. No PC mod hooks. */
@interface LekakLiveGameController : UIViewController
- (instancetype)initWithDiscURL:(NSURL *)url completion:(void (^)(NSDictionary *))completion;
@end
