#ifndef LEKAK_MDEC_H
#define LEKAK_MDEC_H
#include <stdint.h>
#include <stddef.h>
/* Bounded functional decoder, not physical FIFO/clock emulation. */
typedef struct LekakMdec {
 uint32_t command,control,remaining,received,input_count,input_position;
 uint32_t commands,macroblocks,reads,writes;
 uint8_t quant[128],output[768];
 int16_t scale[64];
 uint16_t input[131070];
 unsigned output_size,output_position,reset_status;
} LekakMdec;
void LekakMdec_Init(LekakMdec *);
uint32_t LekakMdec_Status(const LekakMdec *);
int LekakMdec_Write(LekakMdec *,uint32_t address,uint32_t value);
int LekakMdec_Read(LekakMdec *,uint32_t address,uint32_t *value);
/* DMA API: selected bounded request transfers. 0=wait, -1=invalid,
 * 1=success. Output is reordered into whole RGB macroblocks for DMA1;
 * CPU GPUREAD-style reads retain the documented 8x8 block order. */
int LekakMdec_DmaWrite(LekakMdec *,const uint8_t *,uint32_t words);
int LekakMdec_DmaRead(LekakMdec *,uint8_t *,uint32_t words);
#endif
