#ifndef LEKAK_SPU_REVERB_H
#define LEKAK_SPU_REVERB_H
#include <stdint.h>
/* Functional SAME/DIFF/COMB/APF engine, not hardware resampling/timing. */
typedef struct LekakSpuReverb {
 uint16_t registers[32],gain[2];
 uint32_t base,current,voice_mask,ticks,writes;
 unsigned phase;
 int16_t output[2];
} LekakSpuReverb;
void LekakSpuReverb_Step(LekakSpuReverb *,uint8_t *,int32_t,int32_t,int);
#endif
