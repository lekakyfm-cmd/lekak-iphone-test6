#ifndef LEKAK_XA_AUDIO_H
#define LEKAK_XA_AUDIO_H
#include <stdint.h>
#define LEKAK_XA_QUEUE 16384u
typedef struct LekakXaAudio {
 int16_t pcm[LEKAK_XA_QUEUE][2];
 int history[2][2];
 uint32_t head,count,sectors,frames,consumed;
} LekakXaAudio;
/* Raw2340 bytes beginning at original sector byte12. Selected4-bit ADPCM.
 * Nearest-sample37800/18900->44100 conversion, not hardware7-tap XA FIR. */
int LekakXa_Decode(LekakXaAudio *,const uint8_t raw[2340]);
void LekakXa_Frame(LekakXaAudio *,int16_t out[2]);
#endif
