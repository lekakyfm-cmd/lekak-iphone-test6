#ifndef LEKAK_BIOS_PATCHES_H
#define LEKAK_BIOS_PATCHES_H
#include "pc/memory.h"
/* Recognize the documented six-word Psy-Q exception Cause/GTE patch only.
 * This functional interpreter executes COP2 serially and delivers interrupts
 * between complete instructions, so it cannot double-execute COP2 on entry.
 * No retail BIOS jump table or patchable exception code is fabricated.
 * Unknown sequences remain unsupported. Caller continues at FlushCache. */
static inline uint32_t LekakBios_CausePatch(MemoriesMemory *m,uint32_t return_pc){
 const uint8_t *p=Memories_Resolve(m,return_pc,0x68,4);if(!p)return 0;
 const uint32_t code[]={
  0x8c420018,0,0x24420028,0x00407821,0x3c0a0000,0x254a0000,0x3c090000,0x25290000,
  0x8d430000,0x8c4b0000,0x254a0004,0x146b000e,0x24420004,0x1549fffa,0,0x01e01021,
  0x3c0a0000,0x254a0000,0x3c090000,0x25290000,0x8d430000,0,0xac430000,0x254a0004,0x1549fffb,0x24420004};
 uint32_t words[26];
 for(unsigned i=0;i<26;i++){
  words[i]=Memories_ReadLE32(p+i*4);
  uint32_t mask=(i==4||i==5||i==6||i==7||i==16||i==17||i==18||i==19)?0xffff0000u:0xffffffffu;
  if((words[i]&mask)!=code[i])return 0;
 }
 uint32_t old_start=(words[4]<<16)+(int16_t)words[5],old_end=(words[6]<<16)+(int16_t)words[7];
 uint32_t new_start=(words[16]<<16)+(int16_t)words[17],new_end=(words[18]<<16)+(int16_t)words[19];
 if(old_end-old_start!=24||new_end-new_start!=24)return 0;
 const uint8_t *old=Memories_Resolve(m,old_start,24,4),*next=Memories_Resolve(m,new_start,24,4);
 if(!old||!next)return 0;
 const uint32_t before[]={0xaf410004,0xaf420008,0xaf43000c,0xaf5f007c,0x40037000,0};
 const uint32_t after[]={0xaf410004,0xaf420008,0x40026800,0xaf43000c,0x40037000,0xaf5f007c};
 for(unsigned i=0;i<6;i++)if(Memories_ReadLE32(old+i*4)!=before[i]||Memories_ReadLE32(next+i*4)!=after[i])return 0;
 return return_pc+0x68;
}
/* Documented Psy-Q patch that permanently suppresses Pad/Card's VBlank
 * acknowledgement. Model its policy, not writes into absent BIOS code. */
static inline uint32_t LekakBios_PadAckPatch(MemoriesMemory *m,uint32_t pc){
 const uint8_t *p=Memories_Resolve(m,pc,36,4);if(!p)return 0;
 const uint32_t code[]={0x240a0009,0x8c42016c,0,0x2043062c,0xac600000,0x24630004,0x254affff,0x1540fffc,0};
 for(unsigned i=0;i<9;i++)if(Memories_ReadLE32(p+i*4)!=code[i])return 0;
 return pc+36;
}
static inline uint32_t LekakBios_PadErrorPatch(MemoriesMemory *m,uint32_t pc,uint32_t slots[2]){
 const uint8_t *p=Memories_Resolve(m,pc,52,4);if(!p)return 0;
 const uint32_t code[]={0x8c42016c,0x2409000b,0x20430884,0x3c010000,0xac230000,
  0x20430894,0x3c010000,0xac230000,0xac400594,0x24420004,0x2529ffff,0x1520fffc,0};
 uint32_t words[13];
 for(unsigned i=0;i<13;i++){
  words[i]=Memories_ReadLE32(p+i*4);
  uint32_t mask=(i==3||i==4||i==6||i==7)?0xffff0000u:0xffffffffu;
  if((words[i]&mask)!=code[i])return 0;
 }
 slots[0]=(words[3]<<16)+(int16_t)words[4];slots[1]=(words[6]<<16)+(int16_t)words[7];
 if(!Memories_Resolve(m,slots[0],4,4)||!Memories_Resolve(m,slots[1],4,4))return 0;
 return pc+52;
}
static inline int LekakBios_Words(MemoriesMemory *m,uint32_t address,const uint32_t *words,unsigned count){
 const uint8_t *p=Memories_Resolve(m,address,count*4,4);if(!p)return 0;
 for(unsigned i=0;i<count;i++)if(Memories_ReadLE32(p+i*4)!=words[i])return 0;
 return 1;
}
static inline int LekakBios_FlushTarget(MemoriesMemory *m,uint32_t pc,uint32_t jal){
 if((jal>>26)!=3)return 0;
 uint32_t target=((pc+4)&0xf0000000u)|((jal&0x3ffffffu)<<2);
 const uint32_t wrapper[]={0x240a00a0,0x01400008,0x24090044};
 return LekakBios_Words(m,target,wrapper,3);
}
/* Exact documented early-card IRQ delay patch. Keep the game's real copied
 * RAM continuation, represent only its installation policy. There is no retail
 * BIOS tail address: caller stores an explicit unsupported-tail software token.
 * No serial IRQ or acknowledge behavior is synthesized by recognizing it. */
static inline uint32_t LekakBios_CardEarlyPatch(MemoriesMemory *m,uint32_t pc){
 const uint8_t *p=Memories_Resolve(m,pc,96,4);if(!p)return 0;
 const uint32_t code[]={0x8c420018,0,0x8c430070,0,0x3069ffff,0x00094c00,0x8c430074,0,
  0x306affff,0x012a1821,0x24620028,0x3c0a0000,0x254a0000,0x3c090000,0x25290000,
  0x8d430000,0,0xac430000,0x254a0004,0x1549fffb,0x24420004,0x3c010001,0,0xac22dffc};
 uint32_t w[24];
 for(unsigned i=0;i<24;i++){
  w[i]=Memories_ReadLE32(p+i*4);if(i==22)continue;
  uint32_t mask=(i>=11&&i<=14)?0xffff0000u:0xffffffffu;
  if((w[i]&mask)!=code[i])return 0;
 }
 uint32_t start=(w[11]<<16)+(int16_t)w[12],end=(w[13]<<16)+(int16_t)w[14];
 const uint32_t data[]={0x3c02a001,0x2442dfac,0x00400008,0,0};
 const uint32_t continuation[]={0x8c621074,0,0x30420080,0x1040000b,0,0x8c621044,0,
  0x30420080,0x1440fffc,0,0x3c020001,0x8c42dffc,0,0x00400008,0,0x03e00008,0};
 if(end-start!=20||!LekakBios_Words(m,start,data,5)||!LekakBios_Words(m,0xa000dfac,continuation,17)
    ||!LekakBios_FlushTarget(m,pc+88,w[22]))return 0;
 return pc+84; /* Real caller executes LUI, FlushCache and the tail-token store. */
}
static inline uint32_t LekakBios_CardDelayPatch(MemoriesMemory *m,uint32_t pc){
 const uint8_t *p=Memories_Resolve(m,pc,60,4);if(!p)return 0;
 const uint32_t code[]={0x8c42016c,0,0x8c4309c8,0x3c0a0000,0x254a0000,0x3c090000,0x25290000,
  0x8d480000,0,0xac4809c8,0x254a0004,0x1549fffb,0x24420004,0,0};
 uint32_t w[15];
 for(unsigned i=0;i<15;i++){
  w[i]=Memories_ReadLE32(p+i*4);if(i==13)continue;
  uint32_t mask=(i>=3&&i<=6)?0xffff0000u:0xffffffffu;
  if((w[i]&mask)!=code[i])return 0;
 }
 uint32_t start=(w[3]<<16)+(int16_t)w[4],end=(w[5]<<16)+(int16_t)w[6];
 const uint32_t data[]={0x3c08a001,0x2508df80,0x0100f809,0,0};
 const uint32_t continuation[]={0x946f000a,0x3c080000,0x01e2c025,0x37190012,0xa479000a,
  0x24080028,0x2508ffff,0x1500fffe,0,0x03e00008,0};
 if(end-start!=20||!LekakBios_Words(m,start,data,5)||!LekakBios_Words(m,0xa000df80,continuation,11)
    ||!LekakBios_FlushTarget(m,pc+52,w[13]))return 0;
 return pc+52;
}
static inline uint32_t LekakBios_CardInfoPatch(MemoriesMemory *m,uint32_t pc){
 const uint8_t *p=Memories_Resolve(m,pc,24,4);if(!p)return 0;
 const uint32_t code[]={0x240a0009,0x8c42016c,0,0x20431988,0,0xac600000};
 for(unsigned i=0;i<6;i++)if(i!=4&&Memories_ReadLE32(p+i*4)!=code[i])return 0;
 if(!LekakBios_FlushTarget(m,pc+16,Memories_ReadLE32(p+16)))return 0;
 /* No fictitious B5B code address. The interpreter has no instruction cache;
  * suppressing the extra serial byte is recorded as policy, not card I/O. */
 return pc+24;
}
#endif
