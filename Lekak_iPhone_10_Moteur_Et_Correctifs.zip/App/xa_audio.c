/* 4-bit decoder adapted from pinned upstream src/pc/sdk/libds.c play_xa;
 * MIT license and exact upstream revision are in Engine/exec-provenance.json. */
#include "xa_audio.h"
#include <string.h>
static int floor_div(int v,int d){return v>=0?v/d:-((-v+d-1)/d);}
int LekakXa_Decode(LekakXaAudio *s,const uint8_t raw[2340]){
 static const int k0[4]={0,60,115,98},k1[4]={0,0,-52,-55};
 uint8_t coding=raw[7];
 if(coding&~5u)return -1;
 unsigned stereo=coding&1u,rate=(coding&4u)?18900:37800;
 unsigned n=stereo?2016:4032,frames=n*44100/rate;
 if(frames>LEKAK_XA_QUEUE-s->count)return 0;
 int history[2][2];memcpy(history,s->history,sizeof(history));
 int16_t pcm[4032][2];unsigned count[2]={0,0};
 for(unsigned group=0;group<18;group++){
  const uint8_t *data=raw+12+group*128;
  for(unsigned unit=0;unit<8;unit++){
   unsigned channel=stereo?(unit&1u):0,header=data[4+unit];
   unsigned shift=header&15u,filter=header>>4&3u;if(shift>12)shift=9;
   for(unsigned i=0;i<28;i++){
    int nibble=data[16+i*4+unit/2]>>((unit&1)*4)&15;if(nibble>=8)nibble-=16;
    int sample=floor_div(nibble*4096,1<<shift)+floor_div(history[channel][0]*k0[filter]+history[channel][1]*k1[filter]+32,64);
    if(sample<-32768)sample=-32768;
    if(sample>32767)sample=32767;
    history[channel][1]=history[channel][0];history[channel][0]=sample;
    unsigned at=count[channel]++;pcm[at][channel]=(int16_t)sample;
    if(!stereo)pcm[at][1]=(int16_t)sample;
   }
  }
 }
 for(unsigned i=0;i<frames;i++){
  unsigned src=(unsigned)((uint64_t)i*rate/44100),dst=(s->head+s->count+i)%LEKAK_XA_QUEUE;
  s->pcm[dst][0]=pcm[src][0];s->pcm[dst][1]=pcm[src][1];
 }
 memcpy(s->history,history,sizeof(history));s->count+=frames;s->sectors++;s->frames+=frames;return 1;
}
void LekakXa_Frame(LekakXaAudio *s,int16_t out[2]){
 out[0]=out[1]=0;if(!s->count)return;
 out[0]=s->pcm[s->head][0];out[1]=s->pcm[s->head][1];s->head=(s->head+1)%LEKAK_XA_QUEUE;s->count--;s->consumed++;
}
