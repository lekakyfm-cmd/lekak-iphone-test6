#ifndef LEKAK_GPU_IO_H
#define LEKAK_GPU_IO_H
#include <stdint.h>
#include "pc/render/packets.h"
#define LEKAK_GPU_PACKET_WORDS 256u
typedef struct LekakGpuIo {
 uint32_t status,read_latch,attributes[6],display_start,horizontal,vertical;
 uint32_t words[LEKAK_GPU_PACKET_WORDS],count,expected,gp0_commands,gp1_commands,reads;
 uint32_t transfer_mode,transfer_x,transfer_y,transfer_width,transfer_pixels,transfer_position;
} LekakGpuIo;
/* Single-threaded functional adapter to the pinned software rasterizer.
 * GP0 drawing and synchronous CPU/VRAM pixel transfers. Video events are
 * separate; this adapter does not provide scanout or physical GPU timing. */
void LekakGpuIo_Init(LekakGpuIo *);
int LekakGpuIo_Read(LekakGpuIo *,uint32_t address,uint32_t *value);
/* 0 = not a GPU port, 1 = handled, -1 = unsupported command. */
int LekakGpuIo_Write(LekakGpuIo *,uint32_t address,uint32_t value);
/* Validate complete drawing streams before DMA mutation. Includes bounded
 * flat/Gouraud polylines, retaining the pinned backend's packet semantics. */
MemoriesGpuResult LekakGpuIo_ValidateDrawing(const uint32_t *,size_t);
#endif
