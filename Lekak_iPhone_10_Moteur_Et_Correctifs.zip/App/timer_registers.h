#ifndef LEKAK_TIMER_REGISTERS_H
#define LEKAK_TIMER_REGISTERS_H
#include <stdint.h>
/* Functional root-counter model. Inputs are explicit nominal clock/blank
 * events, not wall time. Instruction timing and reset latency are approximate. */
typedef struct LekakTimerRegisters {
 uint32_t mode[3],target[3],count[3],reads,writes,irq_events[3];
 unsigned hold[3],divider[3],fired[3];
 int blank[2],released[2];
} LekakTimerRegisters;
static inline int LekakTimer_Index(uint32_t address,unsigned bytes,int *reg){
 uint32_t a=address&0x1fffffffu;
 if((bytes!=2&&bytes!=4)||a<0x1f801100u||a>0x1f801128u)return -1;
 uint32_t offset=a-0x1f801100u;*reg=(int)(offset&15u);
 if(*reg!=0&&*reg!=4&&*reg!=8)return -1;
 return (int)(offset>>4);
}
static inline int LekakTimer_Write(LekakTimerRegisters *t,uint32_t a,unsigned bytes,uint32_t v){
 int reg,i=LekakTimer_Index(a,bytes,&reg);if(i<0)return 0;
 if(reg==0){t->count[i]=v&0xffffu;t->hold[i]=2;}
 else if(reg==4){t->mode[i]=(v&0x3ffu)|0x400u;t->count[i]=0;t->hold[i]=2;t->divider[i]=t->fired[i]=0;if(i<2)t->released[i]=0;}
 else t->target[i]=v&0xffffu;
 t->writes++;return 1;
}
static inline int LekakTimer_Read(LekakTimerRegisters *t,uint32_t a,unsigned bytes,uint32_t *v){
 int reg,i=LekakTimer_Index(a,bytes,&reg);if(i<0)return 0;
 *v=reg==0?t->count[i]:(reg==4?t->mode[i]:t->target[i]);
 if(reg==4)t->mode[i]&=~0x1800u;
 t->reads++;return 1;
}
static inline void LekakTimer_Blank(LekakTimerRegisters *t,unsigned i,int active){
 int rising=active&&!t->blank[i];t->blank[i]=active;
 if(rising&&(t->mode[i]&1)){
  unsigned sync=(t->mode[i]>>1)&3;
  if(sync==1||sync==2){t->count[i]=0;t->hold[i]=2;}
  if(sync==3)t->released[i]=1;
 }
}
static inline unsigned LekakTimer_Tick(LekakTimerRegisters *t,unsigned i){
 uint32_t mode=t->mode[i];unsigned sync=(mode>>1)&3;
 if(mode&1){
  if(i==2){if(sync==0||sync==3)return 0;}
  else if((sync==0&&t->blank[i])||(sync==2&&!t->blank[i])||(sync==3&&!t->released[i]))return 0;
 }
 if(t->hold[i]){t->hold[i]--;return 0;}
 if((mode&8)&&t->count[i]==t->target[i]){t->count[i]=0;t->hold[i]=1;}
 else t->count[i]=(t->count[i]+1)&0xffffu;
 unsigned target=t->count[i]==t->target[i],overflow=t->count[i]==0xffffu;
 if(target)t->mode[i]|=0x800;
 if(overflow)t->mode[i]|=0x1000;
 if(!((target&&(mode&0x10))||(overflow&&(mode&0x20)))||(!(mode&0x40)&&t->fired[i]))return 0;
 t->fired[i]=1;
 if(mode&0x80){t->mode[i]^=0x400;if(t->mode[i]&0x400)return 0;}
 /* Pulse request returns inactive immediately in this functional model. */
 t->irq_events[i]++;return 1u<<(4+i);
}
static inline unsigned LekakTimer_CpuCycle(LekakTimerRegisters *t){
 unsigned irq=0;
 for(unsigned i=0;i<2;i++)if(!(t->mode[i]&0x100))irq|=LekakTimer_Tick(t,i);
 if(t->mode[2]&0x200){if(++t->divider[2]==8){t->divider[2]=0;irq|=LekakTimer_Tick(t,2);}}
 else irq|=LekakTimer_Tick(t,2);
 return irq;
}
#endif
