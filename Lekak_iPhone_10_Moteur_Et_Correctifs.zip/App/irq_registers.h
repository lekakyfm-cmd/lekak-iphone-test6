#ifndef LEKAK_IRQ_REGISTERS_H
#define LEKAK_IRQ_REGISTERS_H
#include <stdint.h>
/* Register model; executor may supply device edges and functional IRQ hooks.
 * No CP0 or cycle-accurate exception delivery.
 * Undefined upper bits read as zero. Reset starts with no requests/mask. */
typedef struct LekakIrqRegisters { uint32_t status,mask,reads,writes,dpcr,dicr; } LekakIrqRegisters;
static inline int LekakIrq_Index(uint32_t address,unsigned bytes) {
 uint32_t physical=address&0x1fffffffu;
 if((bytes==1||bytes==2||bytes==4)&&!(physical&(bytes-1))&&physical>=0x1f8010f0u&&physical+bytes<=0x1f8010f8u)return physical<0x1f8010f4u?2:3;
 if(bytes!=2&&bytes!=4)return -1;
 if(physical==0x1f801070u)return 0;
 if(physical==0x1f801074u)return 1;
 if(bytes==4&&physical==0x1f8010f0u)return 2;
 if(bytes==4&&physical==0x1f8010f4u)return 3;
 return -1;
}
static inline int LekakIrq_Read(LekakIrqRegisters *irq,uint32_t address,unsigned bytes,uint32_t *value){
 int index=LekakIrq_Index(address,bytes);if(index<0)return 0;
 uint32_t result=index==0?irq->status:(index==1?irq->mask:(index==2?irq->dpcr:irq->dicr));
 if(index>=2)result>>=(address&3u)*8;
 if(bytes<4)result&=(1u<<(bytes*8))-1;
 *value=result;irq->reads++;return 1;
}
static inline int LekakIrq_Write(LekakIrqRegisters *irq,uint32_t address,unsigned bytes,uint32_t value){
 int index=LekakIrq_Index(address,bytes);if(index<0)return 0;
 if(index==1)irq->mask=value&0x7ffu;
 else if(index==0)irq->status&=value&0x7ffu; /* Zero acknowledges; one leaves unchanged. */
 else if(index==2){unsigned shift=(address&3u)*8;uint32_t mask=bytes==4?0xffffffffu:((1u<<(bytes*8))-1)<<shift;irq->dpcr=(irq->dpcr&~mask)|((value<<shift)&mask);}
 else {
  uint32_t old=irq->dicr;
  unsigned shift=(address&3u)*8;uint32_t mask=bytes==4?0xffffffffu:((1u<<(bytes*8))-1)<<shift;
  value=(value<<shift)&mask;
  irq->dicr=(old&0x00ff807fu&~mask)|(value&0x00ff807fu)|((old&0x7f000000u)&~value);
  if((irq->dicr&0x8000u)||((irq->dicr&0x800000u)&&((irq->dicr>>24)&(irq->dicr>>16)&0x7fu)))irq->dicr|=0x80000000u;
  if(!(old&0x80000000u)&&(irq->dicr&0x80000000u))irq->status|=8;
 }
 irq->writes++;return 1;
}
#endif
