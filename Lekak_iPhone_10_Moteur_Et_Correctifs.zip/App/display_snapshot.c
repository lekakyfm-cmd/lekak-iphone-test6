#include "display_snapshot.h"
int LekakDisplay_CopyRGBA(const uint16_t *vram,uint32_t status,uint32_t origin,uint32_t vertical,uint8_t *out,size_t capacity,unsigned *width,unsigned *height){
 static const unsigned widths[]={256,320,512,640};
 unsigned w=(status&0x10000u)?368:widths[status>>17&3u];
 unsigned start=vertical&1023u,end=vertical>>10&1023u;
 if(!vram||!out||!width||!height||(status&0x00400000u)||end<=start||end-start>512)return 0;
 unsigned h=end-start;if(capacity<(size_t)w*h*4)return 0;
 unsigned sx=origin&1023u,sy=origin>>10&511u;
 for(unsigned y=0;y<h;y++)for(unsigned x=0;x<w;x++){
  uint8_t *p=out+((size_t)y*w+x)*4;
  if(status&0x800000u)p[0]=p[1]=p[2]=0;
  else if(status&0x200000u){
   for(unsigned c=0;c<3;c++){unsigned b=(sx*2+x*3+c)&2047u;uint16_t word=vram[((sy+y)&511u)*1024+b/2];p[c]=(uint8_t)(word>>((b&1u)*8));}
  }else {
   uint16_t word=vram[((sy+y)&511u)*1024+((sx+x)&1023u)];
   for(unsigned c=0;c<3;c++)p[c]=(uint8_t)(((word>>(c*5)&31u)*255u)/31u);
  }
  p[3]=255;
 }
 *width=w;*height=h;return 1;
}
