/* Adapted from the upstream MIT-licensed PC overlay interpreter, revision
 * 0d78202729967a5bbdbc886aa128e48e82bef7ac. See Engine/LICENSE and exec-provenance.json.
 * Fixed host dereferences and native function casts are removed. This is a
 * bounded execution/debugging aid, not a full PS1 emulator or playable game. */
#include "guest_exec.h"
#include "irq_registers.h"
#include "timer_registers.h"
#include "gpu_io.h"
#include "display_timing.h"
#include "bios_patches.h"
#include "pad_driver.h"
#include "cpu_timing.h"
#include "joy_control.h"
#include "cd_registers.h"
#include "spu_config.h"
#include "bios_events.h"
#include "mdec.h"
#include "pc/compat/gte.h"
#include "pc/render/packets.h"
#include <setjmp.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <limits.h>
typedef struct LekakExecSession {
 LekakExecResult owned_result;
 uint64_t total_steps;
 int resumable,stopped;
 LekakExecAudioSink audio_sink;void *audio_context;
 uint32_t r[32],hi,lo,pc,steps,budget,pending_reg,pending_value;
 int pending, interrupts_enabled; MemoriesMemory *memory; LekakExecResult *out; jmp_buf escape;
 LekakIrqRegisters irq;
 LekakTimerRegisters timers;
 LekakGpuIo gpu;
 LekakMdec mdec;
 LekakDisplayTiming video;
 uint32_t dma_channels[7][3];
 uint32_t interrupt_hook;
 uint32_t interrupt_chains[4],clear_counter[4],clear_pad;
 int cd_iso_driver_registered;
 uint32_t memory_megabytes;
 uint32_t saved_r[32],saved_hi,saved_lo,saved_pc,saved_pending_reg,saved_pending_value;
 int irq_active,saved_pending,saved_interrupts_enabled;
 uint32_t cp0_sr,saved_cp0_sr;
 int pad_ack_patch;
 int pad_poll_enabled,pad_error_patch;
 LekakPadDriver pad;
 LekakJoyControl joy;
 LekakCdRegisters cd;
 unsigned cd_irq_line;
 uint32_t common_delay,cd_bus_delay,spu_bus_delay;
 LekakSpuConfig spu;
 LekakBiosEvents events;
 uint32_t event_r[32],event_hi,event_lo,event_pc,event_pending_reg,event_pending_value,event_sr;
 uint32_t event_mask;
 int event_active,event_pending,event_interrupts;
 uint32_t timer_worker_todo;int timer_worker_done;

 int card_initialized,card_pad_shared,card_running;
 int bu_driver_registered;
 uint32_t irq_priority,irq_node,irq_hops;
 int pad_worker_done;
} State;
static void fail(State *,uint32_t,const char *,uint32_t);
static void clock_cycle(State *s){
 s->irq.status|=LekakDisplay_Cycle(&s->video,&s->timers,&s->gpu);
 if(s->spu.phase==767u){
  LekakCd_AudioFrame(&s->cd,s->spu.dsp.cd_input);
 }
 int sample=s->spu.phase==767u;
 LekakSpu_Cycle(&s->spu);
 if(sample&&s->audio_sink){
  int active=!!(s->spu.control&0x8000u);
  s->audio_sink(s->audio_context,active?s->spu.dsp.last[0]:0,active?s->spu.dsp.last[1]:0);
 }
 if(LekakCd_Cycle(&s->cd)<0)fail(s,s->pc,"CD sector image read/format unsupported",s->cd.next_lba);
 unsigned line=LekakCd_Irq(&s->cd);
 if(line&&!s->cd_irq_line)s->irq.status|=line;
 s->cd_irq_line=line;
}
static void fail(State *s,uint32_t pc,const char *reason,uint32_t detail) {
 s->out->pc=pc;s->out->detail=detail;
 snprintf(s->out->reason,sizeof(s->out->reason),"%s",reason);longjmp(s->escape,1);
}
static void *span(State *s,uint32_t a,size_t n,size_t align) {
 void *p=Memories_Resolve(s->memory,a,n,align);
 if(!p)fail(s,s->pc,"Unimplemented memory or invalid alignment",a);
 return p;
}
#define LEKAK_EVENT_RETURN 0xffffffd8u
#define LEKAK_TIMER_WORKER_RETURN 0xffffffd4u
static void event_next(State *s){
 while(s->event_mask){
  unsigned i=0;while(!(s->event_mask&(1u<<i)))i++;
  s->event_mask&=~(1u<<i);LekakBiosEvent *e=&s->events.slots[i];
  if(!e->used||!e->enabled||e->mode!=0x1000u)continue;
  span(s,e->callback,4,4);s->r[31]=LEKAK_EVENT_RETURN;s->pc=e->callback;s->out->bios_event_callbacks++;return;
 }
 memcpy(s->r,s->event_r,sizeof(s->r));s->hi=s->event_hi;s->lo=s->event_lo;s->pc=s->event_pc;
 s->pending=s->event_pending;s->pending_reg=s->event_pending_reg;s->pending_value=s->event_pending_value;
 s->interrupts_enabled=s->event_interrupts;s->cp0_sr=s->event_sr;s->event_active=0;
}
static void event_deliver(State *s,uint32_t c,uint32_t spec,uint32_t resume){
 uint32_t mask=0;
 for(unsigned i=0;i<16;i++){
  LekakBiosEvent *e=&s->events.slots[i];
  if(e->used&&e->enabled&&e->mode==0x1000u&&e->class_id==c&&e->spec==spec)mask|=1u<<i;
 }
 if(mask&&s->event_active)fail(s,s->pc,"Nested BIOS event callback unsupported",c);
 LekakEvent_Deliver(&s->events,c,spec,1);
 if(!mask){s->pc=resume;return;}
 memcpy(s->event_r,s->r,sizeof(s->r));s->event_hi=s->hi;s->event_lo=s->lo;s->event_pc=resume;
 s->event_pending=s->pending;s->event_pending_reg=s->pending_reg;s->event_pending_value=s->pending_value;
 s->event_interrupts=s->interrupts_enabled;s->event_sr=s->cp0_sr;s->interrupts_enabled=0;s->cp0_sr&=~1u;
 s->pending=0;s->event_mask=mask;s->event_active=1;event_next(s);
}
static void restore_irq(State *s){
 if(!s->irq_active)fail(s,s->pc,"ReturnFromException outside a hardware IRQ",s->pc);
 memcpy(s->r,s->saved_r,sizeof(s->r));s->hi=s->saved_hi;s->lo=s->saved_lo;s->pc=s->saved_pc;
 s->pending=s->saved_pending;s->pending_reg=s->saved_pending_reg;s->pending_value=s->saved_pending_value;
 s->interrupts_enabled=s->saved_interrupts_enabled;s->irq_active=0;s->event_active=0;s->event_mask=0;s->out->irq_returns++;
 s->cp0_sr=s->saved_cp0_sr;
}
static void irq_exit_hook(State *s){
 if(!s->interrupt_hook)fail(s,s->pc,"No software interrupt exit context installed",s->irq.status&s->irq.mask);
 const uint8_t *hook=span(s,s->interrupt_hook,48,4);
 uint32_t target=Memories_ReadLE32(hook);
 if(target!=LEKAK_EXCEPTION_RETURN)span(s,target,4,4);
 s->r[31]=target;s->r[29]=Memories_ReadLE32(hook+4);s->r[30]=Memories_ReadLE32(hook+8);
 for(unsigned i=0;i<8;i++)s->r[16+i]=Memories_ReadLE32(hook+12+i*4);
 s->r[28]=Memories_ReadLE32(hook+44);s->r[2]=1;s->pc=target;
}
static void irq_next(State *s){
 while(s->irq_priority<4){
  if(s->irq_priority==1){
   if(!s->timer_worker_done){
    s->timer_worker_done=1;s->timer_worker_todo=0;
    for(unsigned i=0;i<16;i++){
     LekakBiosEvent *e=&s->events.slots[i];
     if(e->used&&e->enabled&&e->class_id>=0xf2000000u&&e->class_id<=0xf2000003u&&e->spec==2){
      unsigned t=e->class_id-0xf2000000u,bit=t==3?1u:1u<<(4+t);
      if(s->irq.status&s->irq.mask&bit)s->timer_worker_todo|=1u<<t;
     }
    }
   }
   if(s->timer_worker_todo){
    unsigned t=0;while(!(s->timer_worker_todo&(1u<<t)))t++;
    s->timer_worker_todo&=~(1u<<t);
    unsigned bit=t==3?1u:1u<<(4+t);
    if(s->clear_counter[t])s->irq.status&=~bit;
    event_deliver(s,0xf2000000u+t,2,LEKAK_TIMER_WORKER_RETURN);return;
   }
  }
  if(s->irq_priority==2&&!s->pad_worker_done){
   s->pad_worker_done=1;
   if(s->pad.started&&(s->irq.status&s->irq.mask&1u)){
    LekakPad_InputAt(&s->pad,s->video.frames);
    if(!LekakPad_Poll(&s->pad,s->memory,s->pad_poll_enabled))fail(s,s->pc,"Invalid pad receive buffers",0);
    if(s->clear_pad&&!s->pad_ack_patch)s->irq.status&=~1u;
   }
  }
  if(!s->irq_node){s->irq_priority++;if(s->irq_priority<4)s->irq_node=s->interrupt_chains[s->irq_priority];continue;}
  if(++s->irq_hops>256)fail(s,s->pc,"Cyclic or excessive interrupt dispatch chain",s->irq_node);
  const uint8_t *node=span(s,s->irq_node,16,4);uint32_t first=Memories_ReadLE32(node+8);
  if(!first){s->irq_node=Memories_ReadLE32(node);continue;}
  span(s,first,4,4);s->r[31]=LEKAK_CHAIN_FIRST_RETURN;s->pc=first;s->out->irq_chain_calls++;return;
 }
 irq_exit_hook(s);
}
static void enter_irq(State *s){
 memcpy(s->saved_r,s->r,sizeof(s->r));s->saved_hi=s->hi;s->saved_lo=s->lo;s->saved_pc=s->pc;
 s->saved_pending=s->pending;s->saved_pending_reg=s->pending_reg;s->saved_pending_value=s->pending_value;
 s->saved_interrupts_enabled=s->interrupts_enabled;s->interrupts_enabled=0;s->pending=0;s->irq_active=1;
 s->saved_cp0_sr=s->cp0_sr;s->cp0_sr&=~1u;
 s->irq_priority=0;s->irq_node=s->interrupt_chains[0];s->irq_hops=0;s->pad_worker_done=0;s->timer_worker_done=0;
 s->r[29]=0x8000fff0u;s->out->irq_entries++;irq_next(s);
}
static void irq_chain_return(State *s){
 if(!s->irq_active||!s->irq_node)fail(s,s->pc,"IRQ chain return outside a callback",s->pc);
 const uint8_t *node=span(s,s->irq_node,16,4);
 uint32_t second=Memories_ReadLE32(node+4);
 if(s->pc==LEKAK_CHAIN_FIRST_RETURN&&s->r[2]&&second){
  span(s,second,4,4);s->r[4]=s->r[2];s->r[31]=LEKAK_CHAIN_SECOND_RETURN;s->pc=second;s->out->irq_chain_calls++;return;
 }
 s->irq_node=Memories_ReadLE32(node);irq_next(s);
}
static int dma_index(uint32_t a,unsigned *channel,unsigned *reg){
 a&=0x1fffffffu;if(a<0x1f801080u||a>0x1f8010e8u||(a&3u))return 0;
 unsigned offset=a-0x1f801080u;*channel=offset>>4;*reg=(offset&15u)>>2;
 return *reg<3;
}
static void dma_completion(State *s,unsigned channel){
 uint32_t old=s->irq.dicr;
 if(old&(1u<<(16+channel)))s->irq.dicr|=1u<<(24+channel);
 s->irq.dicr&=~0x80000000u;
 if((s->irq.dicr&0x8000u)||((s->irq.dicr&0x800000u)&&((s->irq.dicr>>24)&(s->irq.dicr>>16)&0x7fu)))s->irq.dicr|=0x80000000u;
 if(!(old&0x80000000u)&&(s->irq.dicr&0x80000000u))s->irq.status|=8;
}
static void otc_dma(State *s){
 uint32_t *d=s->dma_channels[6];
 if((d[2]&0x11000000u)!=0x11000000u||!(s->irq.dpcr&0x08000000u))return;
 if(d[2]&0x40000000u)fail(s,s->pc,"OTC cache snooping unsupported",d[2]);
 uint32_t n=d[1]&0xffffu;if(!n)n=65536;
 if(!s->resumable&&n>s->budget-s->steps)fail(s,s->pc,"OTC DMA exceeds diagnostic budget",n);
 uint32_t low=d[0]-4*(n-1);
 uint8_t *ram=span(s,low,n*4,4); /* Validate entire list before any writes. */
 for(uint32_t i=0;i<n;i++)Memories_WriteLE32(ram+i*4,i?low+(i-1)*4:0xffffffu);
 d[0]=(low-4)&0xffffffu;d[2]&=~0x11000000u;
 s->steps+=n;for(uint32_t i=0;i<n;i++)clock_cycle(s);
 s->out->otc_dma_transfers++;s->out->otc_dma_words+=n;dma_completion(s,6);
}
static void mdec_dma(State *s,unsigned channel){
 uint32_t *d=s->dma_channels[channel],control=d[2];
 if(!(control&0x1000000u)||!(s->irq.dpcr&(channel?0x80u:8u)))return;
 if(control!=(channel?0x01000200u:0x01000201u))fail(s,s->pc,"MDEC DMA control unsupported",control);
 uint32_t blocks=d[1]>>16,words=d[1]&0xffffu;
 if(!blocks||!words||words>32)fail(s,s->pc,"MDEC DMA block count/size unsupported",d[1]);
 uint64_t total=(uint64_t)blocks*words;
 if(!s->resumable&&total>s->budget-s->steps)fail(s,s->pc,"MDEC DMA exceeds diagnostic budget",(uint32_t)total);
 uint32_t n=(uint32_t)total;uint8_t *ram=span(s,d[0],n*4,4);
 int result=channel?LekakMdec_DmaRead(&s->mdec,ram,n):LekakMdec_DmaWrite(&s->mdec,ram,n);
 if(result<0)fail(s,s->pc,"MDEC DMA data/count unsupported",n);
 if(!result)return;
 d[0]=(d[0]+n*4)&0xffffffu;d[1]&=0xffffu;d[2]&=~0x11000000u;
 s->steps+=n;for(uint32_t i=0;i<n;i++)clock_cycle(s);
 s->out->mdec_dma_transfers[channel]++;s->out->mdec_dma_words[channel]+=n;dma_completion(s,channel);
}
static void gpu_dma(State *s){
 uint32_t *d=s->dma_channels[2],control=d[2];
 if(!(control&0x1000000u)||!(s->irq.dpcr&0x800u)||!(s->gpu.status&0x02000000u))return;
 if(control==0x01000201u||control==0x01000200u){
  uint32_t blocks=d[1]>>16,block_words=d[1]&0xffffu;
  uint32_t mode=(control&1u)?1u:2u;
  if(!blocks||!block_words)fail(s,s->pc,"GPU DMA zero block count unsupported",d[1]);
  uint64_t total=(uint64_t)blocks*block_words;
  if(s->gpu.transfer_mode!=mode||s->gpu.count)fail(s,s->pc,"GPU DMA without matching image transfer",control);
  uint32_t remaining=(s->gpu.transfer_pixels-s->gpu.transfer_position+1)/2;
  if(total>remaining)fail(s,s->pc,"GPU DMA exceeds remaining image words",(uint32_t)total);
  if(!s->resumable&&total>s->budget-s->steps)fail(s,s->pc,"GPU DMA exceeds diagnostic budget",(uint32_t)total);
  uint32_t n=(uint32_t)total;uint8_t *ram=span(s,d[0],n*4,4);
  for(uint32_t i=0;i<n;i++){
   if(mode==1)LekakGpuIo_Write(&s->gpu,0x1f801810u,Memories_ReadLE32(ram+i*4));
   else {uint32_t value;LekakGpuIo_Read(&s->gpu,0x1f801810u,&value);Memories_WriteLE32(ram+i*4,value);}
  }
  d[0]=(d[0]+n*4)&0xffffffu;d[1]&=0xffffu;d[2]&=~0x11000000u;
  s->steps+=n;for(uint32_t i=0;i<n;i++)clock_cycle(s);
  s->out->gpu_dma_transfers++;s->out->gpu_dma_words+=n;dma_completion(s,2);return;
 }
 if((control&0x701u)!=0x401u)fail(s,s->pc,"Unsupported GPU DMA mode",control);
 if(s->gpu.count)fail(s,s->pc,"GPU DMA starts in an incomplete CPU packet",s->gpu.count);
 uint32_t *words=malloc(65536*sizeof(*words));if(!words)fail(s,s->pc,"GPU DMA allocation failed",0);
 size_t count=0;MemoriesGpuResult result=Memories_GpuCollect(s->memory,d[0],words,65536,16384,&count);
 if(result!=MEMORIES_GPU_OK){free(words);fail(s,s->pc,"Invalid or excessive GPU DMA list",result);}
 if(!s->resumable&&count>s->budget-s->steps){free(words);fail(s,s->pc,"GPU DMA exceeds diagnostic budget",(uint32_t)count);}
 result=LekakGpuIo_ValidateDrawing(words,count);
 if(result!=MEMORIES_GPU_OK){free(words);fail(s,s->pc,"Unsupported GPU DMA packet",result);}
 for(size_t i=0;i<count;i++)if(LekakGpuIo_Write(&s->gpu,0x1f801810u,words[i])!=1){free(words);fail(s,s->pc,"GPU DMA backend rejected packet",(uint32_t)i);}
 free(words);s->steps+=(uint32_t)count;
 for(size_t i=0;i<count;i++)clock_cycle(s);
 d[0]=0xffffffu;d[2]&=~0x11000000u;
 s->out->gpu_dma_transfers++;s->out->gpu_dma_words+=(uint32_t)count;
 dma_completion(s,2);
}
static void cd_dma(State *s){
 uint32_t *d=s->dma_channels[3];
 if(!(d[2]&0x1000000u)||!(s->irq.dpcr&0x8000u))return;
 if((d[2]&0x11000707u)!=0x11000000u||d[2]&0x40000100u)fail(s,s->pc,"CD DMA mode unsupported",d[2]);
 uint32_t n=d[1]&0xffffu;if(!n)n=65536;
 if(s->cd.fifo_pos>s->cd.fifo_size||n>(s->cd.fifo_size-s->cd.fifo_pos)/4)fail(s,s->pc,"CD DMA exceeds available sector FIFO",n);
 if(!s->resumable&&n>s->budget-s->steps)fail(s,s->pc,"CD DMA exceeds diagnostic budget",n);
 uint8_t *dst=span(s,d[0],n*4,4); /* Validate all RAM/FIFO before mutation. */
 memcpy(dst,s->cd.fifo+s->cd.fifo_pos,n*4);s->cd.fifo_pos+=n*4;s->cd.data_bytes+=n*4;
 d[0]=(d[0]+n*4)&0xffffffu;d[2]&=~0x11000000u;
 s->steps+=n;for(uint32_t i=0;i<n;i++)clock_cycle(s);
 s->out->cd_dma_transfers++;s->out->cd_dma_words+=n;dma_completion(s,3);
}
static void spu_dma(State *s){
 uint32_t *d=s->dma_channels[4];
 if(!(d[2]&0x1000000u)||!(s->irq.dpcr&0x80000u))return;
 if(d[2]!=0x01000201u&&d[2]!=0x01000200u)fail(s,s->pc,"SPU DMA control unsupported",d[2]);
 uint32_t blocks=d[1]>>16,words=d[1]&0xffffu;
 if(words!=16||!blocks)fail(s,s->pc,"SPU DMA block count/size unsupported",d[1]);
 uint32_t n=words*blocks,mode=(d[2]&1u)?0x20u:0x30u;
 if(s->spu.ram_control!=4||s->spu.fifo_count||(s->spu.control&0x30u)!=mode)
  fail(s,s->pc,"SPU DMA before ready transfer mode",s->spu.status);
 if(mode==0x30u&&s->spu_bus_delay!=0x220931e1u)fail(s,s->pc,"SPU DMA read bus setting unsupported",s->spu_bus_delay);
 if(!s->resumable&&n>s->budget-s->steps)fail(s,s->pc,"SPU DMA exceeds diagnostic budget",n);
 uint8_t *ram=span(s,d[0],n*4,4); /* Entire range checked before copy. */
 if((s->spu.status&0x30u)!=mode)return; /* DREQ waits for delayed mode. */
 s->spu.status|=0x400u;
 for(uint32_t i=0;i<n*4;i++){
  uint32_t at=(s->spu.transfer_address+i)&0x7ffffu;
  if(mode==0x20u)s->spu.ram[at]=ram[i];else ram[i]=s->spu.ram[at];
 }
 s->spu.transfer_address=(s->spu.transfer_address+n*4)&0x7ffffu;
 d[0]=(d[0]+n*4)&0xffffffu;d[1]&=0xffffu;d[2]&=~0x11000000u;
 s->spu.status&=~0x400u;s->steps+=n;for(uint32_t i=0;i<n;i++)clock_cycle(s);
 s->out->spu_dma_transfers++;s->out->spu_dma_words+=n;dma_completion(s,4);
}
static uint32_t l32(State *s,uint32_t a){uint32_t mv;int mr=LekakMdec_Read(&s->mdec,a,&mv);if(mr<0)fail(s,s->pc,"MDEC read unavailable or malformed stream",a);if(mr)return mv;if((a&0x1fffffffu)==0x1f801014u)return s->spu_bus_delay;if((a&0x1fffffffu)==0x1f801018u)return s->cd_bus_delay;if((a&0x1fffffffu)==0x1f801020u)return s->common_delay;uint32_t v;unsigned channel,reg;if(dma_index(a,&channel,&reg))return s->dma_channels[channel][reg];if(LekakIrq_Read(&s->irq,a,4,&v)||LekakTimer_Read(&s->timers,a,4,&v)||LekakGpuIo_Read(&s->gpu,a,&v))return v;return Memories_ReadLE32(span(s,a,4,4));}
static uint16_t l16(State *s,uint32_t a){
 uint32_t v;
 if((a&0x1fffffffu)==0x1f801802u){if(LekakCd_ReadData(&s->cd,2,&v)<0)fail(s,s->pc,"CD data FIFO empty",a);s->cd.reads++;return (uint16_t)v;}
 int spu=LekakSpu_Read(&s->spu,a,2,&v);
 if(spu<0)fail(s,s->pc,"SPU read register/width unsupported",a);
 if(spu)return (uint16_t)v;
 if(LekakIrq_Read(&s->irq,a,2,&v)||LekakTimer_Read(&s->timers,a,2,&v)||LekakJoy_Read(&s->joy,a,2,&v))return (uint16_t)v;
 uint8_t *p=span(s,a,2,2);return p[0]|((uint16_t)p[1]<<8);
}
static uint8_t l8(State *s,uint32_t a){uint32_t iv;if(LekakIrq_Read(&s->irq,a,1,&iv))return (uint8_t)iv;uint8_t v;int cd=LekakCd_Read(&s->cd,a,&v);if(cd<0)fail(s,s->pc,"CD register read unsupported or FIFO empty",a);if(cd)return v;return *(uint8_t*)span(s,a,1,1);}
static void s32(State *s,uint32_t a,uint32_t v){
 int mr=LekakMdec_Write(&s->mdec,a,v);if(mr<0)fail(s,s->pc,"MDEC command/parameter unsupported",v);if(mr)return;
 if((a&0x1fffffffu)==0x1f801014u){
  if(v!=0x220931e1u&&v!=0x200931e1u)fail(s,s->pc,"SPU bus delay setting unsupported",v);
  s->spu_bus_delay=v;return; /* Configuration, not SBUS latency. */
 }
 if((a&0x1fffffffu)==0x1f801018u){
  if(v!=0x20843u&&v!=0x20943u)fail(s,s->pc,"CD bus delay configuration unsupported",v);
  s->cd_bus_delay=v;return; /* Configuration only, no SBUS cycle accuracy. */
 }
 if((a&0x1fffffffu)==0x1f801020u){
  if(v!=0x1323u&&v!=0x1325u&&v!=0x31125u)fail(s,s->pc,"COMMON_DELAY configuration unsupported",v);
  s->common_delay=v;return; /* Record supported configuration; bus timing partial. */
 }
 unsigned channel,reg;
 if(dma_index(a,&channel,&reg)){
  if(reg==2&&(v&0x1000000u)&&channel!=0&&channel!=1&&channel!=2&&channel!=3&&channel!=4&&channel!=6)fail(s,s->pc,"DMA transfer not implemented",channel);
  s->dma_channels[channel][reg]=reg==0?v&0xffffffu:(channel==6&&reg==2?(v&0x51000000u)|2u:v);
  if(channel<2&&reg==2)mdec_dma(s,channel);
  if(channel==2&&reg==2)gpu_dma(s);
  if(channel==3&&reg==2)cd_dma(s);
  if(channel==4&&reg==2)spu_dma(s);
  if(channel==6&&reg==2)otc_dma(s);
  return;
 }
 if(LekakIrq_Write(&s->irq,a,4,v)||LekakTimer_Write(&s->timers,a,4,v))return;
 int result=LekakGpuIo_Write(&s->gpu,a,v);
 if(result<0)fail(s,s->pc,"GPU command not implemented",v);
 if(result)return;
 Memories_WriteLE32(span(s,a,4,4),v);
}
static void s16(State *s,uint32_t a,uint16_t v){
 int spu=LekakSpu_Write(&s->spu,a,2,v);
 if(spu<0)fail(s,s->pc,"SPU write register/mode unsupported",a);
 if(spu)return;
 if(LekakIrq_Write(&s->irq,a,2,v)||LekakTimer_Write(&s->timers,a,2,v))return;
 int joy=LekakJoy_Write(&s->joy,a,2,v);if(joy<0)fail(s,s->pc,"JOY serial control mode not implemented",v);if(joy)return;
 uint8_t *p=span(s,a,2,2);p[0]=(uint8_t)v;p[1]=(uint8_t)(v>>8);
}
static void s8(State *s,uint32_t a,uint8_t v){if(LekakIrq_Write(&s->irq,a,1,v))return;int cd=LekakCd_Write(&s->cd,a,v);if(cd<0)fail(s,s->pc,"CD register write or command unsupported",((a&3u)<<24)|(s->cd.index<<16)|v);if(cd){unsigned line=LekakCd_Irq(&s->cd);if(line&&!s->cd_irq_line)s->irq.status|=line;s->cd_irq_line=line;return;}*(uint8_t*)span(s,a,1,1)=v;}
static uint32_t checked_add(State *s,uint32_t pc,uint32_t a,uint32_t b){
 int64_t n=(int64_t)(int32_t)a+(int32_t)b;if(n<INT32_MIN||n>INT32_MAX)fail(s,pc,"Signed arithmetic overflow",0);return (uint32_t)n;
}
static uint32_t checked_sub(State *s,uint32_t pc,uint32_t a,uint32_t b){
 int64_t n=(int64_t)(int32_t)a-(int32_t)b;if(n<INT32_MIN||n>INT32_MAX)fail(s,pc,"Signed arithmetic overflow",0);return (uint32_t)n;
}
static int control(uint32_t ins){unsigned op=ins>>26,fn=ins&63;return (op==0&&(fn==8||fn==9))||(op>=1&&op<=7);}
static void trace(State *s,uint32_t pc,uint32_t ins){

 if(!s->resumable&&s->steps>=s->budget)fail(s,pc,"Instruction budget reached",s->steps);
 s->pc=pc;s->steps++;s->out->instruction=ins;
 clock_cycle(s);
 unsigned index=s->out->trace_count++%LEKAK_EXEC_TRACE;
 s->out->trace_pc[index]=pc;s->out->trace_ins[index]=ins;
}
static void plain(State *s, uint32_t pc,uint32_t ins)
{
    uint32_t a, word;
    unsigned op = ins >> 26, rs = ins >> 21 & 31, rt = ins >> 16 & 31, rd = ins >> 11 & 31, sa = ins >> 6 & 31,
             fn = ins & 63;
    int32_t im = (int16_t)ins;
    uint64_t up;
    int64_t sp;
    if (!ins) return;
    if((op==0x12||op==0x32||op==0x3a)&&!(s->cp0_sr&0x40000000u))fail(s,pc,"COP2 disabled; exception delivery unsupported",ins);
    switch (op) {
    case 0:
        switch (fn) {
        case 0: s->r[rd] = s->r[rt] << sa; break;
        case 2: s->r[rd] = s->r[rt] >> sa; break;
        case 3: s->r[rd] = (uint32_t)((int32_t)s->r[rt] >> sa); break;
        case 4: s->r[rd] = s->r[rt] << (s->r[rs] & 31); break;
        case 6: s->r[rd] = s->r[rt] >> (s->r[rs] & 31); break;
        case 7: s->r[rd] = (uint32_t)((int32_t)s->r[rt] >> (s->r[rs] & 31)); break;
        case 0x0c:
            /* Functional SYS(1/2) adapter, matching the PC port's logical
             * critical flag, consistent with the limited SR model.
             * Psy-Q Enter returns previous enabled state; Exit preserves v0.
             * Only the plain syscall encoding is supported. */
            if(ins!=0x0000000cu)fail(s,pc,"Unsupported syscall encoding",ins);
            if(s->r[4]==1){s->r[2]=(uint32_t)s->interrupts_enabled;s->interrupts_enabled=0;s->cp0_sr&=~0x401u;s->out->critical_enters++;}
            else if(s->r[4]==2){s->interrupts_enabled=1;s->cp0_sr|=0x401u;s->out->critical_exits++;}
            else fail(s,pc,"System call not implemented",s->r[4]);
            break;
        case 0x0d: fail(s, pc, "break instruction", ins); break;
        case 0x10: s->r[rd] = s->hi; break;
        case 0x11: s->hi = s->r[rs]; break;
        case 0x12: s->r[rd] = s->lo; break;
        case 0x13: s->lo = s->r[rs]; break;
        case 0x18: sp = (int64_t)(int32_t)s->r[rs] * (int32_t)s->r[rt]; s->lo = (uint32_t)sp; s->hi = (uint32_t)(sp >> 32); break;
        case 0x19: up = (uint64_t)s->r[rs] * s->r[rt]; s->lo = (uint32_t)up; s->hi = (uint32_t)(up >> 32); break;
        case 0x1a:
            if (s->r[rt]) {
                if (s->r[rt] == 0xffffffffu) { s->lo = 0u - s->r[rs]; s->hi = 0; }
                else { s->lo = (uint32_t)((int32_t)s->r[rs] / (int32_t)s->r[rt]); s->hi = (uint32_t)((int32_t)s->r[rs] % (int32_t)s->r[rt]); }
            } else { s->lo = (int32_t)s->r[rs] < 0 ? 1u : 0xffffffffu; s->hi = s->r[rs]; }
            break;
        case 0x1b:
            if (s->r[rt]) { s->lo = s->r[rs] / s->r[rt]; s->hi = s->r[rs] % s->r[rt]; }
            else { s->lo = 0xffffffffu; s->hi = s->r[rs]; }
            break;
        case 0x20: s->r[rd] = checked_add(s, pc, s->r[rs], s->r[rt]); break;
        case 0x21: s->r[rd] = s->r[rs] + s->r[rt]; break;
        case 0x22: s->r[rd] = checked_sub(s, pc, s->r[rs], s->r[rt]); break;
        case 0x23: s->r[rd] = s->r[rs] - s->r[rt]; break;
        case 0x24: s->r[rd] = s->r[rs] & s->r[rt]; break;
        case 0x25: s->r[rd] = s->r[rs] | s->r[rt]; break;
        case 0x26: s->r[rd] = s->r[rs] ^ s->r[rt]; break;
        case 0x27: s->r[rd] = ~(s->r[rs] | s->r[rt]); break;
        case 0x2a: s->r[rd] = (int32_t)s->r[rs] < (int32_t)s->r[rt]; break;
        case 0x2b: s->r[rd] = s->r[rs] < s->r[rt]; break;
        default: fail(s, pc, "unsupported instruction", ins);
        }
        break;
    case 8: s->r[rt] = checked_add(s, pc, s->r[rs], (uint32_t)im); break;
    case 9: s->r[rt] = s->r[rs] + (uint32_t)im; break;
    case 0xa: s->r[rt] = (int32_t)s->r[rs] < im; break;
    case 0xb: s->r[rt] = s->r[rs] < (uint32_t)im; break;
    case 0xc: s->r[rt] = s->r[rs] & (ins & 0xffff); break;
    case 0xd: s->r[rt] = s->r[rs] | (ins & 0xffff); break;
    case 0xe: s->r[rt] = s->r[rs] ^ (ins & 0xffff); break;
    case 0xf: s->r[rt] = ins << 16; break;
    case 0x12: /* COP2 */
        if (ins & (1u << 25)) { if(!Memories_GteCommand(ins))fail(s,pc,"Unsupported GTE command",ins); break; }
        switch (rs) {
        case 0: s->r[rt] = Memories_GteReadData(rd); break;
        case 2: s->r[rt] = Memories_GteReadControl(rd); break;
        case 4: Memories_GteWriteData(rd, s->r[rt]); break;
        case 6: Memories_GteWriteControl(rd, s->r[rt]); break;
        default: fail(s, pc, "unsupported COP2 form", ins);
        }
        break;
    case 0x20: s->r[rt] = (uint32_t)(int32_t)(int8_t)l8(s, s->r[rs] + (uint32_t)im); break;
    case 0x21: s->r[rt] = (uint32_t)(int32_t)(int16_t)l16(s, s->r[rs] + (uint32_t)im); break;
    case 0x22: a = s->r[rs] + (uint32_t)im; s->r[rt] = (s->r[rt] & (0x00ffffffu >> ((a & 3) * 8))) | (l32(s, a & ~3u) << ((3 - (a & 3)) * 8)); break;
    case 0x23: s->r[rt] = l32(s, s->r[rs] + (uint32_t)im); break;
    case 0x24: s->r[rt] = l8(s, s->r[rs] + (uint32_t)im); break;
    case 0x25: s->r[rt] = l16(s, s->r[rs] + (uint32_t)im); break;
    case 0x26: a = s->r[rs] + (uint32_t)im; s->r[rt] = (s->r[rt] & (0xffffff00u << ((3 - (a & 3)) * 8))) | (l32(s, a & ~3u) >> ((a & 3) * 8)); break;
    case 0x28: s8(s, s->r[rs] + (uint32_t)im, (uint8_t)s->r[rt]); break;
    case 0x29: s16(s, s->r[rs] + (uint32_t)im, (uint16_t)s->r[rt]); break;
    case 0x2a: a = s->r[rs] + (uint32_t)im; word = l32(s, a & ~3u); s32(s, a & ~3u, (word & (0xffffff00u << ((a & 3) * 8))) | (s->r[rt] >> ((3 - (a & 3)) * 8))); break;
    case 0x2b: s32(s, s->r[rs] + (uint32_t)im, s->r[rt]); break;
    case 0x2e: a = s->r[rs] + (uint32_t)im; word = l32(s, a & ~3u); s32(s, a & ~3u, (word & (0x00ffffffu >> ((3 - (a & 3)) * 8))) | (s->r[rt] << ((a & 3) * 8))); break;
    case 0x10:
        if(rd!=12||(ins&0x7ffu)||(rs!=0&&rs!=4))fail(s,pc,"unsupported COP0 register or instruction",ins);
        if(rs==0){s->r[rt]=s->cp0_sr;s->out->cp0_sr_reads++;}
        else{
            if(s->r[rt]&~0x40000401u)fail(s,pc,"Unsupported COP0 SR control bits",s->r[rt]);
            s->cp0_sr=s->r[rt];s->interrupts_enabled=(s->cp0_sr&0x401u)==0x401u;s->out->cp0_sr_writes++;
        }
        break;
    case 0x32: Memories_GteLoad(rt, span(s, s->r[rs] + (uint32_t)im, 4, 4)); break;
    case 0x3a: Memories_GteStore(rt, span(s, s->r[rs] + (uint32_t)im, 4, 4)); break;
    default: fail(s, pc, "unsupported instruction", ins);
    }
    s->r[0] = 0;
}


/* MIPS-I load delay, including the LWL/LWR merge forwarding pair. No branch-likely:
 * those instructions belong to later ISAs and are rejected for this PS1 harness. */
static int loaded_register(uint32_t i){
 unsigned op=i>>26,rs=(i>>21)&31;
 if((op>=0x20&&op<=0x26)||(op==0x10&&rs==0)||(op==0x12&&!(i&(1u<<25))&&(rs==0||rs==2)))return (i>>16)&31;
 return -1;
}
static int written_register(uint32_t i){
 unsigned op=i>>26,rs=(i>>21)&31,fn=i&63;
 if(op==0){if(fn<=7||fn==9||fn==0x10||fn==0x12||(fn>=0x20&&fn<=0x2b))return (i>>11)&31;return -1;}
 if(op>=8&&op<=15)return (i>>16)&31;
 if((op==0x10&&rs==0)||(op==0x12&&!(i&(1u<<25))&&(rs==0||rs==2)))return (i>>16)&31;
 return -1;
}
static void finish_pending(State *s,int written,int new_reg,uint32_t value){
 if(s->pending&&s->pending_reg!=(uint32_t)written)s->r[s->pending_reg]=s->pending_value;
 s->pending=new_reg>0;s->pending_reg=(uint32_t)new_reg;s->pending_value=value;s->r[0]=0;
}
static void execute_plain(State *s,uint32_t pc,uint32_t ins,int delay_slot){
 s->pc=pc;
 uint32_t op=ins>>26;trace(s,pc,ins);
 if(control(ins))fail(s,pc,delay_slot?"Branch in delay slot":"Unexpected branch",ins);
 if(delay_slot && op==0 && (ins&63)==0x0c)fail(s,pc,"Syscall in delay slot not implemented",ins);
 int writes_syscall_v0=op==0 && (ins&63)==0x0c && s->r[4]==1;
 int load=loaded_register(ins);uint32_t before=load>=0?s->r[load]:0;
 /* Charge explicit RAM data-load stalls, never duplicate instruction-fetch
  * reads performed by the decoder. IRQ delivery stays at instruction boundaries. */
 uint32_t address=s->r[(ins>>21)&31]+(uint32_t)(int32_t)(int16_t)ins;
 unsigned wait=LekakCpu_LoadWait(ins,address);
 for(unsigned i=0;i<wait;i++)clock_cycle(s);
 if((op==0x22||op==0x26)&&s->pending&&s->pending_reg==(uint32_t)load){
  if(((ins>>21)&31)==(unsigned)load)fail(s,pc,"Unaligned load base aliases merge register",ins);
  s->r[load]=s->pending_value;
 }
 plain(s,pc,ins);
 uint32_t value=load>=0?s->r[load]:0;
 if(load>=0)s->r[load]=before;
 finish_pending(s,load>=0?-1:(writes_syscall_v0?2:written_register(ins)),load,value);
}
static State *create_state(MemoriesMemory *memory,uint32_t entry,uint32_t gp,uint32_t sp,
 const LekakExecPads *pads,LekakDiscImage *image){
 if(!memory)return NULL;
 State *s=calloc(1,sizeof(*s));if(!s)return NULL;
 LekakExecResult *out=&s->owned_result;
 s->memory=memory;s->out=out;s->pc=entry;s->interrupts_enabled=1;s->irq.dpcr=0x07654321u;
 s->cp0_sr=0x40000401u; /* Defined software boot state: GTE and IRQ2 enabled. */
 s->common_delay=0x31125u;s->cd_bus_delay=0x20843u;s->spu_bus_delay=0x200931e1u;
 s->cd.image=image;
 /* Software post-loader boot context: inserted data image, controller IRQs
  * enabled as after BIOS CD initialization. This is not power-on reset. */
 s->cd.enable=image?0x1fu:0;
 s->cd.volume[0]=s->cd.volume[2]=s->cd.volume_applied[0]=s->cd.volume_applied[2]=0x80;
 s->pad_poll_enabled=1;
 if(pads){
  s->pad.press_frame=pads->press_frame;s->pad.release_frame=pads->release_frame;
  s->pad.repeat_frames=pads->repeat_frames;
  for(unsigned i=0;i<2;i++){s->pad.connected[i]=!!pads->connected[i];s->pad.scheduled[i]=pads->pressed[i];s->pad.pressed[i]=pads->press_frame?0:pads->pressed[i];}
 }
 s->dma_channels[6][2]=2;
 for(unsigned i=0;i<3;i++)s->timers.mode[i]=0x400u;
 for(unsigned i=0;i<4;i++)s->clear_counter[i]=1;
 s->clear_pad=1;
 /* Abstract BIOS driver registry starts attached, as after BIOS boot. This
  * diagnostic has no built-in CD IRQ nodes. Selected drive setup uses an
  * attached image, but sector transfers remain absent. Removing
  * the ISO driver changes the registry; it does not delete game IRQ nodes. */
 s->cd_iso_driver_registered=1;
 s->memory_megabytes=2;
 LekakGpuIo_Init(&s->gpu);LekakMdec_Init(&s->mdec);
 /* At line/cycle zero the reset display ranges are already blank. This
  * initial state is not a new edge and must not invent an IRQ. */
 s->video.hblank=s->video.vblank=1;s->timers.blank[0]=s->timers.blank[1]=1;
 s->r[28]=gp;s->r[29]=sp;s->r[31]=LEKAK_EXEC_RETURN;
 return s;
}
static int run_state(State *s,uint32_t budget,int resumable,LekakExecResult *destination){
 LekakExecResult *out=s->out;
 if(s->stopped){*destination=*out;return out->returned?LEKAK_EXEC_FINISHED:LEKAK_EXEC_FAULT;}
 s->steps=0;s->budget=budget;s->resumable=resumable;out->reason[0]=0;
 int fault=setjmp(s->escape);
 if(!fault)while(s->pc!=LEKAK_EXEC_RETURN){
  if(s->steps>=s->budget){
   if(s->resumable){out->pc=s->pc;out->detail=0;snprintf(out->reason,sizeof(out->reason),"Execution slice yielded");break;}
   fail(s,s->pc,"Instruction budget reached",s->steps);
  }
  if(s->pc==LEKAK_CARD_IRQ_TAIL)fail(s,s->pc,"Card serial IRQ tail not implemented",s->pc);
  if(s->pc==LEKAK_PAD_ENABLE_FN||s->pc==LEKAK_PAD_DISABLE_FN){
   if(!s->pad_error_patch)fail(s,s->pc,"Pad callback invoked before its patch was installed",s->pc);
   s->steps++;clock_cycle(s);
   s->pad_poll_enabled=s->pc==LEKAK_PAD_ENABLE_FN;s->out->pad_poll_callbacks++;s->pc=s->r[31];continue;
  }
  mdec_dma(s,0);mdec_dma(s,1);
  gpu_dma(s);
  otc_dma(s);
  spu_dma(s);
  if(s->pc==LEKAK_TIMER_WORKER_RETURN){if(!s->irq_active)fail(s,s->pc,"Timer worker return outside IRQ",0);s->steps++;irq_next(s);continue;}
  if(s->pc==LEKAK_EVENT_RETURN){if(!s->event_active)fail(s,s->pc,"Event return outside callback",0);s->steps++;event_next(s);continue;}
  if(s->pc==LEKAK_EXCEPTION_RETURN){s->steps++;restore_irq(s);continue;}
  if(s->pc==LEKAK_CHAIN_FIRST_RETURN||s->pc==LEKAK_CHAIN_SECOND_RETURN){s->steps++;irq_chain_return(s);continue;}
  /* Deliver between completed instructions/branch pairs. No nested IRQs;
   * branch-delay EPC/BD timing and CP0 execution remain unsupported. */
  if(!s->irq_active&&s->interrupts_enabled&&(s->irq.status&s->irq.mask)){
   if(s->event_active)fail(s,s->pc,"IRQ nesting during BIOS event callback unsupported",s->pc);
   s->steps++;enter_irq(s);continue;
  }
  uint32_t pc=s->pc,physical=pc&0x1fffffffu;
  if(pc==0x801680f4u||pc==0x80168160u){
   /* Native-port compatibility, matching pinned pc/overlays/boot_check.c.
    * This is NOT BIOS ROM emulation or a successful mechanical CD check.
    * Only the identified USA boot-check overlay may use the native stubs. */
   const uint8_t *module=span(s,0x80168000u,0x1800,4);
   uint32_t hash=2166136261u;
   for(unsigned i=0;i<0x1800;i++)hash=(hash^module[i])*16777619u;
   if(hash==0x0233e23cu){
    if(s->pending){if(s->pending_reg)s->r[s->pending_reg]=s->pending_value;s->pending=0;}
    if(pc==0x80168160u)s->r[2]=0;
    s->out->native_boot_check_calls++;s->pc=s->r[31];s->steps++;clock_cycle(s);continue;
   }
  }
  if(physical==0xA0||physical==0xB0||physical==0xC0){
   if(!s->resumable&&s->steps>=s->budget)fail(s,pc,"Instruction budget reached",s->steps);
   /* One bounded adapter step per BIOS call, in addition to guest opcodes. */
   s->steps++;
   clock_cycle(s);
   if(physical==0xB0&&s->r[9]>=7&&s->r[9]<=0xd){
    unsigned fn=s->r[9];LekakBiosEvent *e=LekakEvent_Get(&s->events,s->r[4]);
    switch(fn){
    case 8:
     if(s->r[6]!=0x2000u&&s->r[6]!=0x1000u)fail(s,pc,"BIOS event mode unsupported",s->r[6]);
     if(s->r[6]==0x1000u)span(s,s->r[7],4,4);
     s->r[2]=LekakEvent_Open(&s->events,s->r[4],s->r[5]);
     e=LekakEvent_Get(&s->events,s->r[2]);if(e){e->mode=s->r[6];e->callback=s->r[7];}break;
    case 7:s->out->bios_calls++;event_deliver(s,s->r[4],s->r[5],s->r[31]);continue;
    case 9:if(e)memset(e,0,sizeof(*e));s->r[2]=1;break;
    case 0xc:if(e){e->enabled=1;e->ready=0;}s->r[2]=1;break;
    case 0xd:if(e){e->enabled=0;e->ready=0;}s->r[2]=1;break;
    case 0xa:
     if(e&&e->enabled&&!e->ready)fail(s,pc,"BIOS event wait has no ready producer",s->r[4]);
     /* Already ready or disabled: share TestEvent consumption. */
     /* fall through */
    case 0xb:s->r[2]=e&&e->mode==0x2000u&&e->enabled&&e->ready;if(s->r[2])e->ready=0;break;
    }
    s->out->bios_calls++;s->pc=s->r[31];continue;
   }
   if(physical==0xB0&&s->r[9]==0x20){
    LekakEvent_Deliver(&s->events,s->r[4],s->r[5],0);s->out->bios_calls++;s->pc=s->r[31];continue;
   }
   if(physical==0xB0&&s->r[9]==0x17){s->out->bios_calls++;restore_irq(s);continue;}
   if(physical==0xB0&&s->r[9]==0x12){
    if(!LekakPad_Init(&s->pad,s->memory,s->r[4],s->r[5],s->r[6],s->r[7]))fail(s,pc,"Unsupported pad buffers or allocation sizes",s->r[4]);
    s->pad_poll_enabled=1;s->r[2]=1;s->out->bios_calls++;s->pc=s->r[31];continue;
   }
   if(physical==0xB0&&(s->r[9]==0x13||s->r[9]==0x14)){
    if(s->r[9]==0x13&&!s->pad.initialized)fail(s,pc,"StartPAD before InitPAD",0);
    s->pad.started=s->r[9]==0x13;
    if(s->r[9]==0x14)s->card_running=0;
    if(s->pad.started)s->irq.mask|=1u; /* Worker needs VBlank, no serial IRQ model. */
    s->r[2]=1;s->out->bios_calls++;s->pc=s->r[31];continue;
   }
   if(physical==0xB0&&s->r[9]==0x56){
    uint32_t resume=LekakBios_CausePatch(s->memory,s->r[31]);
    if(resume)s->out->bios_cause_patches++;
    else{
     resume=LekakBios_CardEarlyPatch(s->memory,s->r[31]);
     if(!resume)fail(s,pc,"Unrecognized BIOS table/exception patch request",s->r[31]);
     if(!s->card_initialized)fail(s,pc,"Card patch before InitCARD",s->r[31]);
     s->r[2]=LEKAK_CARD_IRQ_TAIL;s->out->bios_card_early_patches++;
    }
    s->out->bios_calls++;s->pc=resume;continue;
   }
   if(physical==0xB0&&s->r[9]==0x57){
    uint32_t resume=LekakBios_PadAckPatch(s->memory,s->r[31]);
    if(resume){s->pad_ack_patch=1;s->out->bios_pad_ack_patches++;}
    else{
     uint32_t slots[2];resume=LekakBios_PadErrorPatch(s->memory,s->r[31],slots);
     if(resume){s32(s,slots[0],LEKAK_PAD_ENABLE_FN);s32(s,slots[1],LEKAK_PAD_DISABLE_FN);
      s->pad_error_patch=1;s->out->bios_pad_error_patches++;}
     else{
      resume=LekakBios_CardDelayPatch(s->memory,s->r[31]);
      int delay=!!resume;
      if(!resume){
       resume=LekakBios_CardInfoPatch(s->memory,s->r[31]);
       if(!resume)fail(s,pc,"Unrecognized BIOS pad/card patch request",s->r[31]);
      }
      if(!s->card_initialized)fail(s,pc,"Card patch before InitCARD",s->r[31]);
      if(delay)s->out->bios_card_delay_patches++;else s->out->bios_card_info_patches++;
     }
    }
    s->out->bios_calls++;s->pc=resume;continue;
   }
   if((physical==0xB0&&s->r[9]==0x35)||(physical==0xA0&&s->r[9]==3)){
    if(s->r[4]!=1)fail(s,pc,"Only the diagnostic stdout descriptor is supported",s->r[4]);
    uint32_t length=s->r[6];
    if(length){
     const char *bytes=span(s,s->r[5],length,1);
     size_t capacity=LEKAK_EXEC_CONSOLE-1-s->out->console_bytes;
     size_t count=length<capacity?length:capacity;
     memcpy(s->out->console_output+s->out->console_bytes,bytes,count);
     s->out->console_bytes+=(uint32_t)count;
     if(count<length)s->out->console_truncated=1;
    }
    s->r[2]=length;
   } else if(physical==0xA0&&s->r[9]==0x44){
    /* FlushCache: interpreter fetches guest RAM directly on every opcode;
     * there is no decoded-code or instruction cache to invalidate. */
   } else if(physical==0xA0&&s->r[9]==0x48){
    s32(s,0x1f801814u,s->r[4]);
   } else if(physical==0xA0&&s->r[9]==0x49){
    gpu_dma(s);
    if((s->dma_channels[2][2]&0x1000000u)||!(s->gpu.status&0x10000000u))fail(s,pc,"GPU BIOS sync requires unsupported wait",s->gpu.status);
    if(s->gpu.status&0x60000000u)s32(s,0x1f801814u,0x04000000u);
    s32(s,0x1f801810u,s->r[4]);s->r[2]=0;
   } else if(physical==0xA0&&(s->r[9]==0x72||s->r[9]==0x56)){
    /* Psy-Q void _96_remove(): detach the software ISO driver. No read,
     * transfer or CD initialization success is fabricated by this call. */
    s->cd_iso_driver_registered=0;s->out->cd_driver_removals++;
   } else if(physical==0xA0&&s->r[9]==0x9F){
    if(s->r[4]!=2)fail(s,pc,"Only the allocated 2 MiB RAM configuration is supported",s->r[4]);
    s->memory_megabytes=2;
   } else if(physical==0xB0&&s->r[9]==0x18){
    uint8_t *context=span(s,LEKAK_DEFAULT_IRQ_CONTEXT,0x30,4);
    memset(context,0,0x30);
    Memories_WriteLE32(context,LEKAK_EXCEPTION_RETURN);
    Memories_WriteLE32(context+4,0x8000fff0u);
    s->interrupt_hook=LEKAK_DEFAULT_IRQ_CONTEXT;s->r[2]=s->interrupt_hook;
   } else if(physical==0xB0&&s->r[9]==0x19){
    /* Store the validated exit context; IRQ dispatch uses this context
     * after checking that software priority chains are empty. */
    span(s,s->r[4],0x30,4);s->interrupt_hook=s->r[4];
   } else if(physical==0xB0&&s->r[9]==0x5B){
    if(s->r[4]>1)fail(s,pc,"Invalid pad auto-ack configuration",s->r[4]);
    uint32_t old=s->clear_pad;s->clear_pad=s->r[4];s->r[2]=old;
   } else if(physical==0xC0&&s->r[9]==2){
    uint32_t priority=s->r[4],node=s->r[5];
    if(priority>=4)fail(s,pc,"Invalid interrupt priority",priority);
    span(s,node,16,4);
    /* Reject duplicate registrations rather than introduce a cycle. */
    for(uint32_t at=s->interrupt_chains[priority],n=0;at;at=Memories_ReadLE32(span(s,at,16,4))){
     if(at==node||++n>64)fail(s,pc,"Duplicate or cyclic interrupt chain",node);
    }
    s32(s,node,s->interrupt_chains[priority]);s->interrupt_chains[priority]=node;s->r[2]=0;
   } else if(physical==0xC0&&s->r[9]==3){
    uint32_t priority=s->r[4],node=s->r[5];
    if(priority>=4)fail(s,pc,"Invalid interrupt priority",priority);
    span(s,node,16,4);s->r[2]=0;
    for(uint32_t at=s->interrupt_chains[priority],n=0;at;at=Memories_ReadLE32(span(s,at,16,4))){
     if(++n>64)fail(s,pc,"Cyclic interrupt removal chain",node);
     if(at==node){
      if(n!=1)fail(s,pc,"Only priority-chain head removal is supported",node);
      s->interrupt_chains[priority]=Memories_ReadLE32(span(s,node,16,4));s->r[2]=node;break;
     }
    }
   } else if(physical==0xB0&&s->r[9]==0x4A){
    /* Configuration/idle state only. No inserted card, serial IRQ node or
     * storage completion is synthesized. Start/I/O services still halt. */
    if(s->r[4]>1)fail(s,pc,"Unsupported card/pad sharing configuration",s->r[4]);
    s->card_initialized=1;s->card_running=0;s->card_pad_shared=(int)s->r[4];s->pad_poll_enabled=(int)s->r[4];
    /* InitCARD2 is void: preserve v0 rather than inventing a success result. */
   } else if(physical==0xB0&&(s->r[9]==0x4B||s->r[9]==0x4C)){
    if(!s->card_initialized)fail(s,pc,"Card lifecycle before InitCARD",s->r[9]);
    if(s->r[9]==0x4B){
     if(s->card_pad_shared&&!s->pad.initialized)fail(s,pc,"Shared card start before InitPAD",0);
     s->card_running=1;s->irq.mask|=0x81u;
     if(s->card_pad_shared)s->pad.started=1;
    }else s->card_running=0; /* Preserve controller polling. */
    /* Functional lifecycle only, no media/serial success or v0 fabricated. */
   } else if(physical==0xA0&&(s->r[9]==0x55||s->r[9]==0x70)){
    if(!s->card_running)fail(s,pc,"Backup driver init before StartCARD",s->r[9]);
    s->bu_driver_registered=1; /* Abstract registry only, autoformat disabled. */
   } else if(physical==0xC0&&s->r[9]==0xA){
    if(s->r[4]>=4||s->r[5]>1)fail(s,pc,"Invalid root-counter auto-ack configuration",s->r[4]);
    uint32_t old=s->clear_counter[s->r[4]];s->clear_counter[s->r[4]]=s->r[5];s->r[2]=old;
   } else {
    fail(s,pc,"BIOS service not implemented",s->r[9]);
   }
   s->out->bios_calls++;s->pc=s->r[31];continue;
  }
  /* Checked RAM/scratchpad fetch, once per instruction, separate from MMIO. */
  uint32_t ins=Memories_ReadLE32(span(s,pc,4,4)),op=ins>>26,rs=(ins>>21)&31,rt=(ins>>16)&31,fn=ins&63;
  uint32_t target=0,next=pc+8;int written=-1;
  if(!control(ins)){execute_plain(s,pc,ins,0);s->pc=pc+4;continue;}
  trace(s,pc,ins);
  if(op==0){target=s->r[rs];if(fn==9){written=(ins>>11)&31;s->r[written]=next;}}
  else if(op==2||op==3){target=((pc+4)&0xF0000000u)|((ins&0x3FFFFFFu)<<2);if(op==3){written=31;s->r[31]=next;}}
  else{
   int take=0;int32_t im=(int16_t)ins;
   if(op==1){
    if(rt==0||rt==16)take=(int32_t)s->r[rs]<0;
    else if(rt==1||rt==17)take=(int32_t)s->r[rs]>=0;
    else fail(s,pc,"Unsupported REGIMM instruction",ins);
    if(rt==16||rt==17){written=31;s->r[31]=next;}
   }else if(op==4)take=s->r[rs]==s->r[rt];
   else if(op==5)take=s->r[rs]!=s->r[rt];
   else if(op==6){if(rt)fail(s,pc,"Invalid BLEZ encoding",ins);take=(int32_t)s->r[rs]<=0;}
   else if(op==7){if(rt)fail(s,pc,"Invalid BGTZ encoding",ins);take=(int32_t)s->r[rs]>0;}
   target=take?pc+4+((uint32_t)im<<2):next;
  }
  finish_pending(s,written,-1,0);execute_plain(s,pc+4,Memories_ReadLE32(span(s,pc+4,4,4)),1);s->pc=target;
 }
 s->total_steps+=s->steps;out->total_steps=s->total_steps;
 out->steps=s->steps;memcpy(out->registers,s->r,sizeof(s->r));
 out->logical_interrupts_enabled=s->interrupts_enabled;
 out->irq_status=s->irq.status;out->irq_mask=s->irq.mask;
 out->irq_reads=s->irq.reads;out->irq_writes=s->irq.writes;
 out->dma_control=s->irq.dpcr;out->dma_interrupt=s->irq.dicr;
 out->interrupt_hook=s->interrupt_hook;memcpy(out->interrupt_chains,s->interrupt_chains,sizeof(out->interrupt_chains));
 out->timer_reads=s->timers.reads;out->timer_writes=s->timers.writes;
 out->cd_iso_driver_registered=s->cd_iso_driver_registered;
 out->memory_megabytes=s->memory_megabytes;
 out->mdec_status=LekakMdec_Status(&s->mdec);out->mdec_commands=s->mdec.commands;out->mdec_macroblocks=s->mdec.macroblocks;
 out->gpu_status=s->gpu.status;out->gp0_commands=s->gpu.gp0_commands;out->gp1_commands=s->gpu.gp1_commands;
 out->gpu_display_start=s->gpu.display_start;out->gpu_display_horizontal=s->gpu.horizontal;out->gpu_display_vertical=s->gpu.vertical;
 out->gpu_reads=s->gpu.reads;
 out->cp0_sr=s->cp0_sr;out->pad_ack_patch_enabled=s->pad_ack_patch;
 out->pad_poll_enabled=s->pad_poll_enabled;out->pad_error_patch_enabled=s->pad_error_patch;
 memcpy(out->pad_buffers,s->pad.buffers,sizeof(out->pad_buffers));out->pad_initializations=s->pad.initializations;
 out->pad_polls=s->pad.polls;out->pad_initialized=s->pad.initialized;out->pad_started=s->pad.started;
 out->joy_control_reads=s->joy.reads;out->joy_control_writes=s->joy.writes;
 out->card_initialized=s->card_initialized;out->card_pad_shared=s->card_pad_shared;
 out->card_running=s->card_running;
 out->bu_driver_registered=s->bu_driver_registered;
 out->cd_streaming=s->cd.streaming;out->cd_decoded_ready=s->cd.decoded_ready;
 out->xa_audio_sectors=s->cd.xa.sectors;out->xa_audio_frames=s->cd.xa.frames;out->xa_audio_consumed=s->cd.xa.consumed;out->xa_audio_queued=s->cd.xa.count;
 out->cd_fifo_size=s->cd.fifo_size;out->cd_fifo_pos=s->cd.fifo_pos;out->cd_last_command=s->cd.command;
 out->spu_reads=s->spu.reads;out->spu_writes=s->spu.writes;out->spu_ticks=s->spu.ticks;
 out->spu_manual_halfwords=s->spu.manual_halfwords;out->spu_frames=s->spu.dsp.frames;
 out->spu_nonzero_frames=s->spu.dsp.nonzero_frames;out->spu_pcm_hash=s->spu.dsp.pcm_hash;
 out->spu_control=s->spu.control;out->spu_status=s->spu.status;
 memcpy(out->spu_main_gain,s->spu.main_gain,sizeof(out->spu_main_gain));
 memcpy(out->spu_current_gain,s->spu.current_gain,sizeof(out->spu_current_gain));
 memcpy(out->spu_cd_gain,s->spu.cd_gain,sizeof(out->spu_cd_gain));
 out->cd_reads=s->cd.reads;out->cd_writes=s->cd.writes;out->cd_commands=s->cd.commands;
 out->cd_sectors_decoded=s->cd.sectors_decoded;out->cd_data_irqs=s->cd.data_irqs;out->cd_data_bytes=s->cd.data_bytes;
 out->cd_next_lba=s->cd.next_lba;
 out->cd_acks=s->cd.acks;out->cd_completions=s->cd.completions;out->cd_flags=s->cd.flags;out->cd_enable=s->cd.enable;
 out->nominal_cycles=s->video.cycles;out->video_lines=s->video.line;out->video_frames=s->video.frames;
 out->hblank_edges=s->video.hblank_edges;out->vblank_edges=s->video.vblank_edges;
 memcpy(out->timer_counts,s->timers.count,sizeof(out->timer_counts));
 memcpy(out->timer_irq_events,s->timers.irq_events,sizeof(out->timer_irq_events));
 if(s->pc==LEKAK_EXEC_RETURN){out->returned=1;out->pc=s->pc;snprintf(out->reason,sizeof(out->reason),"Routine returned");}
 if(fault||out->returned)s->stopped=1;
 *destination=*out;
 return fault?LEKAK_EXEC_FAULT:(out->returned?LEKAK_EXEC_FINISHED:LEKAK_EXEC_YIELDED);
}
LekakExecSession *LekakExec_Create(MemoriesMemory *memory,uint32_t entry,uint32_t gp,uint32_t sp,
 const LekakExecPads *pads,LekakDiscImage *image){return create_state(memory,entry,gp,sp,pads,image);}
int LekakExec_Slice(LekakExecSession *s,uint32_t quota,LekakExecResult *out){
 if(!s||!out||!quota||quota>1000000u){
  if(out){memset(out,0,sizeof(*out));snprintf(out->reason,sizeof(out->reason),"Invalid session or execution quota");}
  return LEKAK_EXEC_FAULT;
 }
 return run_state(s,quota,1,out);
}
void LekakExec_SetPads(LekakExecSession *s,const LekakExecPads *pads){
 if(!s||s->stopped)return;
 s->pad.press_frame=pads?pads->press_frame:0;s->pad.release_frame=pads?pads->release_frame:0;
 s->pad.repeat_frames=pads?pads->repeat_frames:0;
 for(unsigned i=0;i<2;i++){
  s->pad.connected[i]=pads?!!pads->connected[i]:0;
  s->pad.scheduled[i]=pads?pads->pressed[i]:0;
  s->pad.pressed[i]=pads&&!pads->press_frame?pads->pressed[i]:0;
 }
}
void LekakExec_Destroy(LekakExecSession *s){free(s);}
void LekakExec_SetAudioSink(LekakExecSession *s,LekakExecAudioSink sink,void *context){
 if(s&&!s->stopped){s->audio_sink=sink;s->audio_context=context;}
}
int LekakExec_RunWithDisc(MemoriesMemory *memory,uint32_t entry,uint32_t gp,uint32_t sp,
 uint32_t budget,LekakExecResult *out,const LekakExecPads *pads,LekakDiscImage *image){
 if(!out)return 0;
 memset(out,0,sizeof(*out));
 if(!memory||!budget){snprintf(out->reason,sizeof(out->reason),"Missing RAM or instruction budget");return 0;}
 State *s=create_state(memory,entry,gp,sp,pads,image);
 if(!s){snprintf(out->reason,sizeof(out->reason),"Execution state allocation failed");return 0;}
 run_state(s,budget,0,out);free(s);return out->returned;
}
int LekakExec_Run(MemoriesMemory *memory,uint32_t entry,uint32_t gp,uint32_t sp,
                  uint32_t budget,LekakExecResult *out){
 return LekakExec_RunWithPads(memory,entry,gp,sp,budget,out,NULL);
}

int LekakExec_RunWithPads(MemoriesMemory *memory,uint32_t entry,uint32_t gp,uint32_t sp,
                  uint32_t budget,LekakExecResult *out,const LekakExecPads *pads){
 return LekakExec_RunWithDisc(memory,entry,gp,sp,budget,out,pads,NULL);
}
