#ifndef LEKAK_DISPLAY_SNAPSHOT_H
#define LEKAK_DISPLAY_SNAPSHOT_H
#include <stdint.h>
#include <stddef.h>
/* Snapshot of selected noninterlaced16/24-bit display modes, not live scanout.
 * No output/geometry mutation if bounds or mode checks fail. */
int LekakDisplay_CopyRGBA(const uint16_t *vram,uint32_t status,uint32_t origin,uint32_t vertical,uint8_t *out,size_t capacity,unsigned *width,unsigned *height);
#endif
