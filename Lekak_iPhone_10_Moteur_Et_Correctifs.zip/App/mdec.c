#include "mdec.h"
#include <string.h>
#include <stdlib.h>
/* Integer transform using uploaded scale/quantization tables. Algorithm and
 * register definitions: psx-spx macroblockdecodermdec. Rounding and YUV
 * coefficients are functional approximations, not bit-exact silicon. */
static const uint8_t zig[64]={0,1,8,16,9,2,3,10,17,24,32,25,18,11,4,5,12,19,26,33,40,48,41,34,27,20,13,6,7,14,21,28,35,42,49,56,57,50,43,36,29,22,15,23,30,37,44,51,58,59,52,45,38,31,39,46,53,60,61,54,47,55,62,63};
static int32_t floor_div(int64_t v,int32_t d){return (int32_t)(v>=0?v/d:-((-v+d-1)/d));}
static int sign10(uint16_t v){int x=v&1023;return x>=512?x-1024:x;}
static int limit(int v,int lo,int hi){return v<lo?lo:v>hi?hi:v;}
static void reset(LekakMdec *m){m->command=m->remaining=m->received=m->input_count=m->input_position=0;m->output_size=m->output_position=0;m->reset_status=1;}
void LekakMdec_Init(LekakMdec *m){memset(m,0,sizeof(*m));reset(m);}
uint32_t LekakMdec_Status(const LekakMdec *m){
 uint32_t v=m->output_position==m->output_size?0x80000000u:0;
 v|=((m->command>>25)&15u)<<23;
 v|=(m->remaining?m->remaining-1:m->reset_status?0u:0xffffu)&0xffffu;
 unsigned depth=m->command>>27&3u;
 v|=((depth>=2&&m->output_position<m->output_size)?m->output_position/(64u*(depth==2?3u:2u)):4u)<<16;
 if(m->remaining)v|=0x20000000u;
 if((m->control&0x40000000u)&&m->remaining)v|=0x10000000u;
 if((m->control&0x20000000u)&&(m->output_position<m->output_size||(!m->remaining&&m->input_position<m->input_count)))v|=0x08000000u;
 return v;
}
static void idct(const LekakMdec *m,int32_t *b){
 int32_t temp[64];
 for(unsigned pass=0;pass<2;pass++){
  for(unsigned x=0;x<8;x++)for(unsigned y=0;y<8;y++){
   int64_t sum=0;
   for(unsigned z=0;z<8;z++)sum+=(int64_t)b[y+z*8]*floor_div(m->scale[x+z*8],8);
   temp[x+y*8]=floor_div(sum+4095,8192);
  }
  memcpy(b,temp,sizeof(temp));
 }
}
static int block(LekakMdec *m,int32_t *b,unsigned qt){
 memset(b,0,64*sizeof(*b));uint16_t code;
 do {if(m->input_position==m->input_count)return 0;code=m->input[m->input_position++];}while(code==0xfe00);
 unsigned q=code>>10,k=0;int v=sign10(code)*(q?m->quant[qt]:2);
 for(;;){
  b[q?zig[k]:k]=limit(v,-1024,1023);
  if(m->input_position==m->input_count)return -1;
  code=m->input[m->input_position++];k+=(code>>10)+1;
  if(k>63)break;
  v=q?floor_div((int64_t)sign10(code)*m->quant[qt+k]*q+4,8):sign10(code)*2;
 }
 idct(m,b);return 1;
}
static uint8_t channel(int v,int signed_output){return (uint8_t)(limit(v,-128,127)+(signed_output?0:128));}
static int decode(LekakMdec *m){
 unsigned depth=m->command>>27&3u;int signed_output=(m->command>>26)&1u;
 int32_t b[6][64];unsigned n=depth<2?1:6;
 for(unsigned i=0;i<n;i++){int ok=block(m,b[i],n==6&&i<2?64:0);if(ok!=1)return i||ok<0?-1:0;}
 if(depth<2){
  for(unsigned i=0;i<64;i++){
   int y=b[0][i]&511;if(y>=256)y-=512;uint8_t v=channel(y,signed_output);
   if(depth==1)m->output[i]=v;else {if(!(i&1))m->output[i/2]=0;m->output[i/2]|=(uint8_t)((v>>4)<<((i&1)*4));}
  }
  m->output_size=depth?64:32;
 }else{
  /* FIFO order is Y1,Y2,Y3,Y4, each 8x8. DMA reorders below. */
  unsigned stride=depth==2?3:2;
  for(unsigned q=0;q<4;q++)for(unsigned y=0;y<8;y++)for(unsigned x=0;x<8;x++){
   unsigned chroma=((q&1)*8+x)/2+(((q>>1)*8+y)/2)*8;
   int cr=b[0][chroma],cb=b[1][chroma],l=b[q+2][y*8+x];
   uint8_t r=channel(l+floor_div((int64_t)cr*359,256),signed_output);
   uint8_t g=channel(l+floor_div(-(int64_t)cb*88-(int64_t)cr*183,256),signed_output);
   uint8_t blue=channel(l+floor_div((int64_t)cb*454,256),signed_output);
   unsigned at=(q*64+y*8+x)*stride;
   if(depth==2){m->output[at]=r;m->output[at+1]=g;m->output[at+2]=blue;}
   else {unsigned rgb=(r>>3)|((g>>3)<<5)|((blue>>3)<<10)|((m->command&0x02000000u)?0x8000u:0);m->output[at]=(uint8_t)rgb;m->output[at+1]=(uint8_t)(rgb>>8);}
  }
  m->output_size=256*stride;
 }
 m->output_position=0;m->macroblocks++;return 1;
}
int LekakMdec_Write(LekakMdec *m,uint32_t address,uint32_t value){
 uint32_t a=address&0x1fffffffu;
 if(a==0x1f801824u){if(value&0x1fffffffu)return -1;if(value&0x80000000u)reset(m);m->control=value&0x60000000u;m->writes++;return 1;}
 if(a!=0x1f801820u)return 0;
 if(m->remaining){
  unsigned cmd=m->command>>29,at=m->received++;
  if(cmd==2)for(unsigned i=0;i<4;i++)m->quant[at*4+i]=(uint8_t)(value>>(i*8));
  else if(cmd==3){m->scale[at*2]=(int16_t)value;m->scale[at*2+1]=(int16_t)(value>>16);}
  else {m->input[at*2]=(uint16_t)value;m->input[at*2+1]=(uint16_t)(value>>16);m->input_count+=2;}
  m->remaining--;m->writes++;return 1;
 }
 if(m->output_position<m->output_size||m->input_position<m->input_count)return -1;
 unsigned cmd=value>>29;
 if(cmd<1||cmd>3)return -1;
 if(cmd==1&&(!(value&0xffffu)||(value&0x01ff0000u)))return -1;
 if(cmd==2&&(value&0x01fffffeu))return -1;
 if(cmd==3&&(value&0x01ffffffu))return -1;
 m->command=value;m->received=m->input_count=m->input_position=0;m->output_size=m->output_position=0;m->reset_status=0;
 m->remaining=cmd==1?value&0xffffu:cmd==2?((value&1u)?32u:16u):32u;
 m->commands++;m->writes++;return 1;
}
int LekakMdec_Read(LekakMdec *m,uint32_t address,uint32_t *value){
 uint32_t a=address&0x1fffffffu;
 if(a==0x1f801824u){*value=LekakMdec_Status(m);m->reads++;return 1;}
 if(a!=0x1f801820u)return 0;
 if(m->remaining)return -1;
 if(m->output_position==m->output_size&&decode(m)!=1)return -1;
 unsigned p=m->output_position;*value=(uint32_t)m->output[p]|((uint32_t)m->output[p+1]<<8)|((uint32_t)m->output[p+2]<<16)|((uint32_t)m->output[p+3]<<24);
 m->output_position+=4;m->reads++;
 if(m->output_position==m->output_size)while(m->input_position<m->input_count&&m->input[m->input_position]==0xfe00)m->input_position++;
 return 1;
}
int LekakMdec_DmaWrite(LekakMdec *m,const uint8_t *bytes,uint32_t words){
 if(!words||words>m->remaining)return -1;
 if(!(m->control&0x40000000u))return 0;
 for(uint32_t i=0;i<words;i++){uint32_t v=0;for(unsigned j=0;j<4;j++)v|=(uint32_t)bytes[i*4+j]<<(j*8);if(LekakMdec_Write(m,0x1f801820u,v)!=1)return -1;}
 return 1;
}
int LekakMdec_DmaRead(LekakMdec *m,uint8_t *bytes,uint32_t words){
 unsigned depth=m->command>>27&3u,size=depth==3?512:depth==2?768:depth==1?64:32;
 if(!words||words%(size/4)||m->output_position!=m->output_size)return -1;
 if(!(m->control&0x20000000u)||m->remaining)return 0;
 /* Transactional validation/decode: no partial RAM output on malformed data.
  * Full buffered command input is a diagnostic simplification of hardware. */
 LekakMdec *copy=malloc(sizeof(*copy));uint8_t *out=malloc((size_t)words*4);
 if(!copy||!out){free(copy);free(out);return -1;}memcpy(copy,m,sizeof(*copy));
 for(uint32_t at=0;at<words*4;at+=size){
  if(decode(copy)!=1){free(copy);free(out);return -1;}
  if(depth<2)memcpy(out+at,copy->output,size);
  else {
   unsigned stride=depth==2?3:2;
   for(unsigned q=0;q<4;q++)for(unsigned y=0;y<8;y++)for(unsigned x=0;x<8;x++){
    unsigned src=(q*64+y*8+x)*stride,dst=(((q>>1)*8+y)*16+(q&1)*8+x)*stride;
    memcpy(out+at+dst,copy->output+src,stride);
   }
  }
  copy->output_position=copy->output_size;
 }
 /* Ignore only actual FE00 command padding after the last complete block. */
 while(copy->input_position<copy->input_count&&copy->input[copy->input_position]==0xfe00)copy->input_position++;
 memcpy(bytes,out,(size_t)words*4);memcpy(m,copy,sizeof(*m));free(copy);free(out);return 1;
}
