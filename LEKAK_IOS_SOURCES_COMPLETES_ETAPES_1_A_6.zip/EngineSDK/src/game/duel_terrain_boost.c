#include "../types.h"
#include "duel_terrain_boost.h"

/* Initialized data at 0x800909D4: the terrain attack modifiers, in card-type
   order. */
s8 gDuel_aTerrainBoost[CARD_TYPE_MAGIC][DUEL_TERRAIN_COUNT] = {
    { 0, 0, DUEL_TERRAIN_BOOST_UNIT, 0, 0, 0 },
    { 0, 0, 0, 0, 0, DUEL_TERRAIN_BOOST_UNIT },
    { 0, DUEL_TERRAIN_BOOST_UNIT, 0, 0, 0, 0 },
    { 0, 0, 0, DUEL_TERRAIN_BOOST_UNIT, 0, 0 },
    { DUEL_TERRAIN_BOOST_UNIT, 0, 0, DUEL_TERRAIN_BOOST_UNIT, 0, 0 },
    { DUEL_TERRAIN_BOOST_UNIT, 0, 0, 0, 0, 0 },
    { 0, 0, DUEL_TERRAIN_BOOST_UNIT, 0, 0, 0 },
    { 0, 0, 0, 0, 0, DUEL_TERRAIN_BOOST_UNIT },
    { 0, 0, 0, 0, 0, DUEL_TERRAIN_PENALTY_UNIT },
    { DUEL_TERRAIN_BOOST_UNIT, 0, 0, 0, 0, 0 },
    { 0, DUEL_TERRAIN_BOOST_UNIT, 0, 0, 0, 0 },
    { 0, 0, 0, 0, 0, 0 },
    { 0, 0, 0, 0, DUEL_TERRAIN_BOOST_UNIT, 0 },
    { 0, 0, 0, 0, DUEL_TERRAIN_BOOST_UNIT, 0 },
    { 0, 0, 0, 0, DUEL_TERRAIN_PENALTY_UNIT, 0 },
    { 0, 0, DUEL_TERRAIN_BOOST_UNIT, 0, DUEL_TERRAIN_BOOST_UNIT, 0 },
    { 0, 0, 0, 0, DUEL_TERRAIN_BOOST_UNIT, 0 },
    { 0, 0, 0, 0, DUEL_TERRAIN_PENALTY_UNIT, 0 },
    { 0, DUEL_TERRAIN_BOOST_UNIT, 0, 0, 0, 0 },
    { DUEL_TERRAIN_BOOST_UNIT, 0, 0, 0, 0, 0 },
};
