#define GINPUT_PAD1_REPEAT_IN_DATA_VOLATILE
#define GINPUT_PAD1_PRESSED_IN_DATA_VOLATILE
#include "../types.h"
#include "display_object.h"
#include "display_object_core.h"
#include "display_object_helpers.h"
#include "display_object_layout.h"
#include "input.h"
#define D_8009B_DISPLAY_OBJECTS_VISIBLE
#include "../unmatched.h"

s32 func_80020988(void) {
    DisplayObject *q;
    s32 one;
    s32 b;
    s32 c;
    s32 v;
    u8 w;

    if ((D_8009B152 & 0x80) == 0) {
        D_8009B152 = D_8009B152 | 0x80;
        one = 1;
        q = DisplayObject_AcquireSlot(DisplayObject_FindFreeGeneralSlot(), 2);
        b = 0xB;
        c = 0x20C;
        DisplayObject_ConfigureSpriteAtPosition(
            q,
            *(s16 *)&D_8009B1CC->field_30.h.field_30 - 8,
            *(s16 *)&D_8009B1CC->field_30.h.field_32 + 0x1E,
            3, one, 2, b, c
        );
        DisplayObject_SelectOrderingTable1(q);
        DisplayObject_SetDepthOffset(q, 0xA);
        /* This merge, the two below it and the first store to 0x60 go
           through the members' addresses with the other signedness rather
           than being plain q->flags and q->field_60 stores. The spelling is
           load-bearing: as member stores, GCC 2.8.1 fills the following
           call's or branch's delay slot with the store and drops the nop,
           which shortens the executable by twelve bytes. The address-of form
           only keeps them non-struct stores because the cast type differs
           from the member's; with the same type fold turns it back into the
           member store. The second 0x60 store can be a plain member store.
           Reads convert normally -- it is only stores standing next to a
           branch that get hoisted. */
        *(s16 *)&q->flags =
            *(s16 *)&q->flags |
            DISPLAY_OBJECT_FLAG_TEXTURE_CELL_OFFSET |
            DISPLAY_OBJECT_FLAG_SCREEN_SPACE;
        D_8009B188 = q;

        q = DisplayObject_AcquireSlot(DisplayObject_FindFreeGeneralSlot(), 2);
        DisplayObject_ConfigureSpriteAtPosition(
            q,
            *(s16 *)&D_8009B1CC->field_30.h.field_30 + 0x3C,
            *(s16 *)&D_8009B1CC->field_30.h.field_32 + 0x1E,
            3, one, 0, b, c
        );
        DisplayObject_SelectOrderingTable1(q);
        DisplayObject_SetDepthOffset(q, 0xA);
        *(s16 *)&q->flags =
            *(s16 *)&q->flags |
            DISPLAY_OBJECT_FLAG_TEXTURE_CELL_OFFSET |
            DISPLAY_OBJECT_FLAG_SCREEN_SPACE;
        D_8009B18C = q;
        return 0;
    }

    q = D_8009B1CC;

    if ((D_8009B152 & 0x40) != 0) {
        *(s16 *)&q->flags =
            *(s16 *)&q->flags | DISPLAY_OBJECT_FLAG_CLIP_TEST;
        v = q->field_20.b.field_21 + *(u8 *)&q->field_60;
        q->field_20.b.field_21 = v;
        w = v;
        if ((v & 0x7F) != 0) {
            return 0;
        }
        if ((w & 0xFF) == 0) {
            *(s16 *)&q->flags =
                *(s16 *)&q->flags & ~DISPLAY_OBJECT_FLAG_CLIP_TEST;
        }
        do { D_8009B152 = D_8009B152 & 0xBF; } while (0);
        return 0;
    }

    if ((gInput_wPad1Repeat & PAD_DIRECTION_HORIZONTAL_MASK) != 0) {
        *(u16 *)&q->field_60 = 0x10;
        if ((gInput_wPad1Repeat & PAD_DIRECTION_RIGHT) != 0) {
            q->field_60 = -0x10;
        }
        D_8009B152 = D_8009B152 | 0x40;
        return 0;
    }

    if ((gInput_wPad1Pressed &
         (PAD_BUTTON_CONFIRM_MASK | PAD_BUTTON_CANCEL)) != 0) {
        DisplayObject_ReleaseIfPresent(D_8009B188);
        DisplayObject_ReleaseIfPresent(D_8009B18C);
        if ((gInput_wPad1Pressed & PAD_BUTTON_CANCEL) != 0) {
            return -1;
        }
        if (q->field_20.b.field_21 == 0) {
            return 1;
        }
        return 2;
    }
    return 0;
}
