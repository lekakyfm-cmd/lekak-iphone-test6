#include "../types.h"
#include "rand_get_interval.h"
#include "../psyq/rand.h"
#include "card_constants.h"
#include "duel_shuffle_deck.h"
#include "duel_shuffle_both_decks.h"
#ifdef MEMORIES_PC
#include "pc/cards/cards.h"
#include "pc/cards/tables.h"
#include <string.h>

/* An opponent's deck dealt from a pool a mod edited (tables.h): the draw
   below, over every card this run has. */
static void Duel_DealEditedDeck(const u16 *pool, u8 *out16, u8 *out8)
{
    static u8 held[CARD_TABLE_ID_END];
    s32 n = 0;
    s32 lim;
    s32 acc;
    s32 i;

    memset(held, 0, sizeof(held));
    while (n < DECK_SIZE) {
        lim = (rand() & (DUEL_DROP_WEIGHT_TOTAL - 1)) + 1;
        acc = 0;
        for (i = 1; i <= gCard_nCount; i++) {
            acc += pool[i];
            if (acc >= lim) {
                break;
            }
        }
        if (i > gCard_nCount || held[i] >= DECK_CARD_COPY_LIMIT) {
            continue;
        }
        held[i]++;
        *(s16 *)out16 = i <= CARD_COUNT ? Cards_PickVariant(i, CARDS_USE_OPPONENT) : i;
        *out8 = n;
        n++;
        out16 += 2;
        out8 += 1;
    }
}

/* An opponent's deck a mod fixed (tables.h): its forty cards as written,
   which the swaps below shuffle. */
static s32 Duel_DealFixedDeck(u8 *out16, u8 *out8)
{
    static u16 fixed[DECK_SIZE];
    s32 n;

    if (!Tables_FixedDeck(Tables_OpponentId(), fixed)) {
        return 0;
    }
    for (n = 0; n < DECK_SIZE; n++) {
        *(s16 *)out16 = fixed[n];
        *out8 = n;
        out16 += 2;
        out8 += 1;
    }
    return 1;
}
#endif

void Duel_ShuffleDeck(s32 src, u8 *out16, u8 *out8) {
    u8 buf[CARD_COUNT];
    u16 *b16;
    u8 *b8;
    u8 *e;
    u8 *t;
    u8 *q;
    s32 i;
    s32 n;
    s32 acc;
    s32 lim;
    s32 x;
    s32 y;
    s32 t16;
    s32 t8;
    s32 u16b;
    s32 u8b;

    b16 = (u16 *)out16;
    b8 = out8;

#ifdef MEMORIES_PC
    if (src == 0 && Duel_DealFixedDeck(out16, out8)) {
    } else if (src == 0 && Tables_Pool(TABLES_POOL_DECK, (const u16 *)gDuel_awOpponentDeckPool) != 0) {
        Duel_DealEditedDeck(Tables_Pool(TABLES_POOL_DECK, (const u16 *)gDuel_awOpponentDeckPool),
                            out16, out8);
    } else
#endif
    if (src == 0) {
        for (i = CARD_COUNT - 1; i >= 0; i--) {
            buf[i] = 0;
        }

        t = gDuel_awOpponentDeckPool;
        n = 0;
        while (n < DECK_SIZE) {
            lim = (rand() & (DUEL_DROP_WEIGHT_TOTAL - 1)) + 1;
            acc = 0;
            i = 0;
            e = t;
            while (1) {
                acc += *(u16 *)e;
                if (acc >= lim) {
                    q = buf + i;
                    if (*q < DECK_CARD_COPY_LIMIT) {
#ifdef MEMORIES_PC
                        /* A copy that asked to may be dealt in its base's
                           place (Cards_PickVariant). */
                        *(s16 *)out16 = Cards_PickVariant(i + 1, CARDS_USE_OPPONENT);
#else
                        *(s16 *)out16 = i + 1;
#endif
                        *out8 = n;
                        n++;
                        out16 += 2;
                        out8 += 1;
                        /* `t16` is the block-copy temp forty lines down; its
                         * live range resumes there, and borrowing the name
                         * here is 10 differences against 4. A fresh local is
                         * not the same thing (the permuter found this). */
                        t16 = *q + 1;
                        *q = t16;
                    }
                    break;
                }
                i++;
                e += 2;
                if (i >= STARTER_DECK_WEIGHT_SCAN_COUNT) {
                    break;
                }
            }
        }
    } else {
        for (i = 0; i < DECK_SIZE; i++) {
            *(s16 *)out16 = *(u16 *G32)src;
            src += 2;
            *out8 = i;
            out8++;
            out16 += 2;
        }
    }

    for (i = 0; i < DUEL_DECK_SHUFFLE_SWAP_COUNT; i++) {
        x = Rand_GetInterval(DECK_SIZE);
        y = Rand_GetInterval(DECK_SIZE);
        t16 = t8 = b16[x];
        u16b = b16[y];
        b16[x] = u16b;
        b16[y] = t16;
        t8 = b8[x];
        u8b = b8[y];
        b8[x] = u8b;
        b8[y] = t8;
    }
}

void Duel_ShuffleBothDecks(void *arg0, void *arg1)
{
    char *base = gDuel_awPlayerShuffledDeck;

    Duel_ShuffleDeck((s32)arg0, (u8 *)base, (u8 *)(base - 0x54));
    Duel_ShuffleDeck((s32)arg1, (u8 *)&((u16 *)base)[DECK_SIZE],
                     (u8 *)(base - 0x2C));
}
