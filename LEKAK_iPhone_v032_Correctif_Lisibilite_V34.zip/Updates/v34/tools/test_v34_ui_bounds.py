#!/usr/bin/env python3
"""Static layout checks for the native 320x240 iPhone viewport, FR/EN.
This verifies the sizing/logic only: final rendering still requires an iPhone.
"""
import re
import unicodedata
from pathlib import Path
root=Path(__file__).resolve().parents[1]
base=root/'SourceMod/Lekak'
font=(base/'ios_ui_font_compact_v34.h').read_text()
gallery=(base/'ios_gallery_v6.h').read_text()
rewards=(base/'rewards.c').read_text()
objectives=(base/'objectives.c').read_text()
progress=(base/'objectives-progress-data.h').read_text()
assert "lekak_ui_font" in font and "'|'" in font
assert 'int small=w/320' in gallery and 'lekak_ui_text(H,' in gallery
assert 'int many=progress_counts[page]>4' in gallery
assert 'PAD_BUTTON_CROSS && progress_counts[page]>4' in objectives
assert 'int status_start=x+cw*61/100' in rewards
assert 'int status_y=gain_y' in rewards
assert 'taken?"PRISE":done?"PRETE":"EN COURS"' in rewards
assert '"L1/R1: pages  CARRE: pretes  TRI: EN"' in rewards

w,h=320,240
x=w*116//1000;right=w*687//1000;cw=right-x
status_start=x+cw*61//100
left_width=status_start-3-x-4
right_width=right-2-status_start
for lang in ("PRETE","EN COURS","PRISE","READY","PENDING","CLAIMED"):
    assert len(lang)*6<=right_width,(lang,len(lang)*6,right_width)
for label in ('+300 etoiles','+100 stars','+600 etoiles'):
    assert len(label)*6<=left_width,(label,len(label)*6,left_width)

rows=[x for x in progress.splitlines() if x.startswith('{{')]
assert len(rows)==40,len(rows)
pattern=re.compile(r'\{[0-7],"[^"]*",\d+,"([^"]*)","([^"]*)"\}')
for language in (0,1):
    for page,row in enumerate(rows):
        conditions=pattern.findall(row)
        assert conditions,(page,row)
        groups=[conditions] if len(conditions)<=4 else [conditions[:len(conditions)//2],conditions[len(conditions)//2:]]
        for half,criteria in enumerate(groups):
            lines=0
            for cond in criteria:
                title=cond[language]+" : 0/100" # widest standard numeric goal
                title=''.join(t for ch in title for t in unicodedata.normalize('NFKD',ch) if ord(t)<128)
                words=title.split(' ');line=''
                for word in words:
                    trial=(line+' '+word).strip()
                    if len(trial)*6<=80:line=trial
                    else:lines+=1;line=word
                lines+=1
            assert lines<=len(criteria)*8,(language,page+1,half,lines)
            height=14+8*lines+3
            assert height<=240*(822-340)//1000,(language,page+1,half,height)
for text in (
 'HAUT/BAS: choix  L1/R1: page', 'O: retour  CARRE: defis  TRI: EN', 'X: autres conditions',
 'UP/DOWN: select  L1/R1: page', 'O: back  SQ: rewards  TRI: FR','X: more conditions',
 'L1/R1: pages  CARRE: pretes  TRI: EN', 'L1/R1: tabs  SQ: ready  TRI: FR',
):
    assert len(text)*6<=w*760//1000,(text,len(text)*6)
print('UI v34: 40 duelists x FR/EN, progress paging, statuses & control guide fit at 320x240.')
