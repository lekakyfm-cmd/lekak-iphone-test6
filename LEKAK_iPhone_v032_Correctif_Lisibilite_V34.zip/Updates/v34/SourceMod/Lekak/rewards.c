#include "pc/mods/modapi.h"
#include "pc/cards/cards.h"
#include "pc/cards/tables.h"
#include "pc/free_duel/duelists.h"
#include "game/input.h"
#include "game/display_object.h"
#include "overlays/main_menu/frontend.h"
#include "game/duel_result_display.h"
#include "pc/platform/title_screen.h"
#include <string.h>
#include <stdio.h>
#include "rewards-logic.h"
#include "rewards-data.h"
#include "ios_rewards_art_v2.h"
/* SAVE_DATA_RESERVED_TAIL_OFFSET=0x628, size=0x58. The game's payload
 * builder clears this unsealed tail; preserve our verified ledger after
 * it builds both identical copies. No card quantities or stock CRC move. */
#define TAIL_OFFSET 0x628
#define STATE_OFFSET 0x200
#define DUP_OFFSET 0x880
static const MemoriesModHost *host;
static uint8_t *save_base;
static int8_t *opponent,*winner;
static uint32_t *starchips;
static void (*old_build)(void *);
static void (*old_apply)(void *);
static int (*old_title)(void);
static unsigned serial=1;
static int opened,category,row,english,corrupt;
#define AVAILABLE_CATEGORY (ROSTER_COUNT+1)
#define CATEGORY_COUNT (ROSTER_COUNT+2)
static int available_keys[ROSTER_COUNT*5+GROUP_COUNT],available_count;
static char notice[112];
static const int goals[4]={1,10,25,50};
static const unsigned prizes[5]={20,100,300,600,100};
static RewardSave *ledger(void){return (RewardSave *)(save_base+TAIL_OFFSET);}
static uint32_t save_code(void){uint32_t n;memcpy(&n,save_base+0x334,4);return n;}
static RewardSave *ready(void){
 RewardSave *s=ledger();uint32_t code=save_code();
 corrupt=0;
 if(s->magic==REWARD_MAGIC && s->duelist_code==code){
  if(!reward_valid(s,code)){corrupt=1;return 0;}
 }else{
  memset(s,0,sizeof(*s));s->magic=REWARD_MAGIC;s->version=1;s->duelist_code=code;reward_seal(s);
 }
 return s;
}
static int duelist(int index){return Duelists_Named(roster[index].ref);}
static int wins(int index){int id=duelist(index);return id>0?Duelists_RecordSlot(save_base,id)[0]:0;}
static int group_progress(int g){
 const GroupSpec *r=&groups[g];int n=0;
 for(int i=0;i<r->count;i++)n+=wins(r->members[i])>=r->target;
 return n;
}
static int complete(int cat,int line,RewardSave *s){
 if(cat<ROSTER_COUNT)return line<4?wins(cat)>=goals[line]:reward_tec(s,cat);
 return line>=0&&line<GROUP_COUNT&&group_progress(line)==groups[line].count;
}
static int key_for(int cat,int line){return cat<ROSTER_COUNT?cat*5+line:ROSTER_COUNT*5+line;}
static void available(RewardSave *s){
 available_count=0;if(!s)return;
 for(int cat=0;cat<=ROSTER_COUNT;cat++){
  int count=cat<ROSTER_COUNT?5:GROUP_COUNT;
  for(int i=0;i<count;i++){
   int key=key_for(cat,i);
   if(!reward_claimed(s,key)&&complete(cat,i,s))available_keys[available_count++]=key;
  }
 }
 if(category==AVAILABLE_CATEGORY&&row>=available_count)row=available_count?available_count-1:0;
}
static int rows(void){return category==AVAILABLE_CATEGORY?available_count:category<ROSTER_COUNT?5:GROUP_COUNT;}
static int selection(int *cat,int *line){
 *cat=category;*line=row;
 if(category==AVAILABLE_CATEGORY){
  available(ready());if(!available_count)return 0;
  int key=available_keys[row];
  *cat=key<ROSTER_COUNT*5?key/5:ROSTER_COUNT;
  *line=key<ROSTER_COUNT*5?key%5:key-ROSTER_COUNT*5;
 }
 return 1;
}
static void build(void *payload){
 RewardSave copy;RewardSave *s=ready();int keep=s!=0;
 if(keep)memcpy(&copy,s,sizeof(copy));
 old_build(payload);
 if(keep){
  memcpy((uint8_t *)payload+STATE_OFFSET+TAIL_OFFSET,&copy,sizeof(copy));
  memcpy((uint8_t *)payload+DUP_OFFSET+TAIL_OFFSET,&copy,sizeof(copy));
  memcpy(ledger(),&copy,sizeof(copy));
 }
}
static void apply(void *state){
 RewardSave copy;memcpy(&copy,(uint8_t *)state+TAIL_OFFSET,sizeof(copy));
 old_apply(state);memcpy(ledger(),&copy,sizeof(copy));
 opened=0;notice[0]=0;serial++;
}
static void awarded(MemoriesModEvent *event){
 if(event->phase!=MEMORIES_AFTER||*winner!=0||!D_8009B1E8)return;
 if(!D_8009B1E8->is_tec_rank||D_8009B1E8->rank_tier<3)return;
 RewardSave *s=ready();if(!s)return;
 for(int i=0;i<ROSTER_COUNT;i++)if(duelist(i)==*opponent){reward_mark_tec(s,i);serial++;break;}
}
static int objectives_open(void){
 if(gMain_bMenuID<5||gMain_bMenuID>10||D_80184599||D_80184598||D_8018459A
  ||D_8018459B||D_8018459C||D_8018459D)return 0;
 int count=0;
 for(int i=5;i<11;i++){
  DisplayObject *o=(DisplayObject *)gMain_apMenuEntries[i];
  if(o){count++;if(o->flags&DISPLAY_OBJECT_FLAG_RENDERABLE)return 0;}
 }
 return count>=3;
}
static void message(const char *fr,const char *en){snprintf(notice,sizeof(notice),"%s",english?en:fr);serial++;}
static int reward_card(const GroupSpec *g){return g->card?Cards_Named(g->card):0;}
static void claim(void){
 RewardSave *s=ready();int cat,line;
 if(!selection(&cat,&line)){message("Aucune recompense disponible.","No rewards available.");return;}
 int key=key_for(cat,line);unsigned amount;
 if(!s){message("Suivi endommage : recharge une sauvegarde valide.","Ledger damaged: load a valid save.");return;}
 if(reward_claimed(s,key)){message("Deja recuperee sur cette sauvegarde.","Already claimed on this save.");return;}
 if(!complete(cat,line,s)){message("Objectif pas encore atteint.","Goal not yet completed.");return;}
 amount=cat<ROSTER_COUNT?prizes[line]:groups[line].stars;
 if(amount){
  if(!reward_stars_fit(*starchips,amount,Tables_StarchipCap())){
   message("Limite d'etoiles : depense avant de recuperer.","Star-chip limit: spend some before claiming.");return;
  }
  *starchips+=amount;
 }else{
  int id=reward_card(&groups[line]);
  if(id<=0||!Cards_Valid(id)){message("Carte indisponible : recompense conservee.","Card unavailable: reward remains unclaimed.");return;}
  uint8_t *quantity=Cards_ChestSlot(save_base,id);
  if(*quantity>=Tables_ChestRoom()){message("Coffre plein pour cette carte.","Trunk is full for this card.");return;}
  /* Quest rewards are not duel drops: do not invoke drop hooks or alter
     the last-duel display and recent-drop history. */
  (*quantity)++;Cards_MarkSeen(id);
 }
 reward_mark(s,key);available(s);
 message("Recuperee ! Pense a sauvegarder ta partie.","Claimed! Remember to save your game.");
}
static int title(void){
 uint16_t p=gInput_wPad1Pressed,n=p|gInput_wPad1Repeat;
 if(!opened){
  if(objectives_open()&&(p&PAD_BUTTON_SQUARE)){
   opened=1;category=AVAILABLE_CATEGORY;row=0;notice[0]=0;available(ready());serial++;
   gInput_wPad1Pressed=gInput_wPad1Held=gInput_wPad1Repeat=0;return -1;
  }
  return old_title();
 }
 if(p&PAD_BUTTON_CANCEL){opened=0;notice[0]=0;serial++;}
 else if(p&PAD_BUTTON_TRIANGLE){english=!english;host->set_setting(host,"language",english);notice[0]=0;serial++;}
 else if(p&PAD_BUTTON_SQUARE){category=AVAILABLE_CATEGORY;row=0;available(ready());notice[0]=0;serial++;}
 else if(p&(PAD_BUTTON_R1|PAD_DIRECTION_RIGHT)){category=(category+1)%CATEGORY_COUNT;row=0;notice[0]=0;serial++;}
 else if(p&(PAD_BUTTON_L1|PAD_DIRECTION_LEFT)){category=(category+CATEGORY_COUNT-1)%CATEGORY_COUNT;row=0;notice[0]=0;serial++;}
 else if(n&(PAD_DIRECTION_DOWN|PAD_BUTTON_R2)){int count=rows();if(count)row=(row+((n&PAD_BUTTON_R2)?5:1))%count;notice[0]=0;serial++;}
 else if(n&(PAD_DIRECTION_UP|PAD_BUTTON_L2)){int count=rows();if(count)row=(row+count-(((n&PAD_BUTTON_L2)?5:1)%count))%count;notice[0]=0;serial++;}
 else if(p&PAD_BUTTON_CROSS)claim();
 gInput_wPad1Pressed=gInput_wPad1Held=gInput_wPad1Repeat=0;
 return -1;
}
static int text_right;
typedef struct { char code; unsigned char rows[7]; } RewardGlyph;
/* --- the fallback font ----------------------------------------------- */

/* 5x7 glyphs, one bit per pixel, the top row first. */
static const RewardGlyph reward_font[] = {
    {' ', {0, 0, 0, 0, 0, 0, 0}},
    {'0', {0x0e, 0x11, 0x13, 0x15, 0x19, 0x11, 0x0e}}, {'1', {0x04, 0x0c, 0x04, 0x04, 0x04, 0x04, 0x0e}},
    {'2', {0x0e, 0x11, 0x01, 0x02, 0x04, 0x08, 0x1f}}, {'3', {0x1f, 0x02, 0x04, 0x02, 0x01, 0x11, 0x0e}},
    {'4', {0x02, 0x06, 0x0a, 0x12, 0x1f, 0x02, 0x02}}, {'5', {0x1f, 0x10, 0x1e, 0x01, 0x01, 0x11, 0x0e}},
    {'6', {0x06, 0x08, 0x10, 0x1e, 0x11, 0x11, 0x0e}}, {'7', {0x1f, 0x01, 0x02, 0x04, 0x08, 0x08, 0x08}},
    {'8', {0x0e, 0x11, 0x11, 0x0e, 0x11, 0x11, 0x0e}}, {'9', {0x0e, 0x11, 0x11, 0x0f, 0x01, 0x02, 0x0c}},
    {'A', {0x0e, 0x11, 0x11, 0x1f, 0x11, 0x11, 0x11}}, {'B', {0x1e, 0x11, 0x11, 0x1e, 0x11, 0x11, 0x1e}},
    {'C', {0x0e, 0x11, 0x10, 0x10, 0x10, 0x11, 0x0e}}, {'D', {0x1e, 0x11, 0x11, 0x11, 0x11, 0x11, 0x1e}},
    {'E', {0x1f, 0x10, 0x10, 0x1e, 0x10, 0x10, 0x1f}}, {'F', {0x1f, 0x10, 0x10, 0x1e, 0x10, 0x10, 0x10}},
    {'G', {0x0e, 0x11, 0x10, 0x17, 0x11, 0x11, 0x0f}}, {'H', {0x11, 0x11, 0x11, 0x1f, 0x11, 0x11, 0x11}},
    {'I', {0x0e, 0x04, 0x04, 0x04, 0x04, 0x04, 0x0e}}, {'J', {0x07, 0x02, 0x02, 0x02, 0x02, 0x12, 0x0c}},
    {'K', {0x11, 0x12, 0x14, 0x18, 0x14, 0x12, 0x11}}, {'L', {0x10, 0x10, 0x10, 0x10, 0x10, 0x10, 0x1f}},
    {'M', {0x11, 0x1b, 0x15, 0x15, 0x11, 0x11, 0x11}}, {'N', {0x11, 0x11, 0x19, 0x15, 0x13, 0x11, 0x11}},
    {'O', {0x0e, 0x11, 0x11, 0x11, 0x11, 0x11, 0x0e}}, {'P', {0x1e, 0x11, 0x11, 0x1e, 0x10, 0x10, 0x10}},
    {'Q', {0x0e, 0x11, 0x11, 0x11, 0x15, 0x12, 0x0d}}, {'R', {0x1e, 0x11, 0x11, 0x1e, 0x14, 0x12, 0x11}},
    {'S', {0x0f, 0x10, 0x10, 0x0e, 0x01, 0x01, 0x1e}}, {'T', {0x1f, 0x04, 0x04, 0x04, 0x04, 0x04, 0x04}},
    {'U', {0x11, 0x11, 0x11, 0x11, 0x11, 0x11, 0x0e}}, {'V', {0x11, 0x11, 0x11, 0x11, 0x11, 0x0a, 0x04}},
    {'W', {0x11, 0x11, 0x11, 0x15, 0x15, 0x15, 0x0a}}, {'X', {0x11, 0x11, 0x0a, 0x04, 0x0a, 0x11, 0x11}},
    {'Y', {0x11, 0x11, 0x11, 0x0a, 0x04, 0x04, 0x04}}, {'Z', {0x1f, 0x01, 0x02, 0x04, 0x08, 0x10, 0x1f}},
    {'a', {0x00, 0x00, 0x0e, 0x01, 0x0f, 0x11, 0x0f}}, {'b', {0x10, 0x10, 0x16, 0x19, 0x11, 0x11, 0x1e}},
    {'c', {0x00, 0x00, 0x0e, 0x10, 0x10, 0x11, 0x0e}}, {'d', {0x01, 0x01, 0x0d, 0x13, 0x11, 0x11, 0x0f}},
    {'e', {0x00, 0x00, 0x0e, 0x11, 0x1f, 0x10, 0x0e}}, {'f', {0x06, 0x09, 0x08, 0x1c, 0x08, 0x08, 0x08}},
    {'g', {0x00, 0x0f, 0x11, 0x11, 0x0f, 0x01, 0x0e}}, {'h', {0x10, 0x10, 0x16, 0x19, 0x11, 0x11, 0x11}},
    {'i', {0x04, 0x00, 0x0c, 0x04, 0x04, 0x04, 0x0e}}, {'j', {0x02, 0x00, 0x06, 0x02, 0x02, 0x12, 0x0c}},
    {'k', {0x10, 0x10, 0x12, 0x14, 0x18, 0x14, 0x12}}, {'l', {0x0c, 0x04, 0x04, 0x04, 0x04, 0x04, 0x0e}},
    {'m', {0x00, 0x00, 0x1a, 0x15, 0x15, 0x15, 0x15}}, {'n', {0x00, 0x00, 0x16, 0x19, 0x11, 0x11, 0x11}},
    {'o', {0x00, 0x00, 0x0e, 0x11, 0x11, 0x11, 0x0e}}, {'p', {0x00, 0x00, 0x1e, 0x11, 0x1e, 0x10, 0x10}},
    {'q', {0x00, 0x00, 0x0d, 0x13, 0x0f, 0x01, 0x01}}, {'r', {0x00, 0x00, 0x16, 0x19, 0x10, 0x10, 0x10}},
    {'s', {0x00, 0x00, 0x0f, 0x10, 0x0e, 0x01, 0x1e}}, {'t', {0x08, 0x08, 0x1c, 0x08, 0x08, 0x09, 0x06}},
    {'u', {0x00, 0x00, 0x11, 0x11, 0x11, 0x13, 0x0d}}, {'v', {0x00, 0x00, 0x11, 0x11, 0x11, 0x0a, 0x04}},
    {'w', {0x00, 0x00, 0x11, 0x11, 0x15, 0x15, 0x0a}}, {'x', {0x00, 0x00, 0x11, 0x0a, 0x04, 0x0a, 0x11}},
    {'y', {0x00, 0x00, 0x11, 0x11, 0x0f, 0x01, 0x0e}}, {'z', {0x00, 0x00, 0x1f, 0x02, 0x04, 0x08, 0x1f}},
    {'-', {0x00, 0x00, 0x00, 0x1f, 0x00, 0x00, 0x00}}, {'.', {0x00, 0x00, 0x00, 0x00, 0x00, 0x0c, 0x0c}},
    {':', {0x00, 0x0c, 0x0c, 0x00, 0x0c, 0x0c, 0x00}}, {'(', {0x02, 0x04, 0x08, 0x08, 0x08, 0x04, 0x02}},
    {')', {0x08, 0x04, 0x02, 0x02, 0x02, 0x04, 0x08}}, {'/', {0x01, 0x01, 0x02, 0x04, 0x08, 0x10, 0x10}},
    {',', {0x00, 0x00, 0x00, 0x00, 0x0c, 0x04, 0x08}}, {';', {0x00, 0x0c, 0x0c, 0x00, 0x0c, 0x04, 0x08}},
    {'\'', {0x0c, 0x04, 0x08, 0x00, 0x00, 0x00, 0x00}}, {'!', {0x04, 0x04, 0x04, 0x04, 0x04, 0x00, 0x04}},
    {'[', {0x0e,0x08,0x08,0x08,0x08,0x08,0x0e}},
    {']', {0x0e,0x02,0x02,0x02,0x02,0x02,0x0e}},
    {'>', {0x10,0x08,0x04,0x02,0x04,0x08,0x10}},
    {'+', {0,0x04,0x04,0x1f,0x04,0x04,0}},
    {'=', {0,0,0x1f,0,0x1f,0,0}},
    {'?', {0x0e, 0x11, 0x01, 0x02, 0x04, 0x00, 0x04}},
};
static const int reward_font_count = (int)(sizeof(reward_font) / sizeof(reward_font[0]));

/* Rewards use 5x7 glyphs with a 6-pixel advance, half the port's
 * 10x14 fallback font. Keep the same integer scale as the panel. */
static int small_width(const char *v,int scale){return (int)strlen(v)*6*scale;}
static void text(int x,int y,const char *value,unsigned color,int scale){
 char clipped[160];snprintf(clipped,sizeof(clipped),"%s",value);
 int n=strlen(clipped),cut=0;
 while(n>0&&small_width(clipped,scale)>text_right-x){clipped[--n]=0;cut=1;}
 if(cut&&n>=3){clipped[n-1]=clipped[n-2]=clipped[n-3]='.';}
 for(const char *at=clipped;*at;at++,x+=6*scale){
  const RewardGlyph *glyph=0;
  for(int i=0;i<reward_font_count;i++)if(reward_font[i].code==*at){glyph=&reward_font[i];break;}
  if(!glyph)for(int i=0;i<reward_font_count;i++)if(reward_font[i].code=='?'){glyph=&reward_font[i];break;}
  if(!glyph)continue;
  for(int row=0;row<7;row++)for(int col=0;col<5;col++)
   if(glyph->rows[row]&(0x10>>col))host->fill(host,x+col*scale,y-3*scale+row*scale,scale,scale,color,255);
 }
}
/* Art-only background: RLE palette from the Windows V2 accepted UI. */
static void ios_reward_backdrop(int w,int h){
 for(int row=0;row<REWARDS_ART_H;row++){
  int top=row*h/REWARDS_ART_H,bottom=(row+1)*h/REWARDS_ART_H,px=0;
  if(top==bottom)continue;
  for(unsigned k=rewards_art_rows[row];k<rewards_art_rows[row+1];k++){
   int x0=px*w/REWARDS_ART_W;px+=rewards_art_runs[k].n;
   int x1=px*w/REWARDS_ART_W;
   if(x1>x0)host->fill(host,x0,top,x1-x0,bottom-top,rewards_art_palette[rewards_art_runs[k].index],255);
  }
 }
}
static void reward_rule(int x,int y,int width,unsigned color){
 if(width>0)host->fill(host,x,y,width,1,color,230);
}
static void overlay(void){
 if(!opened)return;
 int w,h,s;host->overlay_size(host,&w,&h,&s);
 if(w<240||h<180)return;
 s=w/640;if(s>h/480)s=h/480;if(s<1)s=1;
 ios_reward_backdrop(w,h);
 RewardSave *state=ready();available(state);
 char buf[170];
 /* Windows V2 composition; the left panel stays opaque, right temple visible. */
 int x=w*116/1000,right=w*687/1000,cw=right-x;
 int header=h*205/1000,ys=h*309/1000,step=h*88/1000;
 int status_start=x+cw*61/100,compact=(w<650);
 int name_y=compact?3*s:13*s,gain_y=compact?13*s:31*s;
 int status_y=gain_y;
 text_right=right-8*s;
 if(category==AVAILABLE_CATEGORY)
  snprintf(buf,sizeof(buf),english?"AVAILABLE REWARDS (%d)":"RECOMPENSES DISPONIBLES (%d)",available_count);
 else snprintf(buf,sizeof(buf),"%s  %d/%d",category<ROSTER_COUNT?roster[category].name:(english?"SPECIAL GOALS":"OBJECTIFS SPECIAUX"),category+1,CATEGORY_COUNT);
 text(x+5*s,header+3*s,buf,0xFFDA92,s);
 snprintf(buf,sizeof(buf),english?"Stars: %u":"Etoiles : %u",*starchips);
 text(x+5*s,header+16*s,buf,0xDED1E7,s);
 for(int k=0;k<5;k++){
  int index=(row/5)*5+k,count=rows();if(index>=count)break;
  int yy=ys+k*step,sel=index==row,cat=category,goal=index,taken=0,done=0;
  if(sel)host->fill(host,x+2*s,yy+1*s,cw-4*s,step-2*s,0x342A42,250);
  reward_rule(x+2*s,yy+step-1*s,cw-4*s,sel?0xE3BA73:0x614C48);
  if(category==AVAILABLE_CATEGORY){
   int key=available_keys[index];cat=key<ROSTER_COUNT*5?key/5:ROSTER_COUNT;
   goal=key<ROSTER_COUNT*5?key%5:key-ROSTER_COUNT*5;done=1;
  }else{
   taken=state&&reward_claimed(state,key_for(cat,goal));done=state&&complete(cat,goal,state);
  }
  text_right=right-6*s; /* Entire first line belongs to the goal. */
  if(cat<ROSTER_COUNT){
   if(category==AVAILABLE_CATEGORY){
    if(goal<4)snprintf(buf,sizeof(buf),english?"%s - %d wins":"%s - %d victoires",roster[cat].name,goals[goal]);
    else snprintf(buf,sizeof(buf),"%s - S/A TEC",roster[cat].name);
   }else if(goal<4)snprintf(buf,sizeof(buf),english?"%d wins (%d/%d)":"%d victoires (%d/%d)",goals[goal],wins(cat)>goals[goal]?goals[goal]:wins(cat),goals[goal]);
   else snprintf(buf,sizeof(buf),english?"First S/A TEC win":"Premiere victoire S/A TEC");
   text(x+4*s,yy+name_y,buf,taken?0xB1A0B8:0xEEE4FF,s);
   snprintf(buf,sizeof(buf),english?"+%u stars":"+%u etoiles",prizes[goal]);
  }else{
   const GroupSpec *g=&groups[goal];
   text(x+4*s,yy+name_y,english?g->en:g->name,taken?0xB1A0B8:0xEEE4FF,s);
   if(g->stars)snprintf(buf,sizeof(buf),english?"+%u stars":"+%u etoiles",g->stars);
   else snprintf(buf,sizeof(buf),"%s x1",g->card_name);
  }
  text_right=status_start-3*s; /* Prize occupies left part of second row. */
  text(x+4*s,yy+gain_y,buf,0xE5B96E,s);
  const char *status=english?(taken?"CLAIMED":done?"READY":"PENDING"):(taken?"PRISE":done?"PRETE":"EN COURS");
  int sx=right-7*s-small_width(status,s);if(sx<status_start)sx=status_start;
  text_right=right-2*s;
  text(sx,yy+status_y,status,taken?0xAB9CA7:done?0x8DF79B:0xFFD087,s);
 }
 if(category==AVAILABLE_CATEGORY&&!available_count){
  text_right=right-8*s;
  text(x+4*s,ys+3*s,english?"No rewards yet.":"Aucune recompense.",0xD3C7D9,s);
 }
 int fy=h*795/1000,fx=w*115/1000,fr=w*895/1000;
 text_right=fr-3*s;
 if(corrupt)text(fx+5*s,fy+3*s,english?"Ledger invalid":"Suivi endommage",0xFFAAAA,s);
 else if(notice[0])text(fx+5*s,fy+3*s,notice,0xFFDA92,s);
 else text(fx+5*s,fy+3*s,english?"Claim once; save after.":"Un gain par defi; sauvegarder.",0xD6C6DE,s);
 text(fx+5*s,fy+14*s,english?"UP/DOWN: choose  X: claim  O: back":"HAUT/BAS: choix  X: prendre  O: retour",0xEEE6F1,s);
 text(fx+5*s,fy+25*s,english?"L1/R1: tabs  SQ: ready  TRI: FR":"L1/R1: pages  CARRE: pretes  TRI: EN",0xEDCB82,s);
}
static unsigned signature(void){return serial;}
static void reset(void){opened=0;notice[0]=0;serial++;}
static void applied(int on){(void)on;reset();}
int MemoriesModInit(const MemoriesModHost *h,MemoriesMod *m){
 if(h->api<6||!h->subscribe||!h->hook||!h->unhook||!h->overlay_size)return 0;host=h;
 save_base=h->symbol(h,"gDuel_awPlayerDeck");opponent=h->symbol(h,"gDuel_bOpponentID");
 winner=h->symbol(h,"gDuel_bWinnerSide");starchips=h->symbol(h,"gLibrary_dwStarchips");
 if(!save_base||!opponent||!winner||!starchips)return 0;
 void *fn=h->symbol(h,"SaveData_BuildPayload");
 int build_token=fn?h->hook(h,fn,build,(void **)&old_build):0;
 if(!build_token)return 0;
 fn=h->symbol(h,"SaveData_ApplyRuntimeState");
 int apply_token=fn?h->hook(h,fn,apply,(void **)&old_apply):0;
 if(!apply_token){h->unhook(h,build_token);return 0;}
 int title_token=h->hook(h,TitleScreen_Update,title,(void **)&old_title);
 if(!title_token){h->unhook(h,apply_token);h->unhook(h,build_token);return 0;}
 if(!h->subscribe(h,MEMORIES_EVENT_STARCHIP,0,awarded)){
  h->unhook(h,title_token);h->unhook(h,apply_token);h->unhook(h,build_token);return 0;
 }
 english=h->setting(h,"language",0)!=0;
 m->api=6;m->name="Lekak - Rewards iPhone test v1.1";m->overlay=overlay;
 m->overlay_signature=signature;m->reset=reset;m->applied=applied;
 if(h->log)h->log(h,"Rewards v1: 409 permanent goals, save-tail ledger, Square inside Objectives");
 return 1;
}
