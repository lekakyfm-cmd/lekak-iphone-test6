#!/usr/bin/env python3
"""Place the UI-only v33 source overlay after v32 in the EXISTING 0.32 pipeline.

Does not recompile, resign, touch an IPA, or change bundle identifier/version.
"""
from pathlib import Path
import sys,shutil,hashlib,plistlib
PATCH=Path(__file__).resolve().parent
SRC=PATCH/'Updates/v33'
WORKFLOW=Path('.github/workflows/lekak-native-ios.yml')
OLD='          cp -R Updates/v32/. .\n'
NEW='          cp -R Updates/v33/. .\n'

def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def apply(project):
 project=project.resolve()
 workflow=project/WORKFLOW
 manifest=project/'Updates/v32/tools/build_native_ipa.py'
 info=project/'App/Info.plist'
 assert SRC.is_dir(), 'Missing v33 patch layer.'
 for file in [workflow,manifest,info,project/'Updates/v31/SourceMod/Lekak/Collection/collection.c']:
  if not file.is_file():raise SystemExit(f'Not a complete v0.32 source project: {file}')
 identity=plistlib.loads(info.read_bytes())
 if identity.get('CFBundleIdentifier')!='org.lekak.iosprobe':
  raise SystemExit('Unexpected Bundle ID: refusing to modify project')
 build=manifest.read_text(encoding='utf-8')
 if "CFBundleShortVersionString='0.32'" not in build or "CFBundleVersion='32'" not in build:
  raise SystemExit('Build script is not the expected v0.32/build 32. No changes made.')
 wf=workflow.read_text(encoding='utf-8')
 if NEW not in wf and wf.count(OLD)!=1:
  raise SystemExit('Cannot identify v32 layer in workflow. No changes made.')
 # Verify files can be installed without overwriting a foreign update.
 destination=project/'Updates/v33'
 for f in SRC.rglob('*'):
  if f.is_file():
   dest=destination/f.relative_to(SRC)
   if dest.exists() and digest(dest)!=digest(f):
    raise SystemExit(f'Conflicting v33 file: {dest}. No changes made.')
 # Save previous workflow for future restoration.
 backup=workflow.with_name(workflow.name+'.avant_UI_v33')
 if NEW not in wf and not backup.exists():shutil.copy2(workflow,backup)
 for f in SRC.rglob('*'):
  if f.is_file():
   dest=destination/f.relative_to(SRC);dest.parent.mkdir(parents=True,exist_ok=True)
   shutil.copy2(f,dest)
 if NEW not in wf:
  workflow.write_text(wf.replace(OLD,OLD+NEW,1),encoding='utf-8')
 print('SUCCESS: Updates/v33 applied after v32 to the existing project.')
 print('Bundle ID: org.lekak.iosprobe | version 0.32 | build 32 (UNCHANGED)')
 print('Rebuild the SAME native IPA using the repository workflow. Sign as usual.')
if __name__=='__main__':
 if len(sys.argv)!=2:raise SystemExit('Usage: python3 APPLIQUER_A_LA_BUILD_v032.py /path/to/Lekak_iPhone_v0.32')
 apply(Path(sys.argv[1]))
