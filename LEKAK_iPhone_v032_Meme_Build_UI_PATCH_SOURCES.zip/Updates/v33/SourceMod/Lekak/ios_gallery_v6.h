/* iOS adapted from Windows V6. All display text and progress values are dynamic. */
#ifndef LEKAK_IPHONE_GALLERY_V6_H
#define LEKAK_IPHONE_GALLERY_V6_H
#include "ios_duellistes_art_v6.h"
#include "ios_duellistes_portraits_v6.h"
static const MemoriesModHost *H;
static void (*ios_previous_overlay)(void);
static void rect(int x,int y,int w,int h,unsigned rgb,unsigned a){if(w>0&&h>0)H->fill(H,x,y,w,h,rgb,a);}
static int X(int w,int fraction){return (w*fraction)/1000;}
static void draw_art(int w,int h){
 for(int y=0;y<ART_H;y++){
  int y0=y*h/ART_H, y1=(y+1)*h/ART_H,x=0;
  if(y1<=y0)continue;
  for(unsigned k=art_offsets[y];k<art_offsets[y+1];k++){
   int x0=x*w/ART_W; x+=art_runs[k].n;int x1=x*w/ART_W;
   if(x1>x0)rect(x0,y0,x1-x0,y1-y0,art_palette[art_runs[k].c],255);
  }
 }
}
static void translit(const char *s,char *out,unsigned cap){
 unsigned o=0;
 for(unsigned i=0;s&&s[i]&&o+1<cap;i++){
  unsigned char c=(unsigned char)s[i];
  if(c<128){out[o++]=c;continue;}
  if(c==0xc3 && s[i+1]){
   unsigned char t=(unsigned char)s[++i];
   if(t==0xa9||t==0xa8||t==0xaa||t==0xab||t==0x89||t==0x88||t==0x8a)out[o++]='e';
   else if(t==0xa0||t==0xa1||t==0xa2||t==0xa4)out[o++]='a';
   else if(t==0xb4||t==0xb6)out[o++]='o';
   else if(t==0xbb||t==0xb9)out[o++]='u';
   else if(t==0xa7)out[o++]='c';
   else if(t==0xae||t==0xaf)out[o++]='i';
   else out[o++]='?';
  }else if(c==0xc2 && s[i+1]){i++;out[o++]=' ';}
 }
 out[o]=0;
}
static void text(int x,int y,const char *src,unsigned rgb,int scale,int maxw){
 char s[256];translit(src,s,sizeof(s));
 int n=(int)strlen(s),truncated=0;
 while(n>0 && H->text_width(H,s,scale)>maxw){s[--n]=0;truncated=1;}
 if(truncated){
  while(n>0 && H->text_width(H,s,scale)+H->text_width(H,"...",scale)>maxw)s[--n]=0;
  if(n+3<(int)sizeof(s)){strcat(s,"...");}
 }
 H->draw_text(H,x,y,s,rgb,scale);
}
/* Les descriptions sont rendues seulement dans PROGRESS.
 * Le retour a la ligne est calcule avec les largeurs du moteur, pas des caracteres fixes.
 */
#define MAX_LINES 4
static int word_lines(const char *source,int scale,int maxw,char lines[MAX_LINES][256]){
 char ascii[256];translit(source,ascii,sizeof(ascii));
 for(int i=0;i<MAX_LINES;i++)lines[i][0]=0;
 int current=0;
 const char *p=ascii;
 while(*p){
  while(*p==' ')p++;
  if(!*p)break;
  char word[256];unsigned n=0;
  while(*p&&*p!=' '&&n+1<sizeof(word))word[n++]=*p++;
  word[n]=0;
  /* Un mot plus large que le panneau : le separer en morceaux lisibles. */
  unsigned offset=0;
  while(offset<n){
   char trial[256],part[256];
   unsigned count=n-offset;
   memcpy(part,word+offset,count);part[count]=0;
   if(lines[current][0])snprintf(trial,sizeof(trial),"%s %s",lines[current],part);
   else snprintf(trial,sizeof(trial),"%s",part);
   if(H->text_width(H,trial,scale)<=maxw){
    strcpy(lines[current],trial);offset=n;continue;
   }
   if(lines[current][0]){
    if(current+1<MAX_LINES){current++;continue;}
    /* Derniere ligne : un niveau de police inferieur est essaye au rendu. */
    return MAX_LINES+1;
   }
   /* Coupe un mot trop long, sans perdre les caracteres suivants. */
   unsigned cut=1;
   while(cut<count){
    char tmp[256];memcpy(tmp,word+offset,cut+1);tmp[cut+1]=0;
    if(H->text_width(H,tmp,scale)>maxw)break;
    cut++;
   }
   memcpy(lines[current],word+offset,cut);lines[current][cut]=0;
   offset+=cut;
   if(offset<n){if(current+1<MAX_LINES)current++;else return MAX_LINES+1;}
  }
 }
 return current+1;
}
static int progression(const ProgressCondition *c){
 int id,n=0;
 switch(c->kind){
  case 0:id=Duelists_Named(c->ref);return id>0?Duelists_RecordSlot(gDuel_awPlayerDeck,id)[0]:0;
  case 1:for(id=1;id<Duelists_Count();id++)n+=Duelists_RecordSlot(gDuel_awPlayerDeck,id)[0];return n;
  case 2:id=Duelists_Named(c->ref);return id>0&&Duelists_Unlocked(gDuel_awPlayerDeck,id);
  case 3:id=Cards_Named(c->ref);return id>0&&Cards_Valid(id)&&Cards_Seen(id);
  case 4:id=Cards_Named(c->ref);if(id<=0||!Cards_Valid(id))return 0;
         n=*Cards_ChestSlot(gDuel_awPlayerDeck,id);
         for(int k=0;k<40;k++)n+=gDuel_awPlayerDeck[k]==id;
         return n;
  case 5:for(int k=0;k<(strcmp(c->ref,"first6")==0?6:37);k++){
         id=Duelists_Named(objectives[k].identity);n+=id>0&&Duelists_Unlocked(gDuel_awPlayerDeck,id);}return n;
  case 6:if(strcmp(c->ref,"retail39")==0){for(id=1;id<40;id++)n+=Duelists_RecordSlot(gDuel_awPlayerDeck,id)[0]>=1;}
         else for(int k=0;k<37;k++){id=Duelists_Named(objectives[k].identity);n+=id>0&&Duelists_RecordSlot(gDuel_awPlayerDeck,id)[0]>=1;}
         return n;
  case 7:for(id=1;id<=gCard_nCount;id++)n+=Cards_Valid(id)&&Cards_Seen(id);return n;
 }
 return 0;
}
/* Le nom exact d'une carte doit apparaitre, pas un @card ou une etiquette vague. */
static void format_progress(const ProgressCondition *c,int english_mode,char *out,unsigned cap){
 const char *label=english_mode?c->en:c->fr;
 char card[100];
 if(strcmp(label,"@card")==0){
  int id=Cards_Named(c->ref);
  if(id>0 && Cards_NameUtf8(id,card,sizeof(card)))label=card;
  else {snprintf(card,sizeof(card),english_mode?"Card #%d":"Carte n %d",id);label=card;}
 }
 int value=progression(c);if(value>c->target)value=c->target;
 snprintf(out,cap,"%s : %d/%d",label,value,c->target);
}
static void paint_portrait(int index,int x,int y,int width,int height){
 if(index<0||index>=40)return;
 for(int py=0;py<PORTRAIT_SIZE;py++){
  int top=y+py*height/PORTRAIT_SIZE;
  int bottom=y+(py+1)*height/PORTRAIT_SIZE;
  if(bottom<=top)continue;
  int px=0;
  while(px<PORTRAIT_SIZE){
   unsigned col=portrait_index[index][py*PORTRAIT_SIZE+px];
   int end=px+1;
   while(end<PORTRAIT_SIZE && portrait_index[index][py*PORTRAIT_SIZE+end]==col)end++;
   int x0=x+px*width/PORTRAIT_SIZE,x1=x+end*width/PORTRAIT_SIZE;
   if(x1>x0)rect(x0,top,x1-x0,bottom-top,portrait_palette[index][col],255);
   px=end;
  }
 }
}
static void lock_icon(int x,int y,int s,int unlocked){
 unsigned ink=unlocked?0x64e99a:0xff405c;
 int u=s>0?s:1;
 rect(x+5*u,y,12*u,3*u,ink,255);
 rect(x+2*u,y+3*u,3*u,9*u,ink,255);
 rect(x+17*u,y+3*u,3*u,9*u,ink,255);
 rect(x+4*u,y+10*u,14*u,3*u,ink,255);
 rect(x,y+13*u,22*u,17*u,ink,255);
 rect(x+8*u,y+20*u,6*u,6*u,0x220e19,255);
}
static void render(void){
 if(ios_previous_overlay)ios_previous_overlay();
 if(!opened||page<0||page>=40)return;
 int w,h,scale;H->overlay_size(H,&w,&h,&scale);
 if(w<240||h<180)return;
 int s=w/640;if(s>h/480)s=h/480;if(s<1)s=1;
 draw_art(w,h);
 int left=X(w,120),right=X(w,579),width=right-left;
 int rowh=X(h,117),first=X(h,224);
 char b[255];
 snprintf(b,sizeof(b),"%02d/40   %s",page+1,objectives[page].name);
 text(left+12*s,X(h,148),b,0xfbe4bd,s+1,width-22*s);
 int unlocked_count=0;
 for(int k=0;k<40;k++){
  int id=H->duelist_id(H,objectives[k].identity);
  if(id>0 && Duelists_Unlocked(gDuel_awPlayerDeck,id))unlocked_count++;
 }
 snprintf(b,sizeof(b),english?"DUELISTS UNLOCKED : %d/40":"DUELLISTES DEBLOQUES : %d/40",unlocked_count);
 text(left+12*s,X(h,187),b,0xd0a86a,s,width-22*s);
 int start=(page/5)*5;
 for(int k=0;k<5;k++){
  int idx=start+k,y=first+k*rowh,duelist=H->duelist_id(H,objectives[idx].identity);
  int unlocked=duelist>0&&Duelists_Unlocked(gDuel_awPlayerDeck,duelist);
  int sel=(idx==page);
  rect(left+3*s,y+2*s,width-6*s,rowh-4*s,sel?0x3d1723:0x080710,sel?251:247);
  rect(left+4*s,y+2*s,width-7*s,2*s,sel?0xff614a:0x88603b,255);
  rect(left+4*s,y+rowh-4*s,width-7*s,2*s,sel?0xee624e:0x67472e,255);
  int tiny=w<640,fs=tiny?1:s;
  int nrw=tiny?16*s:31*s, icon=tiny?19*s:38*s, ih=tiny?19*s:35*s;
  int pad=tiny?3*s:8*s;
  rect(left+7*s,y+pad,nrw,ih,0x211521,255);
  snprintf(b,sizeof(b),"%02d",idx+1);
  text(left+8*s,y+rowh/2+2*s,b,sel?0xffe3ae:0xdfc49c,fs,nrw);
  rect(left+(tiny?26:45)*s,y+pad-2*s,icon+4*s,ih+4*s,sel?0x65404b:0x29243e,255);
  rect(left+(tiny?28:47)*s,y+pad,icon,ih,0x101022,255);
  paint_portrait(idx,left+(tiny?28:47)*s,y+pad,icon,ih);
  int name_x=left+(tiny?50:94)*s;
  /* V5 : UNE SEULE ligne : nom. Toutes les conditions vont dans PROGRESS. */
  text(name_x,y+rowh/2+2*s,objectives[idx].name,sel?0xffffff:0xe8d7e7,fs,width-(tiny?72:155)*s);
  if(!tiny)lock_icon(right-30*s,y+16*s,s,unlocked);else {rect(right-11*s,y+5*s,6*s,7*s,unlocked?0x63d995:0xff5061,255);rect(right-12*s,y+12*s,8*s,9*s,unlocked?0x63d995:0xff5061,255);}
 }
 /* V5: le panneau PROGRESS affiche TOUJOURS les conditions completes,
    y compris les duellistes ayant un seul critere. Il adapte la police
    si les contraintes depassent la hauteur disponible. */
 {
  int px=X(w,590),pw=X(w,300),count=progress_counts[page];
  int font=s,nlines=0,needed[6]={0};
  char labels[6][256],splits[6][MAX_LINES][256];
  int lineh,header,height,bottom=X(h,822),top_min=X(h,345);
  for(int k=0;k<count;k++){
   format_progress(&progress_conditions[page][k],english,labels[k],sizeof(labels[k]));
  }
  for(;;){
   nlines=0;
   for(int k=0;k<count;k++){
    needed[k]=word_lines(labels[k],font,pw-24*s,splits[k]);
    nlines+=needed[k];
   }
   lineh=(font==s)?29*s:23*font;
   header=(font==s)?46*s:38*s;
   height=header+nlines*lineh+6*s;
   if(font<=1 || (height<=bottom-top_min && nlines<=count*MAX_LINES))break;
   font--;
  }
  if(height>bottom-top_min)height=bottom-top_min;
  int py=bottom-height;
  rect(px,py,pw,height,0x0a0710,248);
  rect(px,py,pw,2*s,0xb78a59,255);
  rect(px,py,2*s,height,0x75533b,255);
  rect(px+pw-2*s,py,2*s,height,0x75533b,255);
  rect(px,py+height-2*s,pw,2*s,0x75533b,255);
  text(px+12*s,py+17*s,english?"PROGRESS":"PROGRESSION",0xf7d6a3,font,pw-24*s);
  int yy=py+header;
  for(int k=0;k<count;k++){
   const ProgressCondition *c=&progress_conditions[page][k];
   unsigned col=progression(c)>=c->target?0x99f3ac:0xf0d9bc;
   int lim=needed[k]<MAX_LINES?needed[k]:MAX_LINES;
   for(int z=0;z<lim;z++){
    if(yy+lineh>py+height-3*s)break;
    text(px+12*s,yy,splits[k][z],col,font,pw-24*s);
    yy+=lineh;
   }
  }
 }
 /* Footer V6 : centrage au PIXEL pres avec la largeur reelle du texte.
    Le texte reste dynamique pour les deux langues et tient dans le bandeau.
    Milieu du bandeau = x 500/1000, deux lignes resserrees au centre vertical. */
 {
  const char *line1=english?"UP/DOWN: select  |  L1/R1: page  |  O: back":"HAUT/BAS: choisir  |  L1/R1: page  |  O: retour";
  const char *line2=english?"SQUARE: challenges  |  TRIANGLE: FR":"CARRE: defis  |  TRIANGLE: EN";
  int font=s>1?s-1:1;
  int safe_width=X(w,760), center=X(w,500);
  int width1=H->text_width(H,line1,font),width2=H->text_width(H,line2,font);
  /* Garde-fou pour les petites resolutions. */
  while(font>1 && (width1>safe_width || width2>safe_width)){
   font--;width1=H->text_width(H,line1,font);width2=H->text_width(H,line2,font);
  }
  int x1=center-width1/2,x2=center-width2/2;
  int y1=X(h,875),y2=X(h,896);
  text(x1,y1,line1,0xf1e5e4,font,safe_width);
  text(x2,y2,line2,0xf1bf81,font,safe_width);
 }

}

#endif
