# Mise à jour iPhone 0.30 — mod Windows TEST(8)

Ce paquet met à jour le dépôt `lekak-iphone-test6-main` fourni dans cette conversation.
Il contient le code et les ressources pour générer un nouvel IPA. Ce n'est pas un IPA installable.

## Installation dans le dépôt

1. Décompresser `Lekak_iPhone_30_MAJ_Depot.zip` sur l'ordinateur.
2. Copier **tout son contenu à la racine du dépôt iPhone existant**, en fusionnant les dossiers et en remplaçant les fichiers concernés. Inclure le dossier `.github`.
3. Garder les fichiers `Lekak_iPhone_30_Windows_Assets_*.zip` compressés à cette racine. Garder aussi les archives du moteur, des anciennes ressources et des musiques déjà présentes dans le dépôt.
4. Envoyer ces changements sur GitHub.
5. Dans **Actions → Lekak - native iPhone app → Run workflow**, lancer la compilation.
6. Quand le workflow réussit, télécharger l'artefact `Lekak-iPhone-Native-…`. Il contient `Lekak_iPhone_30_Windows_Port.ipa` et une édition `Full_Unlock` réservée aux tests.
7. Signer et installer l'IPA avec la méthode utilisée pour l'ancienne version. La version normale conserve les conditions de déblocage. Le BIN du jeu reste à importer par le joueur.

Il n'est pas nécessaire de remplacer les autres fichiers du dépôt. Aucun fichier de sauvegarde ou de disque du joueur n'est inclus dans cette mise à jour.

## Ce qui est intégré

- Les 4 960 variantes, soit quatre raretés pour chacune des 1 240 cartes normales.
- Le code Windows des variantes v0.7.6 : drops, effets, statistiques, bibliothèques, construction de deck et palettes des cartes.
- L'outil de recherche et de revente avec aperçu de la carte, prix de rareté et réserve de trois exemplaires.
- Les illustrations Windows actualisées, dont les 420 fichiers différents du paquet iPhone précédent.
- La chaîne iPhone existante : objectifs, récompenses, revanche, musiques, commandes tactiles et corrections de références/mots de passe.

Les modules de rareté et de collection sont compilés en ARM64 et intégrés statiquement à l'application. Leurs identifiants restent distincts, pour conserver les services partagés et l'ordre de chargement. Les objets Windows `.o` ne sont pas embarqués.

Le chargeur refuse de démarrer si l'un des trois modules nécessaires manque ou échoue, plutôt que de lancer silencieusement un jeu incomplet. Le cache de compilation du moteur a été renouvelé. Les ressources Windows sont extraites après les anciens packs et les corrections iPhone.

L'écran de collection est adapté à la surface de rendu iPhone. Les banques graphiques natives sont enregistrées auprès de la couche d'adressage 32 bits du moteur sans lui transférer la propriété de leurs allocations.

## Vérifications et limites

Les résultats locaux sont dans `verification/windows-port-validation.json` : vérifications C des 23 unités, 40 cas de palettes 4/8 bits avec le GPU logiciel de production, commandes de polygones, conversion des adresses et réinitialisation, démarrage et refus des modules manquants, affichage collection/recherche/vente à trois résolutions, images référencées, navigation des objectifs, références de cartes et boutique.

Ces tests s'exécutent sur l'hôte. **La traduction LLVM complète, la liaison Xcode, la création de l'IPA et le test sur un iPhone physique n'ont pas été réalisés dans cette session.** Le workflow fourni effectue les étapes de compilation et produit ses journaux. En cas d'échec, récupérer l'artefact de journaux `Lekak-iPhone-native-compile-…`.

Les extensions Windows `hand-camera` et `3d-monsters` ne sont pas portées : leurs sources ne figurent pas dans les archives fournies. Les autres extensions désactivées dans le paquet Windows ne sont pas ajoutées. Le rendu de base et les commandes du projet iPhone restent ceux du projet fourni.

Après installation, vérifier sur appareil : ouverture de chaque bibliothèque de rareté, contour et couleur des cartes dans plusieurs phases de duel, sélection dans Build Deck, vente d'un doublon, récompenses, revanche et reprise d'une sauvegarde. Le comportement et les performances sur appareil restent à confirmer.
