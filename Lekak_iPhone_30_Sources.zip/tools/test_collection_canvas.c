/* Production collection drawing on a mock game-sized canvas. */
#include <assert.h>
#include <stdlib.h>
#include "../SourceMod/Lekak/Collection/collection.c"
static int test_w=640,test_h=480;
static unsigned char pixels[960*720*3],state[0x400],stock=9;
static unsigned star_count=10000;
__typeof__(gMain_bMenuID) gMain_bMenuID;
__typeof__(D_80184599) D_80184599;
__typeof__(D_80184598) D_80184598;
__typeof__(D_8018459A) D_8018459A;
__typeof__(D_8018459B) D_8018459B;
__typeof__(D_8018459C) D_8018459C;
__typeof__(D_8018459D) D_8018459D;
u8 *G32 gMain_apMenuEntries[16];
unsigned char *Cards_ChestSlot(void *p,int id){(void)p;(void)id;return &stock;}
int Cards_BaseId(int id){return id;}
void Cards_PatchArtRecord(int id,unsigned char *p){(void)id;(void)p;}
s32 Duel_GetBaseCardStat(s32 id,s32 def){(void)id;return def?2500:3000;}
static void size(const MemoriesModHost *h,int *w,int *v,int *s){(void)h;*w=test_w;*v=test_h;*s=1;}
static void fill(const MemoriesModHost *h,int x,int y,int w,int v,uint32_t rgb,unsigned alpha){
 (void)h;assert(x>=0&&y>=0&&w>0&&v>0&&x+w<=test_w&&y+v<=test_h);
 for(int yy=y;yy<y+v;yy++)for(int xx=x;xx<x+w;xx++)for(int c=0;c<3;c++){
  unsigned char *p=&pixels[(yy*test_w+xx)*3+c];unsigned n=(rgb>>((2-c)*8))&255;*p=(*p*(255-alpha)+n*alpha)/255;
 }
}
static void *find(const MemoriesModHost *h,const char *key){(void)h;(void)key;return NULL;}
static const MemoriesModHost mock={.overlay_size=size,.fill=fill,.find=find};
int main(int argc,char **argv){
 host=&mock;open=1;result_count=5;save=state;stars=&star_count;
 for(int i=0;i<5;i++){results[i]=i+1;snprintf(names[i+1],NAME_SIZE,"Dragon blanc - Mythique");}
 preview_id=1;preview_ready=1;
 for(int i=0;i<CARD_ART_WIDTH*CARD_ART_HEIGHT;i++)preview_record[i]=1+(i%15);
 for(int i=1;i<16;i++){unsigned v=(i*2)|((31-i)<<5)|(i<<10);preview_record[CARD_ART_CLUT+i*2]=v;preview_record[CARD_ART_CLUT+i*2+1]=v>>8;}
 for(int resolution=0;resolution<3;resolution++){
  test_w=320*(resolution+1);test_h=240*(resolution+1);
  for(int mode=0;mode<3;mode++){editing=mode==1;confirm=mode==2;quantity=1;overlay();}
 }
 editing=confirm=0;test_w=640;test_h=480;overlay();
 if(argc==2){FILE *f=fopen(argv[1],"wb");assert(f);fprintf(f,"P6\n%d %d\n255\n",test_w,test_h);assert(fwrite(pixels,3,test_w*test_h,f)==(size_t)(test_w*test_h));fclose(f);}
 puts("Collection list/search/sale bounds passed at 320x240, 640x480 and 960x720");return 0;
}
