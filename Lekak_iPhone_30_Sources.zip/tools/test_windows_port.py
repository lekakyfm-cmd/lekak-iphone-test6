"""Port data integrity and staged production GPU tests; not an iPhone run."""
import hashlib,json,os,subprocess,tempfile
from pathlib import Path
from static_modules import ROOT,modules,loader_branch
from build_iphone_engine import stage_sources

def main():
 entries=modules();assert len(entries)==3
 ids={m['id'] for m in entries}
 plan=json.loads((ROOT/'SourceMod/Lekak/native-units.json').read_text());assert len(plan['units'])==23
 for u in plan['units']:assert (ROOT/'SourceMod/Lekak'/u['source']).is_file()
 for m in entries:
  directory=ROOT/'Resources'/m['directory'];d=json.loads((directory/'mod.json').read_text())
  assert d['id']==m['id'];assert set(d.get('requires',[]))<=ids
  assert not list(directory.rglob('*.o'))
  for c in d.get('cards',[]):
   for key in ('art','field_art','thumbnail','title_image'):
    if isinstance(c.get(key),str):assert (directory/c[key]).is_file(),(m['id'],c['id'],key,c[key])
 rarity=json.loads((ROOT/'Resources/Lekak_Raretes_Test/mod.json').read_text());assert len(rarity['cards'])==4960
 keys={c['id'] for c in rarity['cards']};assert len(keys)==4960
 for tier in range(1,5):assert sum(k.startswith(f't{tier}-') for k in keys)==1240
 for name,digest in json.loads((ROOT/'windows-port-inventory.json').read_text())['files'].items():
  assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest,name
 with tempfile.TemporaryDirectory(prefix='lekak-port-') as folder:
  stage=Path(folder);stage_sources(stage)
  assert loader_branch() in (stage/'src/pc/mods/mods.c').read_text()
  binary=stage/'gpu-test'
  command=[os.environ.get('CC','cc'),'-std=gnu11','-O2','-DMEMORIES_PC','-DMEMORIES_TRANSLATED','-DMEMORIES_IOS','-I'+str(stage/'src'),str(ROOT/'tools/test_rarity_gpu.c'),str(stage/'src/pc/render/soft_gpu.c'),str(stage/'src/pc/guest/translated_runtime.c'),str(stage/'src/pc/memory.c'),'-o',str(binary)]
  subprocess.run(command,check=True);subprocess.run([str(binary)],check=True)
 print('3 static modules, 4960 variants, all image references and imported-file hashes passed')
if __name__=='__main__':main()
