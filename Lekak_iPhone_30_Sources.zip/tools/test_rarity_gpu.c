/* Production iOS GPU + production packet repair; not a physical-device test. */
#include <assert.h>
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include "pc/render/soft_gpu.h"
#include "pc/render/texture_dump.h"
#include "pc/guest/translated_runtime.h"
typedef uint32_t u32;
#include "../SourceMod/Lekak/Rarities/packet_bank.h"
int TextureDump_Enabled;
uint32_t *TextureDump_Tags;
uint16_t *TextureDump_Shadow;
int (*TextureDump_Prepare)(int,int,int,int,int,int,int);
int (*TextureDump_Sample)(int,int,int,int,int,uint32_t *);
void TextureDump_Init(void){}
void TextureDump_Loaded(int x,int y,int w,int h,const uint16_t *p){(void)x;(void)y;(void)w;(void)h;(void)p;}
void TextureDump_Moved(int x,int y,int a,int b,int w,int h){(void)x;(void)y;(void)a;(void)b;(void)w;(void)h;}
void TextureDump_Cleared(int x,int y,int w,int h){(void)x;(void)y;(void)w;(void)h;}
void TextureDump_Primitive(const uint16_t *p,int a,int b,int c,int d,int e,int f,int g,int h,int i){
 (void)p;(void)a;(void)b;(void)c;(void)d;(void)e;(void)f;(void)g;(void)h;(void)i;
}
static MemoriesMemory memory;
int main(void){
 assert(!GuestRuntime_Bind(&memory));SoftGpu_Reset();
 const uint16_t *vram=SoftGpu_Vram();uint16_t *bank=SoftGpu_Bank(13);assert(bank&&bank!=vram);
 uint32_t a=GuestRuntime_EncodePointer((void *)vram),b=GuestRuntime_EncodePointer(bank);assert(a!=b);
 assert(GuestRuntime_ResolveData((void *)(uintptr_t)a,1024*512*2)==vram);
 assert(GuestRuntime_ResolveData((void *)(uintptr_t)b,1024*512*2)==bank);
 unsigned count=GuestRuntime_RegionCount();
 for(int i=0;i<100;i++){assert(SoftGpu_Bank(13)==bank);assert(SoftGpu_Vram()==vram);}
 assert(count==GuestRuntime_RegionCount());
 for(unsigned i=0;i<count;i++)assert(!(GuestRuntime_Region(i)->flags&MEMORIES_REGION_HEAP));
 for(unsigned depth=0;depth<2;depth++)for(unsigned slot=0;slot<20;slot++){
  memset(bank,0,1024*512*2);unsigned color=(slot+1)|((slot+1)<<5);
  bank[(20+slot)*1024+1]=color;bank[768]=depth?0x0101:0x1111;
  uint32_t q[]={5u<<24,0xe100000cu|(depth<<7),0x65808080u,12u<<16|10,((20u+slot)<<6)<<16,1u<<16|1};
  uint32_t before[6];memcpy(before,q,sizeof q);
  SoftGpu_Fill(10,12,1,1,0);SoftGpu_Gp0(q+1,5);assert(vram[12*1024+10]==0);
  rarity_patch_packets(q,q+6);assert((q[1]>>11&15)==13);
  for(unsigned i=0;i<6;i++)if(i!=1)assert(q[i]==before[i]);
  SoftGpu_Gp0(q+1,5);assert(vram[12*1024+10]==color);assert(vram[(20+slot)*1024+1]==0);
 }
 for(unsigned gouraud=0;gouraud<2;gouraud++){
  uint32_t p[13]={0};p[0]=(gouraud?12u:9u)<<24;p[1]=(gouraud?0x3cu:0x2cu)<<24;
  unsigned i=gouraud?6:5;p[i]=0x004c4321;rarity_patch_packets(p,p+1+(p[0]>>24));
  assert((p[i]>>27&15)==13);assert((p[i]&~(15u<<27))==0x004c4321);
 }
 GuestRuntime_Reset();assert(!GuestRuntime_Bind(&memory));assert(SoftGpu_Bank(13)==bank);assert(SoftGpu_Vram()==vram);
 assert(GuestRuntime_EncodePointer(bank));GuestRuntime_Reset();
 puts("40 sprite palettes, flat/Gouraud packets, native/guest pointers and runtime reset passed");return 0;
}
