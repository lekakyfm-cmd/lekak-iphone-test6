"""Preserve original mod identities while linking their iOS code statically."""
import json
import re
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def modules():
    entries=json.loads((ROOT/'SourceMod/Lekak/native-units.json').read_text())['static_modules']
    for key in ('id','entry','directory'):
        assert len({m[key] for m in entries})==len(entries)
    for m in entries:
        assert re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]*',m['entry'])
        assert re.fullmatch(r'[A-Za-z0-9_-]+',m['id']+m['directory'])
    return entries

def loader_branch():
    entries=modules()
    text='#if defined(MEMORIES_IOS)\n'
    for m in entries:
        text+=f'    extern int {m["entry"]}(const MemoriesModHost *, MemoriesMod *);\n'
    text+=('    extern void LekakStatic_RegisterGlobals(void);\n'
           '    static int registered;\n    (void)path;\n'
           '    if (!registered) { LekakStatic_RegisterGlobals(); registered = 1; }\n'
           '    union { MemoriesModEntry entry; void *pointer; } native = { .entry = NULL };\n')
    for m in entries:
        text+=f'    if (!strcmp(mod->id, "{m["id"]}")) native.entry = {m["entry"]};\n'
    return text+('    if (!native.entry) note(mod, "No compiled iPhone module for this identity");\n'
                 '    return native.pointer;\n'
                 '#elif defined(__APPLE__) && defined(__aarch64__) && defined(MEMORIES_TRANSLATED)\n'
                 '    char error[STATUS_MAX];')
