/* The iPhone overlay is game-sized rather than a desktop window. */
static int canvas_width=960,canvas_height=720;
static void collection_size(int *w,int *h,int *s){
 host->overlay_size(host,w,h,s);
#ifdef MEMORIES_IOS
 canvas_width=*w;canvas_height=*h;*w=960;*h=720;*s=1;
#endif
}
static void collection_fill(int x,int y,int w,int h,uint32_t rgb,unsigned alpha){
#ifdef MEMORIES_IOS
 int right=(x+w)*canvas_width/960,bottom=(y+h)*canvas_height/720;
 x=x*canvas_width/960;y=y*canvas_height/720;
 if(x<0)x=0;if(y<0)y=0;
 if(right>canvas_width)right=canvas_width;
 if(bottom>canvas_height)bottom=canvas_height;
 w=right-x;h=bottom-y;
#endif
 if(w>0&&h>0)host->fill(host,x,y,w,h,rgb,alpha);
}
